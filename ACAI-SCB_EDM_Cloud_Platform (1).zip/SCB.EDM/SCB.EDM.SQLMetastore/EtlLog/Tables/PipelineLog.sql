﻿CREATE TABLE [EtlLog].[PipelineLog] (
    [PipelineLogID]            INT              IDENTITY (1, 1) NOT NULL,
    [ParentPipelineLogID]      INT              NULL,
    [PipelineStatus]           NVARCHAR (50)    NOT NULL,
    [SourceID]                 INT              NULL,
    [SourceObjectID]           INT              NULL,
    [StartTime]                DATETIME         NOT NULL,
    [EndTime]                  DATETIME         NULL,
    [ObjectLoadStartDateTime]  DATETIME         NULL,
    [SliceDateTime]            DATETIME         NOT NULL,
    [RunID]                    UNIQUEIDENTIFIER NOT NULL,
    [LoadType]                 NVARCHAR (20)    NOT NULL,
    [RunFrequencyDurationUnit] NVARCHAR (50)    NULL,
    [CreatedBy]                NVARCHAR (100)   DEFAULT (suser_name()) NOT NULL,
    [CreatedOn]                DATETIME         DEFAULT (switchoffset(sysdatetimeoffset(),'+05:30')) NOT NULL,
    [ModifiedBy]               NVARCHAR (100)   DEFAULT (suser_name()) NOT NULL,
    [ModifiedOn]               DATETIME         DEFAULT (switchoffset(sysdatetimeoffset(),'+05:30')) NOT NULL,
    PRIMARY KEY CLUSTERED ([PipelineLogID] ASC),
    FOREIGN KEY ([SourceID]) REFERENCES [Metadata].[SourceMaster] ([SourceID]),
    FOREIGN KEY ([SourceObjectID]) REFERENCES [Metadata].[SourceObjectDetail] ([SourceObjectID])
);

