﻿CREATE TYPE [EtlLog].[SourceFileList] AS TABLE (
    [FileName]    NVARCHAR (200) NULL,
    [RecordCount] BIGINT         NULL);

