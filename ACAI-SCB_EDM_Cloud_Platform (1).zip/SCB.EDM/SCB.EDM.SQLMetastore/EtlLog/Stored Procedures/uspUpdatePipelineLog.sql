﻿/***************************************************************************************************
-- <copyright file="EtlLog.uspUpdatePipelineLog.sql" company="Bajaj Finserv and Microsoft Corporation">
-- Copyright (c) Bajaj Finserv and Microsoft Corporation. All rights reserved.
-- THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, 
-- INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
-- </copyright>

Procedure:          EtlLog.uspUpdatePipelineLog
Create Date:        2019-04-22
Author:             LAKESH
Description:        To update Pipeline Log.
Call by:              
Affected table(s):  [EtlLog].[PipelineLog]
                    
Used By:            Functional Area this is used in
Parameter(s):       @PipelineLogID - PIPELINE LOG ID,
					@PipelineStatus - PIPELINE STATUS

Usage:              EXEC EtlLog.[uspUpdatePipelineLog]
						@PipelineLogID=1,
						@PipelineStatus='Success'
						
****************************************************************************************************
SUMMARY OF CHANGES
Date(yyyy-mm-dd)    Author              Comments
------------------- ------------------- ------------------------------------------------------------
2019-04-24          Durgesh Nandini     Added Headers

***************************************************************************************************/

CREATE PROCEDURE [EtlLog].[uspUpdatePipelineLog]
( @PipelineLogID INT,
  @PipelineStatus NVARCHAR(50)
)
AS 
BEGIN
	
	SET NOCOUNT ON;

	BEGIN TRY

			IF @PipelineLogID IS NOT NULL
			BEGIN

				-- In case this is the master pipeline and child pipelines failed, then fail the master pipeline as well.
				IF (@PipelineStatus = 'Succeeded' AND (EXISTS (SELECT 1 FROM [EtlLog].[PipelineLog] WITH (NOLOCK)
									WHERE [ParentPipelineLogID] = @PipelineLogID
									AND [PipelineStatus] != 'Succeeded'
						  ))
					)
					SET @PipelineStatus = 'Failed'

				UPDATE [EtlLog].[PipelineLog]
				SET
					[PipelineStatus] = @PipelineStatus,
					[EndTime] = SWITCHOFFSET(SYSDATETIMEOFFSET(), '+05:30'),
					[ModifiedOn] = SWITCHOFFSET(SYSDATETIMEOFFSET(), '+05:30'),
					[ModifiedBy] = SUSER_NAME()
				WHERE [ParentPipelineLogID] = @PipelineLogID
				AND [PipelineStatus] NOT IN ('Succeeded', 'Failed');

				UPDATE [EtlLog].[PipelineLog]
				SET 
					[PipelineStatus] = @PipelineStatus,
					[EndTime] = SWITCHOFFSET(SYSDATETIMEOFFSET(), '+05:30'),
					[ModifiedOn] = SWITCHOFFSET(SYSDATETIMEOFFSET(), '+05:30'),
					[ModifiedBy] = SUSER_NAME()
				WHERE PipelineLogID = @PipelineLogID;
			END

			-- If pipeline status is failed then throw the exception.
			IF @PipelineStatus = 'Failed'
				RAISERROR('Pipeline failed. Please check pipeline logs.', 16, 1);
		END TRY
		BEGIN CATCH
			THROW;
		END CATCH
END