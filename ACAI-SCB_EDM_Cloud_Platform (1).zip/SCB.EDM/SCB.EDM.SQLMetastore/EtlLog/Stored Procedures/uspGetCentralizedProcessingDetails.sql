﻿/***************************************************************************************************
-- <copyright file="EtlLog.uspGetCentralizedProcessingDetails.sql" company="Bajaj Finserv and Microsoft Corporation">
-- Copyright (c) Bajaj Finserv and Microsoft Corporation. All rights reserved.
-- THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, 
-- INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
-- </copyright>

Procedure:          EtlLog.[uspGetCentralizedProcessingDetails]
Create Date:        2019-05-20
Author:             PRANAY BEJGUM
Description:        Get details of table and slice for which databricks ETL should run
Call by:              
Affected table(s):  
                    
Used By:            Functional Area this is used in
Parameter(s):       @PipelineActivityLogID - PIPELINE ACTIVITY LOG ID,
					@SourceObjectId - SOURCE OBJECT ID

Usage:              EXEC EtlLog.[uspGetCentralizedProcessingDetails]
						@PipelineActivityLogID=1,
						@SourceObjectDetailId=1
						
****************************************************************************************************
SUMMARY OF CHANGES
Date(yyyy-mm-dd)    Author              Comments
------------------- ------------------- ------------------------------------------------------------


***************************************************************************************************/

CREATE PROCEDURE [EtlLog].[uspGetCentralizedProcessingDetails]
( 
  @PipelineActivityLogID INT,
  @SourceObjectID INT
)
AS 
BEGIN
	
	SET NOCOUNT ON;

	DECLARE @SliceDateTime DATETIME;
	DECLARE @LandingZoneStorage Varchar(50);
	DECLARE @CentralizedZoneStorage Varchar(50);
	DECLARE @ServicePrincipalID Varchar(50);

	-- Get the slice date time.
	SELECT @SliceDateTime = PL.SliceDateTime 
	  FROM [EtlLog].[PipelineActivityLog] PAL WITH (NOLOCK)
INNER JOIN [EtlLog].[PipelineLog] PL WITH (NOLOCK)
		ON PAL.PipelineLogID = PL.PipelineLogID
	 WHERE PipelineActivityLogID = @PipelineActivityLogID						

	-- Get configurations.
	SET @LandingZoneStorage = (SELECT ConfigurationValue FROM [Metadata].[ProcessConfig] WITH (NOLOCK) WHERE ConfigurationName = 'landingZoneStorageAccount')
	SET @CentralizedZoneStorage = (SELECT ConfigurationValue FROM [Metadata].[ProcessConfig] WITH (NOLOCK) WHERE ConfigurationName = 'centralizedZoneStorageAccount')
	SET @ServicePrincipalID = (SELECT ConfigurationValue FROM [Metadata].[ProcessConfig] WITH (NOLOCK) WHERE ConfigurationName = 'servicePrincipalClientId')

	SELECT 
		SOD.ObjectName,
		SOD.ObjectGroup,
		SM.SourceName,
		SOD.ObjectProperties,
		ISNULL(SOD.FrequencyDurationUnit, SM.FrequencyDurationUnit) AS FrequencyDurationUnit,
		SM.SourceProperties,
		@SliceDateTime AS SliceDateTime,
		@LandingZoneStorage as LandingZoneStorage,
		@CentralizedZoneStorage as CentralizedZoneStorage,
		@ServicePrincipalID as ServicePrincipalClientID
	FROM [Metadata].[SourceObjectDetail] SOD WITH (NOLOCK)
	INNER JOIN [Metadata].[SourceMaster] SM WITH (NOLOCK)
	ON SM.SourceID = SOD.SourceID
	WHERE SOD.SourceObjectID = @SourceObjectID and SM.IsActive = 1;
		
END