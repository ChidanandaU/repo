﻿/***************************************************************************************************
-- <copyright file="EtlLog.uspSourcePipelineStartLog.sql" company="Bajaj Finserv and Microsoft Corporation">
-- Copyright (c) Bajaj Finserv and Microsoft Corporation. All rights reserved.
-- THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, 
-- INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
-- </copyright>

Procedure:          EtlLog.uspSourcePipelineStartLog
Create Date:        2019-04-22
Author:             Lakesh
Description:        To log Source pipeline level details and to determine whether a pipeline to be run or not
Call by:              
Affected table(s):  [EtlLog].[PipelineLog] 
                    
Used By:            Functional Area this is used in
Parameter(s):       @SourceName - source name,
					@SliceDateTime - slice date time,
					@PipelineRunID - pipeline run id,
					@LoadType - load type,
					@ToBeResumed - to be resumed

Usage:              EXEC EtlLog.[uspSourcePipelineStartLog]
						@SourceName = 'FINNCAS',
						@SliceDateTime ='2019-04-24 09:06:19.260',
						@PipelineRunId =NEWID(),
						@LoadType = 'Full',
						@ToBeResumed = 1
****************************************************************************************************
SUMMARY OF CHANGES
Date(yyyy-mm-dd)    Author              Comments
------------------- ------------------- ------------------------------------------------------------
2019-04-24          Durgesh Nandini     Added Headers

***************************************************************************************************/

CREATE PROCEDURE [EtlLog].[uspSourcePipelineStartLog]
( 
  @SourceName NVARCHAR(200),
  @SliceDateTime DATETIME,
  @PipelineRunID UNIQUEIDENTIFIER,
  @LoadType NVARCHAR(20),
  @ToBeResumed BIT,
  @ToBeReRun BIT,
  @RunFrequencyDurationUnit NVARCHAR(50)
)
AS
BEGIN
	
	SET NOCOUNT ON;

	BEGIN TRY

		DECLARE @SourceID INT,
				@PipelineLogID INT,
				@SourceType NVARCHAR(200);

		-- Check whether source exists or not.
		IF NOT EXISTS (SELECT 1 FROM [Metadata].[SourceMaster] WITH (NOLOCK) WHERE [SourceName] = @SourceName)
			RAISERROR('Invalid Source. Source %s doesnt exist.', 16, 1, @SourceName);

		-- Get the Source Id.
		SELECT @SourceID = [SourceID], @SourceType = [SourceType] FROM [Metadata].[SourceMaster] WITH (NOLOCK) WHERE [SourceName] = @SourceName;

		-- Check whether the LoadType is valid (Incremental, Full).
		IF @LoadType NOT IN ('Incremental', 'Full')
			RAISERROR('Invalid LoadType. Possible Load types - Incremental, Full. Provided Load Type - %s.', 16, 1, @LoadType);

		-- Check whether any other run for this Source is already in progress.
		IF EXISTS (SELECT 1 FROM [EtlLog].[PipelineLog] WITH (NOLOCK)
							WHERE [SourceID] = @SourceID
							AND [PipelineStatus] = 'InProgress'
							AND [SourceObjectID] IS NULL
							AND ISNULL([RunFrequencyDurationUnit], '') = ISNULL(@RunFrequencyDurationUnit, '')
							AND [LoadType] = @LoadType
				  )
				RAISERROR('Another pipeline for this source is already in progress, please check.', 16, 1);

		-- Check whether source is Active or not.
		IF NOT EXISTS (SELECT 1 FROM [Metadata].[SourceMaster] WITH (NOLOCK) WHERE [SourceName] = @SourceName AND [IsActive] = 1)
			RAISERROR('Source %s is not Active.', 16, 1, @SourceName);

		-- Check whether ToBeResumed is set but ToBeReRun not set.
		IF @ToBeResumed = 1 AND @ToBeReRun = 0
			RAISERROR('Pipeline cant be resumed when it is not re-running.', 16, 1, @SourceName);

		-- In case of re-run (resume) the slice shall already exist and shall have failed last time.
		IF @ToBeReRun = 1
		BEGIN
		
			IF NOT EXISTS (SELECT 1 FROM [EtlLog].[PipelineLog] WITH (NOLOCK)
									WHERE [SourceID] = @SourceID
									AND [SliceDateTime] = @SliceDateTime
									AND [SourceObjectID] IS NULL
									AND ISNULL([RunFrequencyDurationUnit], '') = ISNULL(@RunFrequencyDurationUnit, '')
									AND [LoadType] = @LoadType
						  )
				RAISERROR('No existing slice to be re-run for source %s.', 16, 1, @SourceName);
		
			IF @ToBeResumed = 1 AND NOT EXISTS (SELECT 1 FROM [EtlLog].[PipelineLog] WITH (NOLOCK)
														WHERE [PipelineLogID] = 
																				(SELECT TOP 1 [PipelineLogID] 
																				   FROM [EtlLog].[PipelineLog] WITH (NOLOCK) 
																				  WHERE [SourceID] = @SourceID
																					AND [SliceDateTime] = @SliceDateTime
																					AND [SourceObjectID] IS NULL
																					AND ISNULL([RunFrequencyDurationUnit], '') = ISNULL(@RunFrequencyDurationUnit, '')
																					AND [LoadType] = @LoadType
																					ORDER BY [StartTime] DESC	
																				)
														AND [PipelineStatus] NOT IN ('InProgress', 'Succeeded')
									)
				RAISERROR('Slice cant be resumed for source %s as it didnt fail in previous run.', 16, 1, @SourceName);

		END

		-- Insert record into [EtlLog].[PipelineLog] table to start the pipeline log.
		EXEC [EtlLog].[uspInsertPipelineLog] 
			@ParentPipelineLogID = NULL, 
			@SourceID = @SourceID, 
			@SourceObjectID = NULL,
			@SliceDateTime = @SliceDateTime,
			@PipelineRunID = @PipelineRunID,
			@RunFrequencyDurationUnit = @RunFrequencyDurationUnit,
			@ObjectLoadStartDateTime = NULL,
			@LoadType = @LoadType;

	END TRY
	BEGIN CATCH
		THROW;		
	END CATCH
END