﻿CREATE TABLE [Recon].[QuantitativeSummary] (
    [QuantitativeSummaryID]      INT            IDENTITY (1, 1) NOT NULL,
    [PipelineLogID]              INT            NOT NULL,
    [SourceObjectID]             INT            NOT NULL,
    [SourceToLandingStatus]      NVARCHAR (50)  NULL,
    [LandingToCentralizedStatus] NVARCHAR (50)  NULL,
    [BatchStatus]                NVARCHAR (50)  NOT NULL,
    [CreatedBy]                  NVARCHAR (100) DEFAULT (suser_name()) NOT NULL,
    [CreatedOn]                  DATETIME       DEFAULT (switchoffset(sysdatetimeoffset(),'+05:30')) NOT NULL,
    [ModifiedBy]                 NVARCHAR (100) DEFAULT (suser_name()) NOT NULL,
    [ModifiedOn]                 DATETIME       DEFAULT (switchoffset(sysdatetimeoffset(),'+05:30')) NOT NULL,
    CONSTRAINT [PK_QuantitativeSummary] PRIMARY KEY CLUSTERED ([QuantitativeSummaryID] ASC),
    CONSTRAINT [FK_QuantitativeSummary_PipelineLog] FOREIGN KEY ([PipelineLogID]) REFERENCES [EtlLog].[PipelineLog] ([PipelineLogID]),
    CONSTRAINT [FK_QuantitativeSummary_SourceObjectDetail] FOREIGN KEY ([SourceObjectID]) REFERENCES [Metadata].[SourceObjectDetail] ([SourceObjectID])
);

