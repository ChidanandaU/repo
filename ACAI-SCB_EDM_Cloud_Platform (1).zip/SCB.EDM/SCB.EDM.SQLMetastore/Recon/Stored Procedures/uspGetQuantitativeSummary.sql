﻿/***************************************************************************************************
-- <copyright file="Recon.uspGetQuantitativeSummary.sql" company="Bajaj Finserv and Microsoft Corporation">
-- Copyright (c) Bajaj Finserv and Microsoft Corporation. All rights reserved.
-- THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, 
-- INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
-- </copyright>

Procedure:          Recon.uspGetQuantitativeSummary
Create Date:        2019-06-18
Author:             Lakesh
Description:        To get the quantitative summary for the run.
Call by:              
Affected table(s):   
                    
Used By:            Functional Area this is used in recon process.
Parameter(s):       @SourceObjectID - source Object ID,
					@PipelineLogID - pipeline Log ID.

Usage:              EXEC Recon.[uspGetQuantitativeSummary]
						@SourceObjectID = 1,
						@PipelineLogID = 2,
						
****************************************************************************************************
SUMMARY OF CHANGES
Date(yyyy-mm-dd)    Author              Comments
------------------- ------------------- ------------------------------------------------------------

***************************************************************************************************/
CREATE PROCEDURE [Recon].[uspGetQuantitativeSummary]
( 
  @SourceObjectID INT,
  @PipelineLogID INT
)
AS 
BEGIN

	SET NOCOUNT ON;

	DECLARE @SourceToLandingStatus NVARCHAR (50),
			@LandingToCentralizedStatus NVARCHAR (50)

	-- Get Source to landing quantitative status.
	SELECT @SourceToLandingStatus = 
		CASE WHEN ISNULL(PAL.[SourceCount], 0) = ISNULL(PAL.[TargetCount], 0)
			 AND ISNULL(PAL.[SourceDataVolume], 0) = ISNULL(PAL.[TargetDataVolume], 0)
			THEN 'Succeeded'
			ELSE 'Failed'
		END
	FROM [EtlLog].[PipelineActivityLog] PAL WITH (NOLOCK)
	INNER JOIN [EtlLog].[PipelineLog] PL WITH (NOLOCK)
	ON PAL.[PipelineLogID] = PL.[PipelineLogID]
	WHERE PL.[PipelineLogID] = @PipelineLogID
	AND PL.[SourceObjectID] = @SourceObjectID
	AND PAL.[ActivityType] != 'Databricks'

	-- Get landing to Centralized quantitative status.
	SELECT @LandingToCentralizedStatus = 
		CASE WHEN ISNULL(PAL.[SourceCount], 0) = ISNULL(PAL.[TargetCount], 0)
			 AND ISNULL(PAL.[SourceDataVolume], 0) = ISNULL(PAL.[TargetDataVolume], 0)
			THEN 'Succeeded'
			ELSE 'Failed'
		END
	FROM [EtlLog].[PipelineActivityLog] PAL WITH (NOLOCK)
	INNER JOIN [EtlLog].[PipelineLog] PL WITH (NOLOCK)
	ON PAL.[PipelineLogID] = PL.[PipelineLogID]
	WHERE PL.[PipelineLogID] = @PipelineLogID
	AND PL.[SourceObjectID] = @SourceObjectID
	AND PAL.[ActivityType] = 'Databricks'

	-- Log the quantitative status.
	INSERT INTO [Recon].[QuantitativeSummary]
	(
		[PipelineLogID],
		[SourceObjectID],
		[SourceToLandingStatus],
		[LandingToCentralizedStatus],
		[BatchStatus]
	)
	SELECT 
		@PipelineLogID,
		@SourceObjectID,
		@SourceToLandingStatus,
		@LandingToCentralizedStatus,
		CASE WHEN ISNULL(@SourceToLandingStatus, 'Succeeded') = 'Succeeded' AND 
				  ISNULL(@LandingToCentralizedStatus, 'Succeeded') = 'Succeeded'
			 THEN 'Succeeded'
			ELSE 'Failed'
		END

END