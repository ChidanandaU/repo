﻿/***************************************************************************************************
-- <copyright file="Recon.uspGetObjectsForQualitativeRecon.sql" company="Bajaj Finserv and Microsoft Corporation">
-- Copyright (c) Bajaj Finserv and Microsoft Corporation. All rights reserved.
-- THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, 
-- INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
-- </copyright>

Procedure:          Recon.uspGetObjectsForQualitativeRecon
Create Date:        2019-06-18
Author:             Lakesh
Description:        To get the objects for which Qualitative recon shall be run.
Call by:              
Affected table(s):   
                    
Used By:            Functional Area this is used in recon process.
Parameter(s):       @SourceName - source name.

Usage:              EXEC [Recon].[uspGetObjectsForQualitativeRecon]
						@SourceName = EDW
						
****************************************************************************************************
SUMMARY OF CHANGES
Date(yyyy-mm-dd)    Author              Comments
------------------- ------------------- ------------------------------------------------------------

***************************************************************************************************/
CREATE PROCEDURE [Recon].[uspGetObjectsForQualitativeRecon]
	@SourceName NVARCHAR (200),
	@SourceObjectID INT
AS
BEGIN

	IF @SourceObjectID != 0
	BEGIN
		SELECT  SOD.[SourceID],
				SOD.[SourceObjectID],
				SOD.[ObjectGroup],
				SOD.[ObjectName]
		FROM [Metadata].[SourceObjectDetail] SOD WITH (NOLOCK)
		INNER JOIN [Metadata].[SourceMaster] SM
		ON SOD.[SourceID] = SM.[SourceID]
		AND SOD.[SourceObjectID] = ISNULL(@SourceObjectID, SOD.[SourceObjectID])
		WHERE SM.[SourceName] = @SourceName
		AND [IsReconActive] = 1
	END
	ELSE
	BEGIN
		SELECT  SOD.[SourceID],
				SOD.[SourceObjectID],
				SOD.[ObjectGroup],
				SOD.[ObjectName]
		FROM [Metadata].[SourceObjectDetail] SOD WITH (NOLOCK)
		INNER JOIN [Metadata].[SourceMaster] SM
		ON SOD.[SourceID] = SM.[SourceID]
		WHERE SM.[SourceName] = @SourceName
		AND [IsReconActive] = 1
	END
END