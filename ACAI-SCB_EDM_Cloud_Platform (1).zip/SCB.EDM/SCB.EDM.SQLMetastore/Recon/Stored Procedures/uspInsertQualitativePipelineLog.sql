﻿/***************************************************************************************************
-- <copyright file="Recon.uspInsertQualitativePipelineLog.sql" company="Bajaj Finserv and Microsoft Corporation">
-- Copyright (c) Bajaj Finserv and Microsoft Corporation. All rights reserved.
-- THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, 
-- INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
-- </copyright>

Procedure:          Recon.uspInsertQualitativePipelineLog
Create Date:        2019-09-11
Author:             Lakesh
Description:        Insert ParentPipelineLogId, SourceID, SourceObjectID, SliceDateTime,PipelineRunId into [EtlLog].[PipelineLog] Table

Call by:            

Affected table(s):  [Recon].[QualitativePipelineLog]
                    
Used By:            Functional Area this is used in
Parameter(s):       @ParentPipelineLogId -Parent Pipeline Log ID
					@SourceID - Source ID
					@SourceObjectID - Source Object ID
					@SliceDateTime - slice date time
					@PipelineRunId - Pipeline Run ID
					@PipelineLogID - Output as Pipeline Log ID

Usage:              EXEC Recon.QualitativePipelineLog
						@ParentPipelineLogId =3
						@SourceID=1,
						@SourceObjectID =3,
						@SliceDateTime ='2019-04-24 09:06:19.260',
						@PipelineRunId =NEWID()
****************************************************************************************************
SUMMARY OF CHANGES
Date(yyyy-mm-dd)    Author              Comments
------------------- ------------------- ------------------------------------------------------------

***************************************************************************************************/

CREATE PROCEDURE [Recon].[uspInsertQualitativePipelineLog]
( 
  @ParentPipelineLogID  INT,
  @SourceID INT,
  @SourceObjectID INT,
  @ReconStartDateTime DATETIME,
  @SliceDateTime DATETIME,
  @PipelineRunID UNIQUEIDENTIFIER
)
AS 
BEGIN
	
	SET NOCOUNT ON;

	BEGIN TRY

		-- Check whether any other run for this Source Object is already in progress.
		IF @SourceObjectID IS NOT NULL AND EXISTS (SELECT 1 FROM [Recon].[QualitativePipelineLog] WITH (NOLOCK)
							WHERE [SourceID] = @SourceID
							AND [PipelineStatus] = 'InProgress'
							AND [SourceObjectID] = @SourceObjectID
				  )
				RAISERROR('Another qualitative recon pipeline for this object is already in progress, please check.', 16, 1);

		INSERT INTO [Recon].[QualitativePipelineLog]
		(	
			ParentPipelineLogID,
			PipelineStatus,
			SourceID,
			SourceObjectID,
			StartTime,
			SliceDateTime,
			RunID,
			ReconStartDateTime
		)
		VALUES 
		(
			@ParentPipelineLogID,
			'InProgress',
			@SourceID,
			@SourceObjectID,
			SWITCHOFFSET(SYSDATETIMEOFFSET(), '+05:30'),
			@SliceDateTime,
			@PipelineRunID,
			@ReconStartDateTime
		);
	
		-- Return PipelineLogID.
		SELECT SCOPE_IDENTITY() AS PipelineLogID, @SourceID AS SourceID;

	END TRY
	BEGIN CATCH
		THROW;		
	END CATCH
END