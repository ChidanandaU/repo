# Example ETL with no parameters - see etl() function

from pyspark.sql import SparkSession
from pyspark.sql.functions import current_timestamp
from pipelines.utils import generictransformations as trans, configmanagement as cm

spark = SparkSession.builder.getOrCreate()


def extract(filePath):
    return spark.read.format("parquet").load(filePath)

def transform(df):
    df = df.withColumn("meta_timestamp", current_timestamp())
    df = trans.addDummyColumn(df)
    return df

def load(df):
  spark.sql("DROP TABLE IF EXISTS TargetTable")
  df.write.format("parquet").mode("overwrite").saveAsTable("TargetTable")
  return

def etl():
  df = extract("/databricks-datasets/amazon/test4K")
  df = transform(df)
  load(df)