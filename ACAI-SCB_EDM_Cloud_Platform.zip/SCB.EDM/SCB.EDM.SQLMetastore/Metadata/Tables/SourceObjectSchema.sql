﻿CREATE TABLE [Metadata].[SourceObjectSchema] (
    [SourceObjectSchemaID] INT            IDENTITY (1, 1) NOT NULL,
    [SourceObjectID]       INT            NOT NULL,
    [ColumnName]           NVARCHAR (200) NOT NULL,
    [ColumnOrder]          INT            NOT NULL,
    [DataType]             NVARCHAR (100) NOT NULL,
    [PrimaryKey]           BIT            DEFAULT ((0)) NOT NULL,
    [ColumnFormat]         NVARCHAR (200) NULL,
    [IsActive] bit,
    [CreatedBy]            NVARCHAR (100) DEFAULT (suser_name()) NOT NULL,
    [CreatedOn]            DATETIME       DEFAULT (switchoffset(sysdatetimeoffset(),'+05:30')) NOT NULL,
    [ModifiedBy]           NVARCHAR (100) DEFAULT (suser_name()) NOT NULL,
    [ModifiedOn]           DATETIME       DEFAULT (switchoffset(sysdatetimeoffset(),'+05:30')) NOT NULL,
    CONSTRAINT [PK_SourceObjectSchema] PRIMARY KEY CLUSTERED ([SourceObjectSchemaID] ASC),
    CONSTRAINT [FK_SourceObjectSchema_SourceObjectDetail] FOREIGN KEY ([SourceObjectID]) REFERENCES [Metadata].[SourceObjectDetail] ([SourceObjectID])
);

