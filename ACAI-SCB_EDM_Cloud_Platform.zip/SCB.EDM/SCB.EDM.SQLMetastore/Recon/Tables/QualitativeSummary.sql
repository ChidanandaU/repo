﻿CREATE TABLE [Recon].[QualitativeSummary] (
    [QualitativeSummaryID] INT             IDENTITY (1, 1) NOT NULL,
    [SourceObjectID]       INT             NOT NULL,
    [BatchWindowStart]     DATETIME        NOT NULL,
    [BatchWindowEnd]       DATETIME        NOT NULL,
    [BatchStartDateTime]   DATETIME        NOT NULL,
    [BatchEndDateTime]     DATETIME        NULL,
    [HashDefinition]       NVARCHAR (4000) NULL,
    [BatchStatus]          NVARCHAR (MAX)  NOT NULL,
    [TotalRecords]         BIGINT          NULL,
    [FailedRecords]        BIGINT          NULL,
    [FieldMismatchCount]   BIGINT          NULL,
    [CorrectionStatus]     NVARCHAR (1000) NULL,
    [CorrectionQuery]      NVARCHAR (MAX)  NULL,
    [CreatedBy]            NVARCHAR (100)  DEFAULT (suser_name()) NOT NULL,
    [CreatedOn]            DATETIME        DEFAULT (switchoffset(sysdatetimeoffset(),'+05:30')) NOT NULL,
    [ModifiedBy]           NVARCHAR (100)  DEFAULT (suser_name()) NOT NULL,
    [ModifiedOn]           DATETIME        DEFAULT (switchoffset(sysdatetimeoffset(),'+05:30')) NOT NULL,
    CONSTRAINT [PK_QualitativeSummary] PRIMARY KEY CLUSTERED ([QualitativeSummaryID] ASC),
    CONSTRAINT [FK_QualitativeSummary_SourceObjectDetail] FOREIGN KEY ([SourceObjectID]) REFERENCES [Metadata].[SourceObjectDetail] ([SourceObjectID])
);

