﻿/***************************************************************************************************
-- <copyright file="Recon.uspGetQualitativeObjectDetails.sql" company="Bajaj Finserv and Microsoft Corporation">
-- Copyright (c) Bajaj Finserv and Microsoft Corporation. All rights reserved.
-- THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, 
-- INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
-- </copyright>

Procedure:          Recon.uspGetQualitativeObjectDetails
Create Date:        2019-09-11
Author:             Lakesh
Description:        To get Source object level details for recon.
Call by:              
Affected table(s):   
                    
Used By:            Functional Area this is used in
Parameter(s):       @SourceID - source ID,
					@SliceDateTime - slice date time

Usage:              EXEC Recon.uspGetQualitativeObjectDetails
						@SourceID = '1',
						@SliceDateTime ='2019-04-24 09:06:19.260'
						
****************************************************************************************************
SUMMARY OF CHANGES
Date(yyyy-mm-dd)    Author              Comments
------------------- ------------------- ------------------------------------------------------------

***************************************************************************************************/

CREATE PROCEDURE [Recon].[uspGetQualitativeObjectDetails]
( 
  @SourceID INT,
  @SliceDateTime DATETIME
)
AS
BEGIN
	
	SET NOCOUNT ON;

	BEGIN TRY
		-- Get all the objects that need to be processed based on Frequency.
		;WITH cteLastMaxSliceDateTime
		AS
		(
			SELECT MAX(SliceDateTime) AS LastSliceDateTime,
					[SourceObjectID]
			FROM [Recon].[QualitativePipelineLog] WITH (NOLOCK)
			WHERE [SourceID] = @SourceID
				AND [PipelineStatus] = 'Succeeded'
				AND [SourceObjectID] IS NOT NULL
			GROUP BY [SourceObjectID]
		)
		SELECT
			SOD.[SourceObjectID],
			ISNULL(SOE.[LastSliceDateTime], CAST('1900-01-01' AS DATETIME)) AS LastReconDate
		FROM [Metadata].[SourceObjectDetail] SOD WITH (NOLOCK)
		INNER JOIN [Metadata].[SourceMaster] SM WITH (NOLOCK)
		ON SOD.[SourceID] = SM.[SourceID]
		LEFT OUTER JOIN cteLastMaxSliceDateTime SOE WITH (NOLOCK)
		ON SOD.[SourceObjectID] = SOE.[SourceObjectID]
		WHERE SOD.[IsReconActive] = 1
		ORDER BY SOD.[LoadOrder]

	END TRY
	BEGIN CATCH
		THROW;		
	END CATCH
END