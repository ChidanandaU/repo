﻿/***************************************************************************************************
-- <copyright file="Recon.uspGetDataIngestionStatus.sql" company="Bajaj Finserv and Microsoft Corporation">
-- Copyright (c) Bajaj Finserv and Microsoft Corporation. All rights reserved.
-- THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, 
-- INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
-- </copyright>

Procedure:          Recon.uspGetDataIngestionStatus
Create Date:        2019-10-02
Author:             Lakesh
Description:        To get Source object data ingestion status.
Call by:              
Affected table(s): 
						
****************************************************************************************************
SUMMARY OF CHANGES
Date(yyyy-mm-dd)    Author              Comments
------------------- ------------------- ------------------------------------------------------------

***************************************************************************************************/
CREATE PROCEDURE [Recon].[uspGetDataIngestionStatus]
(	
  @SourceObjectID INT,
  @QualitativeSummaryID INT
)
AS
BEGIN
	
	SET NOCOUNT ON;

	BEGIN TRY
		IF EXISTS (SELECT 1 FROM [EtlLog].[PipelineLog] WITH (NOLOCK)
								WHERE [PipelineStatus] = 'InProgress'
								AND [SourceObjectID] = @SourceObjectID
				  )			  
					RAISERROR('Data Ingestion pipeline for this object is in progress, please check.', 16, 1);
		ELSE
			UPDATE [Recon].[QualitativeSummary]
			SET [CorrectionStatus] = 'InProgress'
			WHERE [QualitativeSummaryID] = @QualitativeSummaryID;

	END TRY
	BEGIN CATCH
		THROW;		
	END CATCH
END