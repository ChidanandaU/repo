﻿/***************************************************************************************************
-- <copyright file="EtlLog.uspInsertPipelineActivityLog.sql" company="Bajaj Finserv and Microsoft Corporation">
-- Copyright (c) Bajaj Finserv and Microsoft Corporation. All rights reserved.
-- THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, 
-- INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
-- </copyright>

Procedure:          EtlLog.uspInsertPipelineActivityLog
Create Date:        2019-04-22
Author:             Pranay
Description:        Insert PipelineLogId, ActivityName, ActivityType, ActivityStatus, StartTime into [EtlLog].[PipelineActivityLog] Table
Call by:            
Affected table(s):  [EtlLog].[PipelineActivityLog] 
                    
Used By:            Functional Area this is used in
Parameter(s):       @SourceObjectID  - Source Object ID
					@PipelineLogID - Pipeline Log ID
					@ActivityName - Activity name
					@ActivityType - Activity Type
					@SliceDateTime - Slice date time
					@ToBeResumed - to be resumed

Usage:              EXEC EtlLog.uspInsertPipelineActivityLog
						@SourceObjectID=2,
						@PipelineLogID =3,
						@ActivityName='activity',
						@ActivityType='Az Copy',
						@SliceDateTime='2019-04-24 09:06:19.260',
						@ToBeResumed=1
****************************************************************************************************
SUMMARY OF CHANGES
Date(yyyy-mm-dd)    Author              Comments
------------------- ------------------- ------------------------------------------------------------
2019-04-24          Durgesh Nandini     Added Headers

***************************************************************************************************/

CREATE PROCEDURE [EtlLog].[uspInsertPipelineActivityLog]
(
  @SourceObjectID INT,
  @PipelineLogID INT,
  @ActivityName NVARCHAR(200),
  @ActivityType NVARCHAR(200),
  @SliceDateTime DATETIME,
  @ToBeResumed BIT,
  @RunFrequencyDurationUnit NVARCHAR(50),
  @LoadType NVARCHAR(20)
)
AS 
BEGIN
	
	SET NOCOUNT ON;

	BEGIN TRY

		-- If the existing slice need to be resumed, determine whether this activity need to re-run.
		IF (@ToBeResumed = 1 AND EXISTS (
											SELECT 1 
											FROM [EtlLog].[PipelineActivityLog]	WITH (NOLOCK)
											WHERE [PipelineActivityLogID] = (SELECT TOP 1 PAL.[PipelineActivityLogID]
																				FROM [EtlLog].[PipelineLog] PL WITH (NOLOCK)
																				INNER JOIN [EtlLog].[PipelineActivityLog] PAL WITH (NOLOCK)
																				ON PL.[PipelineLogID] = PAL.[PipelineLogID]
																				WHERE PL.[SourceObjectID] = @SourceObjectID
																				AND PL.[SliceDateTime] = @SliceDateTime
																				AND PAL.[ActivityName] = @ActivityName
																				AND PAL.[ActivityType] = @ActivityType
																				AND ISNULL(PL.[RunFrequencyDurationUnit], '') = ISNULL(@RunFrequencyDurationUnit, '')
																				AND PL.[LoadType] = @LoadType
																				ORDER BY PAL.[StartTime] DESC
																			) AND [ActivityStatus] = 'Succeeded'
										)
			)
			SELECT 0 AS ToBeRun, NULL AS PipelineActivityLogID
		ELSE
			BEGIN
				INSERT INTO [EtlLog].PipelineActivityLog 
				(PipelineLogID, ActivityName, ActivityType, ActivityStatus, StartTime)
				VALUES	
				(@PipelineLogID, @ActivityName, @ActivityType, 'InProgress', SWITCHOFFSET(SYSDATETIMEOFFSET(), '+05:30'));

				SELECT 1 AS ToBeRun, SCOPE_IDENTITY() AS PipelineActivityLogID
			END
	END TRY
	BEGIN CATCH

		-- Update the Pipeline Log to failed.
		EXEC [EtlLog].[uspUpdatePipelineLog]
			@PipelineLogID = @PipelineLogID,
			@PipelineStatus = 'Failed';
		THROW;
	END CATCH

END