﻿CREATE TABLE [EtlLog].[SourceFileProcessLog] (
    [SourceFileProcessLogID] INT            IDENTITY (1, 1) NOT NULL,
    [PipelineLogID]          INT            NOT NULL,
    [FileName]               NVARCHAR (200) NOT NULL,
    [RecordCount]            BIGINT         NULL,
    [IsRawtoLandingProcessed] bit, 
    [IsLandingtoStandardisedProcessed] bit,
    [CreatedBy]              NVARCHAR (100) DEFAULT (suser_name()) NOT NULL,
    [CreatedOn]              DATETIME       DEFAULT (switchoffset(sysdatetimeoffset(),'+05:30')) NOT NULL,
    [ModifiedBy]             NVARCHAR (100) DEFAULT (suser_name()) NOT NULL,
    [ModifiedOn]             DATETIME       DEFAULT (switchoffset(sysdatetimeoffset(),'+05:30')) NOT NULL,
    FOREIGN KEY ([PipelineLogID]) REFERENCES [EtlLog].[PipelineLog] ([PipelineLogID])
);

