CREATE TABLE [ETLlog].[SourceFileProcessLog](
	[SourceFileProcessLogID] [int] IDENTITY(1,1) NOT NULL,
	[PipelineLogID] [int] NOT NULL,
	[FileName] [nvarchar](200) NOT NULL,
	[SourceCount] [bigint] NULL,
	[TargetCount] [bigint] NULL,
	[RejectCount] [bigint] NULL,
	[ErrorCount] [bigint] NULL,
	[IsLandingToRawProcessed] [bit] NULL,
	[IsRawtoStandardisedProcessed] [bit] NULL,
	[IsCDCFile] [bit] NULL,
	[SourceID] [int] NULL,
	[SourceObjectID] [int] NULL,
	[FilePath] [nvarchar](max) NULL,
	[RawPath] [NVARCHAR](500) NULL,
	[SourceFileStatus] [varchar](20) NULL,
	[RawFileStatus] [NVARCHAR](20) NULL,
	[CreatedBy] [nvarchar](100) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](100) NOT NULL,
	[ModifiedOn] [datetime] NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [ETLlog].[SourceFileProcessLog] ADD  DEFAULT (suser_name()) FOR [CreatedBy]
GO

ALTER TABLE [ETLlog].[SourceFileProcessLog] ADD  DEFAULT (switchoffset(sysdatetimeoffset(),'+05:30')) FOR [CreatedOn]
GO

ALTER TABLE [ETLlog].[SourceFileProcessLog] ADD  DEFAULT (suser_name()) FOR [ModifiedBy]
GO

ALTER TABLE [ETLlog].[SourceFileProcessLog] ADD  DEFAULT (switchoffset(sysdatetimeoffset(),'+05:30')) FOR [ModifiedOn]
GO

ALTER TABLE [ETLlog].[SourceFileProcessLog]  WITH CHECK ADD FOREIGN KEY([PipelineLogID])
REFERENCES [ETLlog].[PipelineLog] ([PipelineLogID])
GO

