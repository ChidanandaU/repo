CREATE PROCEDURE [ETLlog].[uspUpdatePoolConfigurationLog]
@PoolConfigurationID INT,
@InstancePoolId NVARCHAR(1000),
@Mode Nvarchar(1000)
AS
-----------------------------------------------------------------------------------------------------------------------
/****** StoredProcedure:		[ETLlog].[uspUpdatePoolConfigurationLog]
		Script Date:			2021-06-07 
		Author:					Santhosh Boyapally
		Test Execute:			This SP is used to insert records into the PoolConfigurationLog Table.
		CMD:					EXEC ETLlog.uspUpdatePoolConfigurationLog
								@PoolConfigurationID = <value>, @InstancePoolId=<value>, @Mode= <value>
								
******/
-----------------------------------------------------------------------------------------------------------------------
BEGIN
	BEGIN TRY	
	IF @Mode = 'insert'
	BEGIN
		Insert Into [ETLlog].[PoolConfigurationLog]
			(
			PoolConfigurationID
			,InstancePoolId
			,StartDate
			,EndDate
			,IsActive
			,CreatedBy
			,CreatedOn
			)
			VALUES
			(
				@PoolConfigurationID,
				@InstancePoolId,
				SWITCHOFFSET(SYSDATETIMEOFFSET(), '+08:00'), 
				'9999-12-31',
				1,
				SUSER_NAME(),
				GETUTCDATE()
			)
     END 
	 ELSE 
	 BEGIN 
		 Update  [ETLlog].[PoolConfigurationLog]
		   SET 	isactive=0,
				EndDate = getdate(),
				ModifiedBy = SUSER_NAME(),
				ModifiedOn = GETUTCDATE()
		WHERE InstancePoolId=@InstancePoolId
	 END
	END TRY

	BEGIN CATCH
		DECLARE @Errmsg NVARCHAR(4000) = (
				SELECT ERROR_MESSAGE()
				)
			,@ErrorSeverity INT = ERROR_SEVERITY()
			,@ErrorState INT = ERROR_STATE()

		RAISERROR (
				@Errmsg
				,@ErrorSeverity
				,@ErrorState
				)
	END CATCH
END
