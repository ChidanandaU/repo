CREATE PROCEDURE [ETLlog].[uspInsertPipelineActivityErrorLog]
( 
  @PipelineLogID INT,
  @PipelineActivityLogID INT,
  @ErrorMessage NVARCHAR(MAX),
  @SoucreFileProcessLogID INT,
  @IsLandingToRawProcessed BIT,
  @IsRawtoStandardisedProcessed BIT
)
AS 
BEGIN
	
	SET NOCOUNT ON;

	INSERT INTO [EtlLog].[PipelineActivityErrorLog] 
	(PipelineActivityLogID, ErrorMessage)
	VALUES
	(@PipelineActivityLogID, @ErrorMessage);

	-- Update the activity status as failed.
	EXEC [EtlLog].[uspUpdatePipelineActivityLog]
		@PipelineActivityLogID = @PipelineActivityLogID,
		@ActivityStatus = 'Failed'

	-- Update the pipeline status as failed.
	EXEC [EtlLog].[uspUpdatePipelineLog]
	@PipelineLogID = @PipelineLogID,
	@SourceFileProcessLogID = @SoucreFileProcessLogID,
	@SourceCount = NULL, 
	@TargetCount = NULL, 
	@ErrorCount  = NULL, 
	@IsLandingToRawProcessed = 0,
	@IsRawtoStandardisedProcessed = 0,
	@SourceObjectId = NULL, 
	@SourceId= NULL,
	@PipelineStatus = 'Failed',
	@SourceFileStatus = 'Failed'

END