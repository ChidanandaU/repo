CREATE PROCEDURE [ETLlog].[uspUpdatePipelineLog]
( @PipelineLogID INT,
  @SourceFileProcessLogID INT, 
  @SourceCount  BIGINT, 
  @TargetCount  BIGINT, 
  @ErrorCount   BIGINT, 
  @IsLandingToRawProcessed bit,
  @IsRawtoStandardisedProcessed bit,
  @IsCDCFile bit = NULL,
  @SourceObjectId int, 
  @SourceId int,
  @PipelineStatus NVARCHAR(50),
  @SourceFileStatus VARCHAR(20)
)
AS 
-----------------------------------------------------------------------------------------------------------------------    
/****** StoredProcedure:	[ETLlog].[uspUpdatePipelineLog]
  Script Date:				2021-07-14     
  Author:					Sonam Jain 
  Test Execute:				This SP is used to insert pipeline logs
  CMD:						EXEC [ETLlog].[uspUpdatePipelineLog]
							@ParentPipelineLogID = '<value>'
							,@SourceFileProcessLogID = '<value>'
							,@SourceCount = '<value>'
							,@TargetCount = '<value>'
							,@ErrorCount = '<value>'
							,@IsLandingToRawProcessed = '<value>'
							,@IsRawtoStandardisedProcessed = '<value>'
							,@SourceObjectId = '<value>'
							,@SourceId = '<value>'
							,@PipelineStatus = '<value>'
							,@SourceFileStatus = '<value>'
******/    
-----------------------------------------------------------------------------------------------------------------------    

BEGIN
	
	SET NOCOUNT ON;

	BEGIN TRY

			IF @PipelineLogID IS NOT NULL
			BEGIN

				-- In case this is the master pipeline and child pipelines failed, then fail the master pipeline as well.
				IF (@PipelineStatus = 'Succeeded' AND (EXISTS (SELECT 1 FROM [EtlLog].[PipelineLog] WITH (NOLOCK)
									WHERE [ParentPipelineLogID] = @PipelineLogID
									AND [PipelineStatus] != 'Succeeded'
						  ))
					)
					SET @PipelineStatus = 'Failed'

				UPDATE [EtlLog].[PipelineLog]
				SET
					[PipelineStatus] = @PipelineStatus,
					[EndTime] = SWITCHOFFSET(SYSDATETIMEOFFSET(), '+08:00'),
					[ModifiedOn] = SWITCHOFFSET(SYSDATETIMEOFFSET(), '+08:00'),
					SourceObjectId=@SourceObjectId,
					[ModifiedBy] = SUSER_NAME()
				WHERE [ParentPipelineLogID] = @PipelineLogID
				AND [PipelineStatus] NOT IN ('Succeeded', 'Failed');


				UPDATE [EtlLog].[SourceFileProcessLog]
				SET SourceCount=@SourceCount,
					TargetCount=@TargetCount,
					ErrorCount=@ErrorCount,
					IsLandingToRawProcessed=@IsLandingToRawProcessed,
					IsRawtoStandardisedProcessed=@IsRawtoStandardisedProcessed,
					IsCDCFile = @IsCDCFile,
					SourceID=@SourceId, 
					SourceObjectId=@SourceObjectId,
					SourceFileStatus = @SourceFileStatus,
					[ModifiedOn] = SWITCHOFFSET(SYSDATETIMEOFFSET(), '+08:00'),
					[ModifiedBy] = SUSER_NAME()
				WHERE SourceFileProcessLogID = @SourceFileProcessLogID

				UPDATE [EtlLog].[PipelineLog]
				SET 
					[PipelineStatus] = @PipelineStatus,
					[EndTime] = SWITCHOFFSET(SYSDATETIMEOFFSET(), '+08:00'),
					[ModifiedOn] = SWITCHOFFSET(SYSDATETIMEOFFSET(), '+08:00'),
					SourceObjectId=@SourceObjectId,
					[ModifiedBy] = SUSER_NAME()
				WHERE PipelineLogID = @PipelineLogID;
			END

			-- If pipeline status is failed then throw the exception.
			IF @PipelineStatus = 'Failed'
				RAISERROR('Pipeline failed. Please check pipeline logs.', 16, 1);
		END TRY
		BEGIN CATCH
			DECLARE @Errmsg NVARCHAR(4000) = (
				SELECT ERROR_MESSAGE()
				)
			,@ErrorSeverity INT = ERROR_SEVERITY()
			,@ErrorState INT = ERROR_STATE()

		RAISERROR (
				@Errmsg
				,@ErrorSeverity
				,@ErrorState
				)
		END CATCH
END
