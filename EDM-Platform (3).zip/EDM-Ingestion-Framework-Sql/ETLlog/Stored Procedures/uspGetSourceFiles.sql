CREATE PROCEDURE [ETLlog].[uspGetSourceFiles]
(
	@SourceName NVARCHAR(50),
	@SourceFileStatus NVARCHAR(20)
)
AS
-----------------------------------------------------------------------------------------------------------------------    
/****** StoredProcedure:	[ETLlog].[uspGetSourceFiles] 
  Script Date:				2021-07-14     
  Author:					Sonam Jain 
  Test Execute:				This SP is used to get list of source files to be processed from landing zone
  CMD:						EXEC [ETLlog].[uspGetSourceFiles] 
							@SourceName= '<value>' ,
							@SourceFileStatus = '<value>'
******/    
-----------------------------------------------------------------------------------------------------------------------    

BEGIN
	SET NOCOUNT ON;

    BEGIN TRY

		DECLARE @SourceFileList TABLE 
			(
				SourceFileProcessLogId INT
				, PipelineLogId INT
				, Source NVARCHAR(50)
				, Country NVARCHAR(20)
				, FilePath NVARCHAR(MAX)
				, FileName NVARCHAR(200)
			)
		
		INSERT INTO @SourceFileList
		SELECT SourceFileProcessLogId,
			PipelineLogId,
			@SourceName AS Source, 
			RIGHT(FilePath,CHARINDEX('/',REVERSE(FilePath))-1) AS Country,
			FilePath, 
			FileName 
		FROM  [ETLlog].[SourceFileProcessLog]
		WHERE SourceFileStatus = @SourceFileStatus 
			AND FilePath LIKE '%/' + @SourceName +'/%'

		UPDATE sfpl
		SET SourceFileStatus = 'Processing',
			ModifiedBy = SUSER_NAME(),
			ModifiedOn = GETUTCDATE()
		FROM @SourceFileList AS sfl
		INNER JOIN [ETLlog].[SourceFileProcessLog] AS sfpl
			ON sfl.SourceFileProcessLogId = sfpl.SourceFileProcessLogID

		SELECT PipelineLogId, Source, Country, FilePath, FileName FROM @SourceFileList
	
	END TRY

	BEGIN CATCH
		DECLARE @Errmsg NVARCHAR(4000) = (    
		   SELECT ERROR_MESSAGE() )    
		  ,@ErrorSeverity INT = ERROR_SEVERITY()    
		  ,@ErrorState INT = ERROR_STATE()    
    
		  RAISERROR (    
			@Errmsg    
			,@ErrorSeverity    
			,@ErrorState    
			)   

	END CATCH

END


