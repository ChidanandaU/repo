CREATE PROCEDURE [ETLlog].[uspInsertPipelineEtlActivityLog]
(
  @SourceObjectID INT,
  @PipelineLogID INT,
  @ActivityName NVARCHAR(200),
  @ActivityType NVARCHAR(200)
)
AS 
BEGIN
	
	SET NOCOUNT ON;

	BEGIN TRY
		
				INSERT INTO [EtlLog].PipelineEtlActivityLog 
				(PipelineLogID, ActivityName, ActivityType, ActivityStatus, StartTime)
				VALUES	
				(@PipelineLogID, @ActivityName, @ActivityType, 'InProgress', SWITCHOFFSET(SYSDATETIMEOFFSET(), '+05:30'));

				SELECT SCOPE_IDENTITY() AS PipelineActivityLogID

	END TRY
	BEGIN CATCH

		-- Update the Pipeline Log to failed.
		EXEC [EtlLog].[uspUpdatePipelineLog]
			@PipelineLogID = @PipelineLogID,
			@PipelineStatus = 'Failed'

		DECLARE @Errmsg NVARCHAR(4000) = (
				SELECT ERROR_MESSAGE()
				)
			,@ErrorSeverity INT = ERROR_SEVERITY()
			,@ErrorState INT = ERROR_STATE()

		RAISERROR (
				@Errmsg
				,@ErrorSeverity
				,@ErrorState
				)
	END CATCH

END



