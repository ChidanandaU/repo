CREATE PROCEDURE [ETLLog].[uspGetSourceName]
(
	@SourceFileStatus VARCHAR(20)
)
AS
-----------------------------------------------------------------------------------------------------------------------    
/****** StoredProcedure:	[ETLLog].[uspGetSourceName]  
  Script Date:				2021-07-14     
  Author:					Sonam Jain 
  Test Execute:				This SP is used to get distinct source list from landing zone
  CMD:						EXEC [ETLLog].[uspGetSourceName] 
							@SourceFileStatus= '<value>'    
******/    
-----------------------------------------------------------------------------------------------------------------------    

BEGIN
	SET NOCOUNT ON;

	BEGIN TRY
		
		SELECT DISTINCT SUBSTRING(SUBSTRING(FilePath,CHARINDEX('/', FilePath) + 1,LEN(FilePath) - CHARINDEX('/', FilePath) - CHARINDEX('/',REVERSE(FilePath)) ),CHARINDEX('/',SUBSTRING(FilePath,CHARINDEX('/', FilePath) + 1,LEN(FilePath) - CHARINDEX('/', FilePath) - CHARINDEX('/',REVERSE(FilePath)) ))+1,LEN(SUBSTRING(FilePath,CHARINDEX('/', FilePath) + 1,LEN(FilePath) - CHARINDEX('/', FilePath) - CHARINDEX('/',REVERSE(FilePath))))) AS Source
		FROM [ETLlog].[SourceFileProcessLog]		
		WHERE SourceFileStatus = @SourceFileStatus

	END TRY

	BEGIN CATCH
		DECLARE @Errmsg NVARCHAR(4000) = (    
		   SELECT ERROR_MESSAGE() )    
		  ,@ErrorSeverity INT = ERROR_SEVERITY()    
		  ,@ErrorState INT = ERROR_STATE()    
    
		  RAISERROR (    
			@Errmsg    
			,@ErrorSeverity    
			,@ErrorState    
			)   

	END CATCH

END
