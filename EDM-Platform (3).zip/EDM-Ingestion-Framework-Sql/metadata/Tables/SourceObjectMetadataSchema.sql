CREATE TABLE [Metadata].[SourceObjectMetadataSchema](
	[SourceObjectMetadataSchemaID] [int] IDENTITY(1,1) NOT NULL,
	[SourceObjectID] [int] NOT NULL,
	[ColumnName] [nvarchar](200) NOT NULL,
	[ColumnOrder] [int] NOT NULL,
	[DataType] [nvarchar](100) NOT NULL,
	[IsPrimaryKey] [bit] NOT NULL,
	[ColumnFormat] [nvarchar](200) NULL,
	[IsActive] [bit] NULL,
	[IsSchemaEvolved] [bit] NULL,
	[Length] [smallint] NULL,
	[Width] [smallint] NULL,
	[Rule] [nvarchar](1000) NULL,
	[CreatedBy] [nvarchar](100) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](100) NOT NULL,
	[ModifiedOn] [datetime] NOT NULL,
	[IsTokenizable] [bit] NULL,
	[TokenizationAlgorithm] [nvarchar](1000) NULL,
	[SourceDataType] [nvarchar](100) NULL,
	[isnullable] [bit] NULL,
	[SchemaType] [nvarchar](200) NULL,
 CONSTRAINT [PK_SourceObjectMetadataSchema] PRIMARY KEY CLUSTERED 
(
	[SourceObjectMetadataSchemaID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [Metadata].[SourceObjectMetadataSchema] ADD  DEFAULT ((0)) FOR [IsPrimaryKey]
GO

ALTER TABLE [Metadata].[SourceObjectMetadataSchema] ADD  DEFAULT (suser_name()) FOR [CreatedBy]
GO

ALTER TABLE [Metadata].[SourceObjectMetadataSchema] ADD  DEFAULT (switchoffset(sysdatetimeoffset(),'+05:30')) FOR [CreatedOn]
GO

ALTER TABLE [Metadata].[SourceObjectMetadataSchema] ADD  DEFAULT (suser_name()) FOR [ModifiedBy]
GO

ALTER TABLE [Metadata].[SourceObjectMetadataSchema] ADD  DEFAULT (switchoffset(sysdatetimeoffset(),'+05:30')) FOR [ModifiedOn]
GO

ALTER TABLE [Metadata].[SourceObjectMetadataSchema]  WITH CHECK ADD  CONSTRAINT [FK_SourceObjectMetadataSchema_SourceObjectDetail] FOREIGN KEY([SourceObjectID])
REFERENCES [Metadata].[SourceObjectDetail] ([SourceObjectID])
GO

ALTER TABLE [Metadata].[SourceObjectMetadataSchema] CHECK CONSTRAINT [FK_SourceObjectMetadataSchema_SourceObjectDetail]
GO