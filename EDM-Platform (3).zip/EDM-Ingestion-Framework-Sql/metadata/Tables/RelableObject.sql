CREATE TABLE [Metadata].[RelableObject](
	[RelableObjectID] [int] IDENTITY(1,1) NOT NULL,
	[SourceName] [nvarchar](200) NOT NULL,
	[CountryCode] [nvarchar](200) NOT NULL,
	[RenameProperties] [nvarchar](max) NOT NULL,
	[Frequency] [int] NULL,
	[FrequencyDurationUnit] [nvarchar](50) NULL,
	[CreatedBy] [nvarchar](100) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](100) NOT NULL,
	[ModifiedOn] [datetime] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[RelableObjectID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [Metadata].[RelableObject] ADD  DEFAULT (suser_name()) FOR [CreatedBy]
GO

ALTER TABLE [Metadata].[RelableObject] ADD  DEFAULT (switchoffset(sysdatetimeoffset(),'+05:30')) FOR [CreatedOn]
GO

ALTER TABLE [Metadata].[RelableObject] ADD  DEFAULT (suser_name()) FOR [ModifiedBy]
GO

ALTER TABLE [Metadata].[RelableObject] ADD  DEFAULT (switchoffset(sysdatetimeoffset(),'+05:30')) FOR [ModifiedOn]
GO