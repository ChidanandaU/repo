CREATE TABLE [Metadata].[StreamingTableExplodeProperties](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[TargetTableID] [bigint] NOT NULL,
	[ExplodeColumnSequence] [int] NOT NULL,
	[ExplodeColumnJsonPath] [nvarchar](MAX) NOT NULL,
	[NestedObjectType] [nvarchar](50) NULL,
	[ExplodeMode] [nvarchar](50) NULL,
	[CreatedBy] [nvarchar](100) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](100) NULL,
	[ModifiedOn] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [Metadata].[StreamingTableExplodeProperties] ADD  DEFAULT (suser_name()) FOR [CreatedBy]
GO

ALTER TABLE [Metadata].[StreamingTableExplodeProperties] ADD  DEFAULT (getutcdate()) FOR [CreatedOn]
GO

ALTER TABLE [Metadata].[StreamingTableExplodeProperties]  WITH CHECK ADD FOREIGN KEY([TargetTableID])
REFERENCES [Metadata].[StreamingEDMPTableDetails] ([ID])
GO