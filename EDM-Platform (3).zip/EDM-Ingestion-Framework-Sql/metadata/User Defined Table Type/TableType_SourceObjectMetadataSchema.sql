CREATE TYPE [Metadata].[TableType_SourceObjectMetadataSchema] AS TABLE(
	[ColumnName] [nvarchar](100) NULL,
	[SourceDataType] [nvarchar](100) NULL,
	[DataType] [nvarchar](100) NULL,
	[IsNullable] [int] NULL,
	[IsPrimaryKey] [int] NULL,
	[Rules] [nvarchar](max) NULL,
	[Width] [int] NULL,
	[Length] [smallint] NULL,
	[ColumnOrder] [int] NULL,
	[IsActive] [int] NULL,
	[Source] [nvarchar](100) NULL,
	[Country] [nvarchar](100) NULL,
	[ObjectName] [nvarchar](100) NULL,
	[SchemaType] [nvarchar](200) NULL
)
GO