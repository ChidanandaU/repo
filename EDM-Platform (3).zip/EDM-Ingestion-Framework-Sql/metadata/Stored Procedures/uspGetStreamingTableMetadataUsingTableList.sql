CREATE PROCEDURE [Metadata].[uspGetStreamingTableMetadataUsingTableList]  
@ReconTableList [Metadata].[TableType_RealTimeIngestion] READONLY
AS  
-----------------------------------------------------------------------------------------------------------------------  
/****** StoredProcedure:  [Metadata].[uspGetStreamingTableMetadataUsingTableList]  
  Script Date:   2021-07-05  
  Author:		 Saurav Misra 
  Test Execute:  This SP is used to get the Table and Column Properties for a list of tables  
  CMD:     EXEC [Metadata].[uspGetStreamingTableMetadataUsingTableList]  @ReconTableList = '<value>'  
******/  
-----------------------------------------------------------------------------------------------------------------------  
BEGIN  
 BEGIN TRY
  
  SELECT   
    ssd.StreamingSource,  
    ssd.ID AS StreamingSourceID,  
    td.ID AS TargetTableID,  
    td.TargetTableName,  
    td.HasExplode,  
    cd.ColumnName,  
    cd.ColumnOrder,  
    cd.SourceDataType,  
    cd.DestDataType,  
    cd.IsPrimaryKey,  
    cd.PkSequenceNumber,  
    cd.[Length],  
    cd.IsNullable,  
    cd.JsonTag,  
    cd.IsExploded,  
    cd.IsActive,  
    cd.IsSchemaEvolved, 
    cd.IsSchemaEvolvedStandardized,
    cd.IsColumnUpdated,
    cd.IsColumnUpdatedStandardized,
    cd.IsTokenizable,  
    cd.TokenizationAlgorithm,
    cd.TokenizationFunction
  FROM Metadata.StreamingSourceDetails ssd  
  INNER JOIN Metadata.StreamingEDMPTableDetails td 
    ON ssd.ID = td.StreamingSourceID 
  INNER JOIN Metadata.StreamingEDMPColumnDetails cd 
    ON td.ID = cd.TargetTableID
  INNER JOIN @ReconTableList rtl 
    ON rtl.TargetTableName = td.TargetTableName
 END TRY  
  
 BEGIN CATCH  
  DECLARE @Errmsg NVARCHAR(4000) = (  
    SELECT ERROR_MESSAGE()  
    )  
   ,@ErrorSeverity INT = ERROR_SEVERITY()  
   ,@ErrorState INT = ERROR_STATE()  
  
  RAISERROR (  
    @Errmsg  
    ,@ErrorSeverity  
    ,@ErrorState  
   )  
 END CATCH  
END  
GO