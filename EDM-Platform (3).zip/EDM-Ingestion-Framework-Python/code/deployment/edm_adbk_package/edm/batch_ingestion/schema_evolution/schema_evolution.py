import datetime

import pyspark.sql.types as t
import pyspark.sql.functions as f

from edm.utils.const import (
    STANDARDIZE_ZONE_DATA_PATH, TRANSFORMED_ZONE_DATA_PATH)
from edm.utils.general_helper import (
    initialise, get_filename_date_index
)
from edm.utils.logging_utility import get_logger

LOGGER = get_logger(__name__)

class SchemaEvolution:
    '''
    This class is used to handle the schema
    evolution scenarios.
    '''
    def __init__(self, source, country, file_name, spark, dbutils, **kwargs):
        '''
        This instantiates a Param Config Parser Object
        '''
        self.source = source
        self.country = country
        self.file_name = file_name
        self.spark = spark
        self.dbutils = dbutils
        self.spn_credentials = kwargs.get("spn_credentials", None)
        self.kv_name = kwargs.get("kv_name", None)
        self.adls_account_name = kwargs.get("adls_account_name", None)
        self.config_path = kwargs.get("config_path", None)

    def schema_evolution_handling(self):
        '''
        This method is used to run the schema
        evolution scenerios.
        '''
        standardize_data_path = (
            STANDARDIZE_ZONE_DATA_PATH.replace(
                "container",
                self.config['adls_details'][0]['standardized_container_name']
                ).replace(
                    "account",
                    self.config['adls_details'][0]['name']
                ).replace(
                    "source",
                    self.source
                ).replace(
                    "country",
                    self.country
                )
        )

        transformed_data_path = (
            TRANSFORMED_ZONE_DATA_PATH.replace(
                "container",
                self.config['adls_details'][0]['transformed_container_name']
                ).replace(
                    "account",
                    self.config['adls_details'][0]['name']
                ).replace(
                    "source",
                    self.source
                ).replace(
                    "country",
                    self.country
                )
        )

        df = self.get_metainfo_sql()
        self.schema_evolution(df)

    def get_metainfo_sql(self):
        '''Add description'''

        query=f'''(select TOP 100 Percent
            sod.ObjectName, 
            sm.SourceName,
            sm.CountryCode,
            ColumnName,
            ColumnOrder,
            DataType,
            IsPrimaryKey, 
            sob.IsActive,
            sob.IsSchemaEvolved,
            sod.ObjectType
        FROM [Metadata].[sourceobjectschema] sob
        JOIN [Metadata].[SourceObjectDetail] sod 
        ON sob.SourceObjectID=sod.SourceObjectID
        JOIN [metadata].[SourceMaster] AS SM   
            ON sm.SourceID=sod.SourceID
        AND sob.sourceobjectid in (SELECT DISTINCT sourceobjectid FROM [Metadata].[SourceObjectSchema]  where IsSchemaEvolved=1)
        and (sob.isactive=1 OR sob.IsSchemaEvolved=1)
        order by sod.SourceObjectID,sob.columnorder)src'''
        df = self.db_obj.get_df_from_query(query)
        pd_df = df.orderBy('ObjectName', 'ColumnOrder').toPandas()
        return pd_df

    def deleteColumn(self, df, sourcename,country,tablename):
        d = datetime.today()
        delete_df=df[(df.ObjectName==tablename) & (df.IsActive==1)]
        columnlist=','.join(delete_df['ColumnName'])
        if(delete_df['ObjectType'].unique()=='txn'):
            columnlist='RowId,'+columnlist+',date,file,IsActive'
            partitioncolumn='date'
        else :
            columnlist='RowId,'+columnlist+',date,file,StartDate,EndDate,IsActive'  
            partitioncolumn='IsActive'
        # check if table exist or not
        selectstring='SELECT '+columnlist+' FROM '+sourcename+'_'+country+'_'+tablename+'_delta'
        SourceLocation='abfss://transformed@edmsbxseadlk.dfs.core.windows.net/data/'+sourcename+'/'+country+'/'+tablename+'/'
        TargetLocation='abfss://standardized@edmsbxseadlk.dfs.core.windows.net/data/'+sourcename+'/'+country+'/'+tablename+\
                        str(datetime.date.today().year)+str(d.strftime('%m'))+str(d.strftime('%d'))
        SourceParquetLocation='abfss://standardized@edmsbxseadlk.dfs.core.windows.net/'+sourcename+'/'+country+'/'+tablename+'/'
        RefereshString='DROP TABLE IF EXISTS '+sourcename+'_'+country+'_'+tablename
        self.dbutils.fs.cp (SourceLocation,TargetLocation, True) 
        print(selectstring)
        TableData=self.spark.sql(selectstring)
        TableData.cache()
        TableData.write.format('delta').partitionBy(partitioncolumn).mode('overwrite').option('overwriteschema','true').save(SourceLocation)
        self.dbutils.fs.rm(SourceParquetLocation,True)
        TableData.write.format('parquet').partitionBy(partitioncolumn).mode('overwrite').save(SourceParquetLocation)
        self.spark.sql(RefereshString)
        RefereshString='create  table '+sourcename+'_'+country+'_'+tablename+' using parquet options (path \''+SourceParquetLocation+'*/*'+'\')'
        print(RefereshString)
        self.spark.sql(RefereshString)
        RefereshString='DROP TABLE IF EXISTS '+sourcename+'_'+country+'_'+tablename+'_'+str(datetime.date.today().year)+'_'+str(d.strftime('%m'))+'_'+str(d.strftime('%d'))
        self.spark.sql(RefereshString)
        NewTableCreationString='create  table '+sourcename+'_'+country+'_'+tablename+'_'+str(datetime.date.today().year)+'_'+str(d.strftime('%m'))+'_'+str(d.strftime('%d'))+' using DELTA options (path \''+TargetLocation+'\')'
        self.spark.sql(NewTableCreationString)
        params = {
            'SourceName':sourcename,
            'CountryCode': country,
            'TableName': tablename
            }
        schema = 'ETLlog'
        stored_proc = 'uspSchemaEvolutionDeleteColumnUpdate'
        self.db_obj.run_stored_proc(schema, stored_proc, params)

    def schema_evolution(self, df):
        deletedf=df.where("IsActive=0 and IsSchemaEvolved=1").select("ObjectName","SourceName","CountryCode").distinct()
        for row in deletedf.collect():
            self.deleteColumn(df, row["SourceName"],row["CountryCode"],row["ObjectName"])
        updatedf=df.where("IsActive=1 and IsSchemaEvolved=1").select("ObjectName","SourceName","CountryCode").distinct()  
        for row in updatedf.collect():
            CheckIfTableExists=self.spark.sql("show tables '"+row["SourceName"]+'_'+row["CountryCode"]+'_'+row["ObjectName"]+"'")
            print(CheckIfTableExists.count())
            if (CheckIfTableExists.count()==0):
                params = {
                    'SourceName': row["SourceName"],
                    'CountryCode': row["CountryCode"],
                    'TableName': row["ObjectName"]
                    }
                schema = 'ETLlog'
                stored_proc = 'uspSchemaEvolutionDeleteColumnUpdate'
                self.db_obj.run_stored_proc(schema, stored_proc, params)
            else:
                tableName=row["SourceName"]+'_'+row["CountryCode"]+'_'+row["ObjectName"]
                self.ColumnReorderAndDataTypechange(df, row["SourceName"],row["CountryCode"],row["ObjectName"],tableName)
                params = {
                    'SourceName': row["SourceName"],
                    'CountryCode': row["CountryCode"],
                    'TableName': row["ObjectName"]
                    }
                schema = 'ETLlog'
                stored_proc = 'uspSchemaEvolutionUpdate'
                self.db_obj.run_stored_proc(schema, stored_proc, params)

    def ColumnReorderAndDataTypechange(self, df, sourcename,country,objectName,tablename):
        d=datetime.today()
        SourceLocation='abfss://transformed@edmsbxseadlk.dfs.core.windows.net/data/'+sourcename+'/'+country+'/'+objectName+'/'
        SourceParquetLocation='abfss://standardized@edmsbxseadlk.dfs.core.windows.net/'+sourcename+'/'+country+'/'+objectName+'/'
        TargetDeltaLocation='abfss://transformed@edmsbxseadlk.dfs.core.windows.net/data/'+sourcename+'/'+country+'/'+objectName+\
                        str(datetime.date.today().year)+str(d.strftime('%m'))+str(d.strftime('%d'))
        sourcetable='SchemaEvolutionSource_'+tablename
        Existingtable='SchemaEvolutionCurrent_'+tablename
        RefereshString='DROP TABLE IF EXISTS '+tablename
        #Checking for the column datatype 
        Columnlist='describe Table '+tablename+'_delta'
        columnschema=self.spark.sql(Columnlist)
        columnschema.createOrReplaceTempView(sourcetable)
        df.filter(f.col("ObjectName")==tablename).createOrReplaceTempView(Existingtable)
        ColumnAlterCheckString='''SELECT * FROM '''+Existingtable+''' as  et
                                        join '''+sourcetable +''' as st
                                            on st.col_name=et.ColumnName
                                            and lower(et.DataType)!=lower(st.data_type)'''
        ColumnDataTypeChange=self.spark.sql(ColumnAlterCheckString)
        AlterDf=df[(df.ObjectName==objectName) & (df.IsActive==1)]
        selectcolumnlist=','.join(AlterDf['ColumnName'])
        NewColumnList=df[(df.ObjectName==objectName) & (df.IsActive==1)]
        NewColumnList['ColumnWithDataType']=NewColumnList['ColumnName']+' '+NewColumnList['DataType']
        columnlist=','.join(NewColumnList[(NewColumnList.ObjectName==objectName) & (NewColumnList.IsActive==1)].ColumnWithDataType)
        if(AlterDf['ObjectType'].unique()=='txn'):
            selectstring='SELECT RowID,'+selectcolumnlist+',date,file FROM '+tablename+'_delta'
            columnlist='RowID String,'+columnlist+',date string,file string,IsActive String'
        else:
            selectstring='SELECT RowID,'+selectcolumnlist+',date,file,StartDate,EndDate,IsActive FROM '+tablename+'_delta'
            columnlist='RowID String,'+columnlist+',date string,file string,StartDate timestamp,EndDate timestamp,IsActive string'
        if(ColumnDataTypeChange.count()==0):
            print(columnlist)
            AlterString='Alter Table '+tablename+'_delta REPLACE COLUMNS (  '+ columnlist+')'
            print(AlterString)
            self.spark.sql(AlterString)
            print(selectstring)
            TableData=self.spark.sql(selectstring)
            TableData.write.format('parquet').mode('overwrite').save(SourceParquetLocation)
            self.spark.sql(RefereshString)
            RefereshString='create  table '+tablename+' using parquet options (path \''+SourceParquetLocation+'\')'
            self.spark.sql(RefereshString)
        else:
            self.dbutils.fs.cp (SourceLocation,TargetDeltaLocation, True)  
            AlterString='Alter Table '+tablename+'_delta REPLACE COLUMNS (  '+ columnlist+')'
            self.spark.sql(AlterString)
            print(AlterString)
            TableData=self.spark.sql(selectstring)
            TableData.write.format('parquet').mode('overwrite').save(SourceParquetLocation)
            self.spark.sql(RefereshString)
            RefereshString='create  table '+tablename+' using parquet options (path \''+TargetDeltaLocation+'\')'
            self.spark.sql(RefereshString)


    def run(self):
        '''
        This method is used to run the schema evolution
        process end-to-end.
        '''
        LOGGER.info("Starting Schema evolution process")
        LOGGER.info("Started Initialisation")
        self.config, self.db_obj = initialise(
            self.spark, self.spn_credentials, self.kv_name,
            self.adls_account_name, self.config_path
        )
        LOGGER.info("Ended Initialisation")
        LOGGER.info("Starting Processing ")
        self.schema_evolution_handling()