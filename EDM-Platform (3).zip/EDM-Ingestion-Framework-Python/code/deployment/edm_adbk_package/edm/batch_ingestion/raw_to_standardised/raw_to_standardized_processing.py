import json
import datetime
import uuid

from edm.batch_ingestion.landing_to_raw.landing_to_raw_processor import (
    LandingToRawProcessor
)
from edm.utils.const import (
     RAW_ZONE_DATA_PATH)
from edm.utils.general_helper import (
    initialise, get_filename_date_index
)
from edm.utils.logging_utility import get_logger
from pyspark.sql import types as t
from pyspark.sql import functions as f

LOGGER = get_logger(__name__)

class RawToStandardizeProcessor:
    '''
    This class is used to process the data file
    from Raw to Standardize zone after applying
    all the necessary validations.
    '''

    def __init__(self, source_id, source_object_id, spark, dbutils, **kwargs):
        '''
        This instantiates a Raw To Standardized Object
        '''
        self.source_id = source_id
        self.source_object_id = source_object_id
        self.spark = spark
        self.dbutils = dbutils
        self.spn_credentials = kwargs.get("spn_credentials", None)
        self.kv_name = kwargs.get("kv_name", None)
        self.adls_account_name = kwargs.get("adls_account_name", None)
        self.config_path = kwargs.get("config_path", None)

    def raw_to_standardize_processor(self):
        '''
        This method is used to process the data files
        present in raw zone and move it to standardized
        layer.
        '''
        # Getting info of file to be processed.
        query = (
            f"select * from edmsbxseasqldb.ETLlog.SourceFileProcessLog where \
            IsRawtoStandardisedProcessed = 0 and IsLandingToRawProcessed = 1 \
            and SourceID={self.source_id} and \
            SourceObjectID={self.source_object_id} and \
            SourceFileStatus='Completed'"
        )
        results = self.db_obj.run_sql_query(query)

        # Defining year, month, date for partitioning
        d = datetime.date.today()
        year = str(d.year)
        month = str(d.strftime('%m'))
        date = str(d.strftime('%d'))

        # Processing all the required files
        for file_info in results[0]:
            pipeline_log_id = file_info[1]
            source_file_process_log_id = file_info[0]
            file_name = file_info[2]
            source_count = file_info[3]
            source_path = file_info[-1]

            # Getting Source name & country code using source id
            query = (
                f"select SourceName, CountryCode from [Metadata].[SourceMaster] \
                 where SourceID={self.source_id}"
            )
            results = self.db_obj.run_sql_query(query)
            source_name = results[0][0][0]
            country_name = results[0][0][1]
            source_path = source_path.split(country_name+'/')[1]

            # Reading data from source master and source object tables
            query = (
                f"select sm.CountrySourceProperties, sm.SourceType, \
                sod.ObjectName ,sod.ObjectType ,sod.ObjectProperties \
                from Metadata.SourceMaster sm join \
                Metadata.SourceObjectDetail sod on \
                sod.SourceId=sm.SourceID where \
                SourceObjectID={self.source_object_id}"
            )
            results = self.db_obj.run_sql_query(query)
            cs_properties = json.loads(results[0][0][0])
            source_type = results[0][0][1]
            object_name = results[0][0][2]
            object_type = results[0][0][3]
            os_properties = json.loads(results[0][0][4])

            # Get date index
            date_index = get_filename_date_index(file_name)

            # Defining source path
            data_source = (
                RAW_ZONE_DATA_PATH.replace(
                    'account', self.adls_account_name
                ).replace(
                    "source",
                    source_name
                ).replace(
                    "country",
                    country_name
                )
            )
            source_path = (
               f'{data_source}/{source_path}'
            )

            # Reading data
            schema, schema_info, col_to_cast = LandingToRawProcessor \
                .object_schema_width_rules(self, self.source_object_id)
            data = self.spark.read \
                .option("parserLib", "univocity") \
                .option("ignoreTrailingWhiteSpace", "true") \
                .csv(source_path + '/*.snappy', schema=schema, header=True)

            for key, value in col_to_cast.items():
                data = data.withColumn(key, f.col(key).cast(value))

            # Control File Processing
            LOGGER.info("Control file processing started.")
            ctrl_file = cs_properties['control_file']
            if ctrl_file in ('true', 'True'):
                # Defining control file path
                control_file_path = (
                    RAW_ZONE_DATA_PATH.replace(
                        'account', self.adls_account_name
                    ).replace(
                        "data", "control"
                    ).replace(
                        "source", source_name
                    ).replace(
                        "country", country_name
                    )
                )
                hschema, hschema_info, hcol_to_cast = LandingToRawProcessor \
                    .object_schema_width_rules(
                        self,
                        self.source_object_id,
                        'headercolschema'
                    )
                tschema, tschema_info, tcol_to_cast = LandingToRawProcessor \
                    .object_schema_width_rules(
                        self,
                        self.source_object_id,
                        'trailercolschema'
                        )
                control_data = self.spark.read \
                    .option("parserLib", "univocity") \
                    .option("ignoreTrailingWhiteSpace", "true") \
                    .csv(f'{control_file_path}/{source_name}_{country_name}*')
                h_data = self.spark \
                    .createDataFrame(
                        control_data.where(f.col('_c0') == 'H').rdd,
                        schema=hschema
                        )
                for key, value in hcol_to_cast.items():
                    if 'DECIMAL' or 'decimal' in value:
                        continue
                    else:
                        h_data = h_data.withColumn(key, f.col(key).cast(value))
                trailer = control_data.where(f.col('_c0') == 'T')
                countNullValues = trailer \
                    .select(
                        [f.count(f.when(f.col(a).isNull(), a)).alias(a) for a in trailer.columns]
                        ).collect()[0].asDict()
                columnDrop = [d for d, n in countNullValues.items() if n > 0]
                trailer = trailer.drop(*columnDrop)
                t_data = self.spark.createDataFrame(
                    trailer.rdd,
                    schema=tschema
                    )
                for key, value in tcol_to_cast.items():
                    if 'DECIMAL' or 'decimal' in value:
                        continue
                    else:
                        t_data = t_data.withColumn(key, f.col(key).cast(value))
                hdata_dict = h_data.collect()
                tdata_dict = t_data.collect()
                for record in range(len(hdata_dict)):
                    metadata = {
                        'header': hdata_dict[record].asDict(),
                        'trailer': tdata_dict[record].asDict()
                    }
                    table_name = metadata['header']['table'].lower()
                    rowcount = metadata['trailer']['ROWCOUNT']
                    businessdate = metadata['header']['hDate']
                    query = (
                        f"select SourceObjectID from \
                        Metadata.SourceObjectDetail where \
                        ObjectName = '{table_name}'"
                    )
                    results = self.db_obj.run_sql_query(query)
                    if results:
                        object_id = results[0][0]
                        param = (
                            {'SourceObjectID': object_id,
                             'Metadata': json.dumps(metadata),
                             'RowCount': rowcount,
                             'BusinessDate': businessdate}
                        )
                        self.db_obj.run_stored_proc(
                            'ETLlog',
                            'SourceFileHeaderTrailerLogProc',
                            params=param
                        )

            # Row Count Validation
            LOGGER.info("Row count validation started.")
            query = (
                        f"select [RowCount] from \
                        [ETLlog].[SourceFileHeaderTrailerLog] where \
                        SourceObjectID = {self.source_object_id} \
                        and IsActive = 1"
                    )
            results = self.db_obj.run_sql_query(query)
            df_count = data.count()
            skip_row_flag = True
            if results[0]:
                received_row_count = results[0][0][0]
                if 'skip.row.count' in cs_properties:
                    if cs_properties['skip.row.count'].lower() == 'false':
                        skip_row_flag = False
                    else:
                        if results:
                            skip_row_flag = False
                        else:
                            LOGGER.info("Skip Row count is True.")
                else:
                    if results:
                        skip_row_flag = False

            if not skip_row_flag:
                if results:
                    if df_count != received_row_count:
                        LOGGER.info(
                            '''
                            Rejecting the file due to row count
                            mismatch.
                            '''
                        )
                        # TODO: Reject the file
                        break
                    else:
                        LOGGER.info("Row count validation successful !!.")
                else:
                    LOGGER.info(
                        '''
                        Rejecting the file as skip row count is false
                        and metadata info is not available.
                        '''
                    )
                    # TODO: Reject the file
                    break

            # Column count validation
            LOGGER.info("Column count validation started.")
            col_count_from_properties = len(schema_info)
            if col_count_from_properties == len(data.columns):
                LOGGER.info("Column count validation successful.")
            else:
                LOGGER.info(
                    "Rejecting the file due to column length mismatch."
                )
                # TODO: Move to reject directory
                break

            # Adding columns to data
            LOGGER.info("Adding necessary columns to data.")
            uuidUdf = f.udf(lambda: str(uuid.uuid4()), t.StringType())
            file_content = file_name.split('_')
            df_added_columns = data.withColumn(
                "date", f.lit(file_content[date_index].strip('.csv'))
                ) \
                .withColumn(
                    'time', f.expr(
                        "reflect('java.time.LocalDateTime', 'now')"
                    ).cast("string")
                ) \
                .withColumn('RowID',  uuidUdf()) \
                .withColumn('file', f.lit(file_name))

            df_added_columns = df_added_columns\
                .withColumn('time', f.translate(f.col("time"), "-:.", ""))
            df_added_columns = df_added_columns\
                .withColumn('time', f.trim(f.col('time')))
            df_added_columns = df_added_columns\
                .withColumn(
                    'RowID', f.concat(
                        f.col('time'), f.lit('_'), f.col('RowID')
                    )
                )
            df_added_columns = df_added_columns\
                .select(data.columns+['date', 'RowID', 'file'])

            # Date Columns Transformation
            LOGGER.info("Date columns transformation started.")
            # TODO: Integrate ColumnTransformationRules.xml
            func = f.udf(
                lambda x: datetime.datetime.strptime(x, '%Y%m%d'), t.DateType()
            )
            df_added_columns = df_added_columns \
                .withColumn(
                    'date', f.date_format(func(f.col('date')), 'MM-dd-yyy')
                )
            LOGGER.info("Date columns transformation completed.")

            # TODO : Default capturing, replacement & logging.

            LOGGER.info("Generating necessary info for validations.")
            pk_stmt = ' is NULL) '
            dtype_list = []
            for items in schema_info:
                col_name = items[0]
                col_type = items[1]
                # Generating pk statement
                if items[4]:
                    if pk_stmt == ' is NULL) ':
                        pk_stmt = '(' + col_name + pk_stmt
                    else:
                        pk_stmt += f'or ({col_name} is NULL) '
                # Generating datatype validation tuple
                dtype_list.append((col_name, col_type.lower()))

            # Key Columns Check
            LOGGER.info("Key columns check started.")
            invalid_rec_dict = {}
            key_column_flag = {}
            df_invalid_col = None
            if pk_stmt != ' is NULL) ':
                df_key_col_check = df_added_columns \
                    .filter(pk_stmt)
                if df_key_col_check.count() > 0:
                    col_list = list(df_key_col_check.columns)
                    df_invalid_col = df_key_col_check\
                        .select('RowID',
                                f.to_json(
                                    f.struct(col_list)
                                ).alias("ErrorData")
                                )
                    df_invalid_col = df_invalid_col \
                        .withColumn(
                            'PipeLineId',
                            f.lit(pipeline_log_id)) \
                        .withColumn(
                            'SourceObjectId',
                            f.lit(self.source_object_id)) \
                        .withColumn(
                            'SourceFileProcessLogId',
                            f.lit(source_file_process_log_id)) \
                        .withColumn(
                            'ErrorCode',
                            f.lit('PK Null Check')) \
                        .withColumn(
                            'ErrorDescription',
                            f.lit('Primary Key column are Null')
                            )
                    df_invalid_col = df_invalid_col.toPandas()
            LOGGER.info("Key columns check completed.")

            # Data Type Validation
            LOGGER.info("Data Type Validation started.")
            df_dtype_val = df_added_columns.dtypes
            dtype_validation = set(df_dtype_val).difference(set(dtype_list))
            if dtype_validation == {('date', 'string'), ('RowID', 'string'), ('file', 'string')}:
                LOGGER.info('Data Type Validation successful')
            else:
                LOGGER.info('Data Type Validation falied')
                # TODO: Log the invalid columns and datatypes

            # Max Length Check
            LOGGER.info('Max Length check started')
            max_length_inv_list = []
            for item in schema_info:
                col_name = item[0]
                col_type = item[1]
                col_len = item[5]
                if (col_len is not None) and col_type == 'string':
                    len_col_name = col_name + '_len'
                    df_length = df_added_columns \
                        .withColumn(len_col_name, f.length(f.col(col_name)))
                    first_value = df_length \
                        .orderBy(len_col_name) \
                        .select(len_col_name) \
                        .first()[len_col_name]
                    if first_value is not None:
                        ordered_df = df_added_columns\
                            .withColumn(
                                len_col_name, f.length(f.col(col_name))
                            ).orderBy(len_col_name).select(len_col_name)
                        first_rec = (ordered_df.first())[len_col_name]
                        if col_len >= float(first_rec):
                            df_records = df_length.where(
                                f.col(len_col_name) > col_len
                            )
                            ml_data_dict = (
                                lambda row: row.asDict(),
                                df_records.collect().map()
                            )
                            for i in ml_data_dict:
                                max_length_inv_list.append(json.dumps(i))
            invalid_rec_dict['Max Length Check'] = max_length_inv_list

            # Not Null check

            # Error Logging
            schema = 'ETLlog'
            stored_proc = 'uspInsertFileProcessErrorLog'
            table_type = 'TableType_FileProcessErrorLog'

            if df_invalid_col is not None:
                self.db_obj.insert_data_from_df(
                                    schema,
                                    stored_proc,
                                    df_invalid_col,
                                    table_type
                                )

            if invalid_rec_dict['Max Length Check']:
                for key, value in invalid_rec_dict.items():
                    params = {
                        'PipeLineId': pipeline_log_id,
                        'SourceObjectId': self.source_object_id,
                        'SourceFileProcessLogId': source_file_process_log_id,
                        'RowID': i['RowID'],
                        'ErrorCode': key,
                        'ErrorDescription': 'Primary Key column is Null',
                        'ErrorData': json.dumps(i)
                        }

                    self.db_obj.run_stored_proc(schema, stored_proc, params)
                    key_column_flag[items[0]] = 'Failed'

            # Source Reconciliation
            LOGGER.info('Source Reconciliation started')
            if ('recon' or 'RECON') in file_name:
                self.recon(df_added_columns)
            

            part_col = None
            if object_type == 'delta':
                final_df = self.master_data_load(
                    df_added_columns,
                    source_name,
                    country_name,
                    object_name,
                    source_count,
                    pipeline_log_id,
                    source_file_process_log_id
                    )
                if final_df == 'data saved':
                    continue
                else:
                    part_col = 'EndDate'
            else:
                df_added_columns = df_added_columns.withColumn('isDeleted', f.lit(0))
                final_df = df_added_columns
                part_col = 'date'            
            
            destination = f'abfss://transformed@edmsbxseadlk.dfs.core.windows.net/data/{source_name}/{country_name}/{object_name}/'
            destination_std = f'abfss://standardized@edmsbxseadlk.dfs.core.windows.net/{source_name}/{country_name}/{object_name}/'

            # Saving data in delta format
            final_df.coalesce(1).write \
            .format("delta") \
            .mode("append") \
            .option("mergeSchema", "true") \
            .partitionBy(part_col) \
            .save(destination)
            
            # Saving data in parquet format
            final_df.coalesce(1).write \
            .option("header","true") \
            .format("parquet") \
            .mode("append") \
            .option("mergeSchema", "true") \
            .partitionBy(part_col) \
            .save(destination_std)
            
            #Creating parquet tables
            parquet_table = source_name + '_' + country_name + '_' + object_name
            parquet_table = parquet_table.replace('$','')
            self.spark.sql(f'drop table if exists {parquet_table}')
            self.spark.sql(f"CREATE TABLE {parquet_table} USING PARQUET OPTIONS(path '{destination_std}/*/*.*')")

            # creating delta tables
            delta_table = source_name + '_' + country_name + '_' + object_name + '_delta'
            delta_table = delta_table.replace('$','')
            self.spark.sql(f'drop table if exists {delta_table}')
            self.spark.sql(f"CREATE TABLE {delta_table} USING DELTA OPTIONS(path '{destination}/')")
            
            # updating source file process log table
            self.update_source_db(final_df, source_count, pipeline_log_id, source_file_process_log_id)

    def recon(self, df_added_columns):
        func =  f.udf (lambda x: datetime.datetime.strptime(x, '%m-%d-%Y'), t.DateType())
        df_recon = df_added_columns.withColumn('date', f.date_format(func(f.col('date')), 'yyyMMdd'))    
        for row in map(lambda row: row.asDict(), df_recon.collect()):
            recon_status = 'Failed'
            source_name = row['src_stm']
            country_name = row['src_ctry']
            table_name = row['tbl_name'].lower()
            row_count = row['row_cnt']
            checksum_feild = row['chksum_fld_nm']
            checksum_tot = row['chksum_tot']
            date_fld = row['date_fld_nm']
            delta_table = source_name + '_' +country_name + '_' + table_name
            df = self.spark.sql('select count(*) from {} where date="{}"'.format(delta_table, date_fld))
            if df.first()['count(1)'] == row_count:
                recon_status = 'Success'     
            source_query = f"select row_cnt from {source_name}_{country_name}_{table_name} where ods='{date_fld}' and TBL_NAME='{delta_table}'"
            target_query = f"select count(*) from {source_name}_{country_name}_{table_name} where date='{date_fld}'"
            target_cnt = df.count()
            business_date = date_fld
            identifier = f'{source_name}_{country_name}_{table_name}_rowcount'
            params = {
            'SourceID':self.source_id,
            'SourceObjectID': self.source_object_id,
            'identifier': identifier,
            'SourceQuery': source_query, 
            'SourceValue': row_count, 
            'TargetQuery': target_query,
            'TargetValue': target_cnt,
            'BusinessDate': business_date,
            'SourceReconStatus': recon_status,
            'LastSourceReconDateTime': 'None'
            }
            schema = 'Recon'
            stored_proc = 'uspInsertEODRecon'
            self.db_obj.run_stored_proc(schema, stored_proc, params)

    def update_source_db(
        self,
        final_df,
        source_count, 
        pipeline_log_id, 
        source_file_process_log_id
        ):
        target_count = final_df.count()
        error_count = source_count - target_count
        params = {
            'PipelineLogID':pipeline_log_id,
            'SourceFileProcessLogID': source_file_process_log_id,
            'SourceCount': source_count,
            'TargetCount': target_count, 
            'ErrorCount': error_count, 
            'IsLandingToRawProcessed': 1,
            'IsRawtoStandardisedProcessed': 1,
            'sourceObjectID': self.source_object_id,
            'sourceID': self.source_id,
            'PipelineStatus': 'Succeeded'
            }
        schema = 'ETLlog'
        stored_proc = 'uspUpdatePipelineLog'
        self.db_obj.run_stored_proc(schema, stored_proc, params)

    def master_data_load(
        self,
        df,
        source_name,
        country_name,
        object_name,
        source_count,
        pipeline_log_id,
        source_file_process_log_id
        ):
        '''
        This function is used to perform SCD type 2
        on master data.
        '''
        destination = f'abfss://transformed@edmsbxseadlk.dfs.core.windows.net/data/{source_name}/{country_name}/{object_name}/'
        destination_std = f'abfss://standardized@edmsbxseadlk.dfs.core.windows.net/{source_name}/{country_name}/{object_name}/'
        # Defining table name
        table_name = source_name + '_' + country_name + '_' + object_name

        # Adding StartDate, EndDate, isActive columns to master data
        df=df \
            .withColumn('StartDate', f.current_timestamp()) \
            .withColumn('EndDate', f.lit('9999_12_31 11_31_08')) \
            .withColumn('isActive', f.lit('1'))    
        df = df \
            .withColumn('StartDate', f.to_timestamp("StartDate", "yyyy_MM_dd HH_mm_ss")) \
            .withColumn('EndDate', f.to_timestamp("EndDate", "yyyy_MM_dd HH_mm_ss"))

        # Query to fetch all the columns for particular source, country and object 
        get_columns='''SELECT soc.ColumnName,soc.IsPrimaryKey
            FROM Metadata.SourceMaster sm with(nolock)
            JOIN Metadata.SourceObjectDetail sod with(nolock)
            ON sm.SourceID=sod.SourceID
            JOIN Metadata.SourceObjectSchema soc with(nolock)
            ON sod.SourceObjectID=soc.SourceObjectID 
            AND soc.columnname!='DUMMY'
            AND sm.SourceName=\''''+source_name+\
            '''\' AND sm.CountryCode=\''''+country_name+\
            '''\' AND sod.ObjectName=\''''+object_name+\
            '''\' AND soc.IsActive=1'''

        object_cols = self.db_obj.get_df_from_query(get_columns)
        object_cols_sdf = self.spark.createDataFrame(object_cols)

        column_list = (
            ','.join(object_cols["ColumnName"])+',StartDate,EndDate,isActive, file, RowID, date'
            )
        src_column_list = (
            'src.'+',src.'.join(object_cols["ColumnName"])+',current_timestamp(),src.EndDate,src.isActive, src.file, src.RowID, src.date'
        )
        src_column_select_list = (
            'src.' + ',src.'.join(object_cols["ColumnName"]) + ',current_timestamp() as StartDate,src.EndDate,src.isActive, src.file, src.RowID, src.date'
        )
        key_columns = object_cols_sdf \
            .filter("IsPrimaryKey==1") \
            .withColumn(
                'KeyColumnCondition',f.concat(f.lit('tar.'),f.col("ColumnName"),f.lit('=src.'),f.col("ColumnName"))
            ) \
            .select("ColumnName",'KeyColumnCondition').toPandas()
        Key_column_condition_string=' and '.join(key_columns["KeyColumnCondition"])
        non_key_columns=object_cols_sdf \
            .filter("IsPrimaryKey==0") \
            .withColumn(
                'KeyColumnCondition', f.concat(f.lit('tar.'),f.col("ColumnName"),f.lit('=src.'),f.col("ColumnName"))
            ) \
            .select('ColumnName','KeyColumnCondition').toPandas()
        non_key_columns_rowhash_list_srcstring=',"|",'.join('src.'+non_key_columns["ColumnName"])
        non_key_columns_rowhash_list_string=',"|",'.join('tar.'+non_key_columns["ColumnName"])

        table_name=table_name.replace('$','')
        delta_table_name = table_name+'master'
        df.createOrReplaceTempView(delta_table_name)
        check_if_table_exists = self.spark.sql("show tables '"+table_name+"_delta'") 
        if (check_if_table_exists.count()==0):
            df=df.withColumn("EndDate_", df["EndDate"])
            return df
        else:
            df_overwrite_schema=df.filter("1=2")
            df_overwrite_schema=df_overwrite_schema.withColumn("EndDate_", df["EndDate"])
            df_overwrite_schema.write \
            .format("delta") \
            .mode("append") \
            .option("mergeSchema", "true") \
            .partitionBy('EndDate') \
            .save(
                destination
            )
            merge_statement = f'''
            Merge INTO {table_name}_delta as tar using {delta_table_name} as src 
            on {Key_column_condition_string} WHEN Matched and 
            sha2(concat_ws({non_key_columns_rowhash_list_srcstring}),256) 
            != sha2(concat_ws({non_key_columns_rowhash_list_string}),256) 
            and tar.isActive=1 then update SET EndDate=current_timestamp(),isActive=0 
            When Not Matched THEN INSERT ({column_list}) values ({src_column_list})'''
            self.spark.sql(merge_statement)
            select_statement = f'''
            Select {src_column_select_list} FROM {delta_table_name}
            as src LEFT JOIN {table_name}_delta as tar ON 
            {Key_column_condition_string} AND tar.isActive=1  
            Where tar.isActive is null
            '''
            df_append = self.spark.sql(select_statement)
            df_append=df_append.withColumn("EndDate_", df["EndDate"])
            df_append.write \
            .format('delta') \
            .mode("append") \
            .partitionBy('EndDate') \
            .save(
                destination
            )
            self.spark.sql(f'Drop Table if exists {table_name}')
            latest_data = self.spark.sql(f'select * from {table_name}_delta')
            latest_data.write \
            .format("parquet") \
            .mode("overwrite") \
            .partitionBy('EndDate') \
            .save(destination_std)
            self.spark.sql(
                    f"""
                    CREATE TABLE {table_name} USING Parquet 
                    OPTIONS(path 'abfss://standardized@edmsbxseadlk.dfs.core.windows.net/{source_name}/{country_name}/{object_name}/*/*.*')
                    """
                    )
            self.update_source_db(latest_data, source_count, pipeline_log_id, source_file_process_log_id)
            return('data saved')

    def run(self):
        '''
        This method is used to run the raw to standardize pipeline
        end-to-end.
        '''
        LOGGER.info("Starting Landing to Raw pipeline")
        LOGGER.info("Started Initialisation")
        self.config, self.db_obj = initialise(
            self.spark, self.spn_credentials, self.kv_name,
            self.adls_account_name, self.config_path
        )
        LOGGER.info("Ended Initialisation")
        LOGGER.info("Starting Processing Data Files")
        self.raw_to_standardize_processor()
