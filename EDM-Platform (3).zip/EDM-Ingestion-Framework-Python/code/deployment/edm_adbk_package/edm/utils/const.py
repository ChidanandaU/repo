LANDING_ZONE_CONFIG_PATH = (
    'wasbs://container@account.blob.core.windows.net/config/source/country'
)
LANDING_ZONE_DATA_PATH = (
    'wasbs://container@account.blob.core.windows.net/data/source/country'
)
RAW_ZONE_DATA_PATH = (
    'abfss://raw@account.dfs.core.windows.net/data/source/country'
)
RAW_ZONE_CONFIG_PATH = (
    'abfss://raw@account.dfs.core.windows.net/config'
)
STANDARDIZE_ZONE_DATA_PATH = (
    'abfss://standardized@account.dfs.core.windows.net/source/country'
)
TRANSFORMED_ZONE_DATA_PATH = (
    'abfss://transformed@account.dfs.core.windows.net/data/source/country'
)
SQL_ADBK_DTYPE_MAP = {
    "DECIMAL": "decimal", "VARCHAR": "string",
    "CHAR": "string", "FLOAT": "double", "DOUBLE": "double",
    "INT": "integer", "STRING": "string", "BIGINT": "string"}

REALTIME_DTYPE_MAP = {
    "STRING": "VARCHAR", 'INT': 'INT', "DOUBLE": "DECIMAL", "CLOB": "VARCHAR"
}

REALTIME_LANDING_PATH = (
    'abfss://raw@account.dfs.core.windows.net/'
)
REALTIME_STAGING_DELTA_PATH = (
    'abfss://staging@account.dfs.core.windows.net/realtime/')

REALTIME_STANDARDIZED_DELTA_PATH = (
    'abfss://standardized@account.dfs.core.windows.net/realtime/')

TOKENISATION_ALGO_NUMERALS = 'TE_N_S23_L0R0_LP_AST'
TOKENISATION_ALGO_STRING = 'TE_A_N_L0R0_S23_Y_AST'
CONTROLFILE_TABLE_MAPPING_FILENAME = 'controlfiletablemapping.csv'

GET_STREAMING_SOURCE_SCHEMA_DETAILS = "SELECT SchemaName,\
SchemaGuid \
FROM Metadata.EventHubSchemaRegistryMaster \
WHERE SchemaName = '{}'"

GET_STREAMING_TABLE_COLUMN_PROP = "SELECT ssd.StreamingSource, \
ssd.ID AS StreamingSourceID, td.ID AS TargetTableID, \
td.TargetTableName,  td.HasExplode,  cd.ColumnName,  cd.ColumnOrder, \
cd.SourceDataType,cd.DestDataType,cd.IsPrimaryKey, \
cd.PkSequenceNumber,cd.Length,  cd.IsNullable, cd.JsonTag, \
cd.IsExploded, cd.IsActive,cd.IsSchemaEvolved,cd.IsSchemaEvolvedStandardized, \
cd.IsColumnUpdated,cd.IsColumnUpdatedStandardized,cd.IsTokenizable,cd.TokenizationAlgorithm, \
cd.TokenizationFunction \
FROM Metadata.StreamingSourceDetails ssd \
INNER JOIN Metadata.StreamingEDMPTableDetails td ON ssd.ID = td.StreamingSourceID \
INNER JOIN Metadata.StreamingEDMPColumnDetails cd ON td.ID = cd.TargetTableID \
WHERE ssd.StreamingSource = '{}'"

GET_STREAMING_TABLE_EXPLODE_PROP = "SELECT DISTINCT StreamingSource, \
STD.TargetTableName,SEP.ExplodeColumnSequence, \
SEP.ExplodeColumnJsonPath,SEP.NestedObjectType \
FROM Metadata.StreamingSourceDetails SSD \
INNER JOIN Metadata.StreamingEDMPTableDetails STD ON SSD.ID=STD.StreamingSourceID \
INNER JOIN Metadata.StreamingTableExplodeProperties SEP ON STD.ID= SEP.TargetTableID \
WHERE SSD.StreamingSource='{}' AND STD.TargetTableName='{}'"
