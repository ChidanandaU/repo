import json
import datetime
import uuid

from edm.batch_ingestion.landing_to_raw.landing_to_raw_processor import (
    LandingToRawProcessor
)
from edm.utils.const import (
     RAW_ZONE_DATA_PATH)
from edm.utils.general_helper import (
    initialise, get_filename_date_index
)
from edm.utils.logging_utility import get_logger

import pyspark.sql.types as t
import pyspark.sql.functions as f

LOGGER = get_logger(__name__)


class RawToStandardizeProcessor:
    '''
    This class is used to process the data file
    from Raw to Standardize zone after applying
    all the necessary validations.
    '''

    def __init__(self, source_id, source_object_id, spark, dbutils, **kwargs):
        '''
        This instantiates a Raw To Standardized Object
        '''
        self.source_id = source_id
        self.source_object_id = source_object_id
        self.spark = spark
        self.dbutils = dbutils
        self.spn_credentials = kwargs.get("spn_credentials", None)
        self.kv_name = kwargs.get("kv_name", None)
        self.adls_account_name = kwargs.get("adls_account_name", None)
        self.config_path = kwargs.get("config_path", None)

    def raw_to_standardize_processor(self):
        '''
        This method is used to process the data files
        present in raw zone and move it to standardized
        layer.
        '''
        # Getting info of file to be processed.
        query = (
            f'select * from edmsbxseasqldb.ETLlog.SourceFileProcessLog where \
            IsRawtoStandardisedProcessed = 0 and IsLandingToRawProcessed = 1 \
            and SourceID={self.source_id} and \
            SourceObjectID={self.source_object_id}'
        )
        results, columns = self.db_obj.run_sql_query(query)

        # Defining year, month, date for partitioning
        d = datetime.date.today()
        year = str(d.year)
        month = str(d.strftime('%m'))
        date = str(d.strftime('%d'))

        # Processing all the required files
        for file_info in results:
            pipeline_log_id = file_info[1]
            pipeline_status = 'Succeeded'
            source_file_process_log_id = file_info[0]
            file_name = file_info[2]

            # Getting Source name & country code using source id
            query = (
                f"select SourceName, CountryCode from [Metadata].[SourceMaster] \
                 where SourceID={self.source_id}"
            )
            results, columns = self.db_obj.run_sql_query(query)
            source_name = results[0][0]
            country_name = results[0][1]

            # Reading data from source master and source object tables
            query = (
                f"select sm.CountrySourceProperties, sm.SourceType, \
                sod.ObjectName ,sod.ObjectType ,sod.ObjectProperties \
                from Metadata.SourceMaster sm join \
                Metadata.SourceObjectDetail sod on \
                sod.SourceId=sm.SourceID where \
                SourceObjectID={self.source_object_id}"
            )
            results, columns = self.db_obj.run_sql_query(query)
            cs_properties = json.loads(results[0][0])
            source_type = results[0][1]
            object_name = results[0][2]
            object_type = results[0][3]
            os_properties = json.loads(results[0][4])

            # Get date index
            date_index = get_filename_date_index(file_name)

            # Defining source path
            data_source = (
                RAW_ZONE_DATA_PATH.replace(
                    'account', self.adls_account_name
                ).replace(
                    "source",
                    source_name
                ).replace(
                    "country",
                    country_name
                )
            )
            source_path = (
               f'{data_source}/{object_name}/{year}/{month}/{date}/{file_name}'
            )

            # Reading data
            schema, schema_info, col_to_cast = LandingToRawProcessor \
                .object_schema_width_rules(self, self.source_object_id)
            data = spark.read \
                .option("parserLib", "univocity") \
                .option("ignoreTrailingWhiteSpace", "true") \
                .csv(source_path + '/*.snappy', schema=schema, header=True)
            for key, value in col_to_cast.items():
                data = data.withColumn(key, f.col(key).cast(value))

            # Control File Processing
            LOGGER.info("Control file processing started.")
            ctrl_file = cs_properties['control_file']
            if ctrl_file in ('true', 'True'):
                # Defining control file path
                control_file_path = (
                    RAW_ZONE_DATA_PATH.replace(
                        'account', self.adls_account_name
                    ).replace(
                        "data", "control"
                    ).replace(
                        "source", source_name
                    ).replace(
                        "country", country_name
                    )
                )
                hschema, hschema_info, hcol_to_cast = LandingToRawProcessor \
                    .object_schema_width_rules(
                        self,
                        self.source_object_id,
                        'headercolschema'
                    )
                tschema, tschema_info, tcol_to_cast = LandingToRawProcessor \
                    .object_schema_width_rules(
                        self,
                        self.source_object_id,
                        'trailercolschema'
                        )
                control_data = spark.read \
                    .option("parserLib", "univocity") \
                    .option("ignoreTrailingWhiteSpace", "true") \
                    .csv(f'{control_file_path}/{source_name}_{country_name}*')
                h_data = spark \
                    .createDataFrame(
                        control_data.where(f.col('_c0') == 'H').rdd,
                        schema=hschema
                        )
                for key, value in hcol_to_cast.items():
                    if 'DECIMAL' or 'decimal' in value:
                        continue
                    else:
                        h_data = h_data.withColumn(key, f.col(key).cast(value))
                trailer = control_data.where(f.col('_c0') == 'T')
                countNullValues = trailer \
                    .select(
                        [f.count(f.when(f.col(a).isNull(), a)).alias(a) for a in trailer.columns]
                        ).collect()[0].asDict()
                columnDrop = [d for d, n in countNullValues.items() if n > 0]
                trailer = trailer.drop(*columnDrop)
                t_data = spark.createDataFrame(trailer.rdd, schema=tschema)
                for key, value in tcol_to_cast.items():
                    if 'DECIMAL' or 'decimal' in value:
                        continue
                    else:
                        t_data = t_data.withColumn(key, f.col(key).cast(value))
                hdata_dict = h_data.collect()
                tdata_dict = t_data.collect()
                for record in range(len(hdata_dict)):
                    metadata = {
                        'header': hdata_dict[record].asDict(),
                        'trailer': tdata_dict[record].asDict()
                    }
                    table_name = metadata['header']['table'].lower()
                    rowcount = metadata['trailer']['ROWCOUNT']
                    businessdate = metadata['header']['hDate']
                    query = (
                        f"select SourceObjectID from \
                        Metadata.SourceObjectDetail where \
                        ObjectName = '{table_name}'"
                    )
                    results, columns = self.db_obj.run_sql_query(query)
                    if results:
                        object_id = results[0][0]
                        param = (
                            {'SourceObjectID': object_id,
                             'Metadata': json.dumps(metadata),
                             'RowCount': rowcount,
                             'BusinessDate': businessdate}
                        )
                        self.db_obj.run_stored_proc(
                            'ETLlog',
                            'SourceFileHeaderTrailerLogProc',
                            params=param
                        )

            # Row Count Validation
            LOGGER.info("Row count validation started.")
            query = (
                        f"select [RowCount] from \
                        [ETLlog].[SourceFileHeaderTrailerLog] where \
                        SourceObjectID = {self.source_object_id} \
                        and IsActive = 1"
                    )
            results, columns = self.db_obj.run_sql_query(query)           
            df_count = data.count()
            received_row_count = results[0][0]
            skip_row_flag = True
            if 'skip.row.count' in cs_properties:
                if cs_properties['skip.row.count'].lower() == 'false':
                    skip_row_flag = False
                else:
                    if results:
                        skip_row_flag = False
                    else:
                        LOGGER.info("Skip Row count is True.")
            else:
                if results:
                    skip_row_flag = False

            if not skip_row_flag:
                if results:
                    if df_count != received_row_count:
                        LOGGER.info(
                            '''
                            Rejecting the file due to row count
                            mismatch.
                            '''
                        )
                        # TODO: Reject the file
                        break
                    else:
                        LOGGER.info("Row count validation successful !!.")
                else:
                    LOGGER.info(
                        '''
                        Rejecting the file as skip row count is false
                        and metadata info is not available.
                        '''
                    )
                    # TODO: Reject the file
                    break
  
            # Column count validation
            LOGGER.info("Column count validation started.")
            col_count_from_properties = len(schema_info)
            if col_count_from_properties == len(data.columns):
                LOGGER.info("Column count validation successful.")
            else:
                LOGGER.info(
                    "Rejecting the file due to column length mismatch."
                )
                # TODO: Move to reject directory
                break

            # Adding columns to data
            LOGGER.info("Adding necessary columns to data.")
            uuidUdf = f.udf(lambda: str(uuid.uuid4()), t.StringType())
            file_content = file_name.split('_')
            df_added_columns = data.withColumn(
                "date", f.lit(file_content[date_index].strip('.csv'))
                ) \
                .withColumn(
                    'time', f.expr(
                        "reflect('java.time.LocalDateTime', 'now')"
                    ).cast("string")
                ) \
                .withColumn('RowID',  uuidUdf()) \
                .withColumn('file', f.lit(file_name))

            df_added_columns = df_added_columns\
                .withColumn('time', f.translate(f.col("time"), "-:.", ""))
            df_added_columns = df_added_columns\
                .withColumn('time', f.trim(f.col('time')))
            df_added_columns = df_added_columns\
                .withColumn(
                    'RowID', f.concat(
                        f.col('time'), f.lit('_'), f.col('RowID')
                    )
                )
            df_added_columns = df_added_columns\
                .select(data.columns+['date', 'RowID', 'file'])

            # Date Columns Transformation
            LOGGER.info("Date columns transformation started.")
            # TODO: Integrate ColumnTransformationRules.xml
            func = f.udf(
                lambda x: datetime.datetime.strptime(x, '%Y%m%d'), t.DateType()
            )
            df_added_columns = df_added_columns \
                .withColumn(
                    'date', f.date_format(func(f.col('date')), 'MM-dd-yyy')
                )
            LOGGER.info("Date columns transformation completed.")

            # TODO : Default capturing, replacement & logging.

            LOGGER.info("Generating necessary info for validations.")
            pk_stmt = ' is NULL) '
            dtype_list = []
            for items in schema_info:
                col_name = items[0]
                col_type = items[1]
                # Generating pk statement
                if items[4]:
                    if pk_stmt == ' is NULL) ':
                        pk_stmt = '(' + col_name + pk_stmt
                    else:
                        pk_stmt += f'or ({col_name} is NULL) '
                # Generating datatype validation tuple
                dtype_list.append((col_name, col_type))

            # Key Columns Check
            LOGGER.info("Key columns check started.")
            invalid_rec_dict = {}
            key_column_flag = {}
            if pk_stmt != ' is NULL )':
                df_key_col_check = df_added_columns \
                    .filter(pk_stmt)
                if df_key_col_check.count() > 0:
                    col_list = list(df_key_col_check.columns)
                    df_invalid_col = df_key_col_check\
                        .select('RowID',
                                f.to_json(
                                    f.struct(col_list)
                                ).alias("ErrorData")
                                )
                    df_invalid_col = df_invalid_col \
                        .withColumn(
                            'PipeLineId',
                            f.lit(pipeline_log_id)) \
                        .withColumn(
                            'SourceObjectId',
                            f.lit(self.source_object_id)) \
                        .withColumn(
                            'SourceFileProcessLogId',
                            f.lit(source_file_process_log_id)) \
                        .withColumn(
                            'ErrorCode',
                            f.lit('PK Null Check')) \
                        .withColumn(
                            'ErrorDescription',
                            f.lit('Primary Key column are Null')
                            )
                    df_invalid_col = df_invalid_col.toPandas()
            LOGGER.info("Key columns check completed.")

            # Data Type Validation
            LOGGER.info("Data Type Validation started.")
            df_dtype_val = df_added_columns.dtypes
            dtype_validation = set(df_dtype_val) & set(dtype_list)
            if len(dtype_validation) == len(dtype_list):
                LOGGER.info('Data Type Validation successful')
            else:
                LOGGER.info('Data Type Validation falied')
                # TODO: Log the invalid columns and datatypes

            # Date feild format check

            # Max Length Check
            LOGGER.info('Max Length check started')
            max_length_inv_list = []
            for item in schema_info:
                col_name = item[0]
                col_type = item[1]
                col_len = item[5]
                if (col_len is not None) and col_type == 'string':
                    len_col_name = col_name + '_len'
                    df_length = df_added_columns \
                        .withColumn(len_col_name, f.length(f.col(col_name)))
                    first_value = df_length \
                        .orderBy(len_col_name) \
                        .select(len_col_name) \
                        .first()[len_col_name]
                    if first_value is not None:
                        ordered_df = df_added_columns\
                            .withColumn(
                                len_col_name, f.length(f.col(col_name))
                            ).orderBy(len_col_name).select(len_col_name)
                        first_rec = (ordered_df.first())[len_col_name]
                        if col_len >= float(first_rec):
                            df_records = df_length.where(
                                f.col(len_col_name) > col_len
                            )
                            ml_data_dict = (
                                lambda row: row.asDict(),
                                df_records.collect().map()
                            )
                            for i in ml_data_dict:
                                max_length_inv_list.append(json.dumps(i))
            invalid_rec_dict['Max Length Check'] = max_length_inv_list

            # Not Null check

            # Error Logging
            # schema = 'ETLlog'
            # stored_proc = 'uspInsertFileProcessErrorLog'
            # table_type = 'TableType_FileProcessErrorLog'

            # self.db_obj.insert_data_from_df(
            #                     schema,
            #                     stored_proc,
            #                     df_invalid_col,
            #                     table_type
            #                 )

            # for key, value in invalid_rec_dict.items():
            #     params = {
            #         'PipeLineId': pipeline_log_id,
            #         'SourceObjectId': self.source_object_id,
            #         'SourceFileProcessLogId': source_file_process_log_id,
            #         'RowID': i['RowID'],
            #         'ErrorCode': key,
            #         'ErrorDescription': 'Primary Key column is Null',
            #         'ErrorData': json.dumps(i)
            #         }

            #     self.db_obj.run_stored_proc(schema, stored_proc, params)
            #     key_column_flag[items[0]] = 'Failed'

    def run(self):
        '''
        This method is used to run the raw to standardize pipeline
        end-to-end.
        '''
        LOGGER.info("Starting Landing to Raw pipeline")
        LOGGER.info("Started Initialisation")
        self.config, self.db_obj = initialise(
            self.spark, self.spn_credentials, self.kv_name,
            self.adls_account_name, self.config_path
        )
        LOGGER.info("Ended Initialisation")
        LOGGER.info("Starting Processing Data Files")
        self.raw_to_standardize_processor()
