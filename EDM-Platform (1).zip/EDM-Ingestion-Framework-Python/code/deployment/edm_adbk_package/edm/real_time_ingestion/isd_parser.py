import pandas as pd

from edm.real_time_ingestion.schema_evolution import SchemaEvolution
from edm.utils.const import (
    REALTIME_LANDING_PATH, REALTIME_DTYPE_MAP,
    REALTIME_STAGING_DELTA_PATH,
    REALTIME_STANDARDIZED_DELTA_PATH
)
from edm.utils.general_helper import (
    initialise, merge_sql_metastore_to_adbk_metastore,
    connect_to_synapse, get_polybase_refresh_statement)
from edm.utils.logging_utility import get_logger

LOGGER = get_logger(__name__)
SCHEMA = 'metadata'
TABLE_TYPE_NAME = 'TableType_RealTimeIngestion'


def get_streaming_source(table_property):
    source_property_flag = False
    table_property_parts = table_property.split(",")
    for index, item in enumerate(table_property_parts):
        if item.index("source") >= 0:
            list_index = index
            source_property_flag = True
            break
    if source_property_flag:
        streaming_source = (
            table_property_parts[list_index].split(":")[1]
        )
    else:
        streaming_source = None
    return streaming_source


def get_has_explode_flag(explode_property):
    if pd.isnull(explode_property):
        return 0
    else:
        return 1


def get_dest_data_type(source_data_type):
    if pd.isnull(source_data_type):
        return None
    else:
        return REALTIME_DTYPE_MAP.get(source_data_type, None)


def get_is_primary_key_flag(is_primary):
    if pd.isnull(is_primary):
        return 0
    else:
        flag = is_primary.split(':')[0]
        if flag.lower() == 'yes':
            return 1
        else:
            return 0


def get_pk_seq_num(is_primary):
    if pd.isnull(is_primary):
        return None
    else:
        primary_key_parts = is_primary.split(':')
        flag = is_primary.split(':')[0]
        if flag.lower() == 'yes':
            if len(primary_key_parts) > 1:  # has primary key sequence info
                return is_primary.split(':')[1]
            else:
                IsdParser.pk_seq_number = IsdParser.pk_seq_number + 1
                return IsdParser.pk_seq_number
        else:
            return None


def get_is_nullable_flag(nullable_prop):
    if pd.isnull(nullable_prop):
        return 0
    else:
        if nullable_prop.lower() == 'yes':
            return 1
        else:
            return 0


def get_is_exploded_flag(json_tag):
    if pd.isnull(json_tag):
        return 0
    else:
        try:
            if json_tag.index('exp_col') >= 0:
                return 1
            else:
                return 0
        except ValueError:
            return 0


def get_is_tokenisable_flag(tokenisable_prop):
    if pd.isnull(tokenisable_prop):
        return 0
    else:
        if tokenisable_prop.lower() in ('y', 'yes'):
            return 1
        else:
            return 0


def get_tokenization_algo(row):
    if row['IsTokenizable'] == 1:
        row['TokenizationAlgorithm'] = row['Data_Element_to_be_used']
        tokenization_func_str = row['Protegrity_Function']
        tokenization_func_str = (
            tokenization_func_str.replace("protegrity.", "")
        )
        tokenization_func_str = (
            tokenization_func_str.rstrip(")").rstrip("(").strip()
        )
        row['TokenizationFunction'] = tokenization_func_str
    else:
        row['TokenizationAlgorithm'] = None
        row['TokenizationFunction'] = None
    return row


def get_explode_string_details(row):
    explode_property_parts = row['ExplodeProperty'].split(":")
    explode_col_str_index = explode_property_parts.index('explode_columns')
    explode_sequence = explode_property_parts[explode_col_str_index+1]
    explode_json_path = explode_property_parts[explode_col_str_index+2]
    nested_object_type = explode_property_parts[explode_col_str_index+3]
    # explode_mode = explode_property_parts[-1]
    row['ExplodeColumnSequence'] = explode_sequence
    row['ExplodeColumnJSONPath'] = explode_json_path
    row['NestedObjectType'] = nested_object_type
    # row['ExplodeMode'] = explode_mode
    return row


class IsdParser:
    pk_seq_number = 0
    '''
    This class is used to read the ISD file dropped in ADLS raw
    zone in the isds folder and register the Configuration and the version
    in the metastore. It also registers other things like Streaming Sources,
    EDMPTables, ColumnDetails and ColumnExplodeProperties into the
    metastore
    '''
    def __init__(self, file_name, file_path, spark, dbutils, **kwargs):
        '''
        This constructor takes the necessary params required to create
        the object and the run the different function in this class.
        '''
        self.spark = spark
        self.dbutils = dbutils
        self.file_name = file_name
        self.file_path = file_path
        self.kv_name = kwargs.get('kv_name', None)
        self.spn_credentials = kwargs.get('spn_credentials', None)
        self.adls_account_name = kwargs.get('adls_account_name', None)
        self.config_path = kwargs.get('config_path', None)
        self.delimiter = kwargs.get('delimiter', ',')

    def get_register_isd_version(self):
        '''
        This function is used to register the configuration
        and its version into the metastore.
        '''
        isd_file_name_parts = self.file_name.split('v_')
        isd_name = isd_file_name_parts[0].strip()
        extension_index = isd_file_name_parts[1].rindex('.')
        isd_version = isd_file_name_parts[1][0:extension_index]

        LOGGER.info(f'Registering ISD: {isd_name}')
        self.db_obj.run_stored_proc(
            schema=SCHEMA,
            stored_proc='uspUpdateStreamingConfigurations',
            params={'ConfigurationName': isd_name}
        )

        LOGGER.info(f'Registering Version: {isd_version}')
        self.db_obj.run_stored_proc(
            schema=SCHEMA,
            stored_proc='uspUpdateStreamingConfigurationVersions',
            params={
                'ConfigurationName': isd_name,
                'VersionNumber': isd_version
            }
        )
        return isd_name, isd_version

    def read_isd_config(self):
        '''
        This function is used to read the ISD file as Spark
        Dataframe from ADLS and later converted to Pandas
        DataFrame for further processing.
        '''
        isd_index = self.file_path.index('isds')
        relative_file_path = (
            self.file_path[isd_index:].rstrip('/') + '/' + self.file_name
        )
        isd_path = REALTIME_LANDING_PATH.replace(
            'account', self.adls_account_name
        )
        isd_path = isd_path.rstrip('/') + '/' + relative_file_path
        LOGGER.info(f'Reading ISD File: {isd_path}')
        isd_spark_df = (
            self.spark.read.format('csv').
            options(
                header=True,
                delimiter=self.delimiter,
                multiline=True, quote="\""
            ).load(isd_path)
        )
        isd_pd_df = isd_spark_df.toPandas()
        return isd_pd_df

    def register_streaming_sources(self):
        '''
        This function is used to register the Distinct Sources
        extracted form the EDMP_TABLE_PROPERTY Column of the ISD
        into the StreamingSourceDetails Table in the metastore.
        '''
        sources_table_df = self.isd_df.loc[:, [
            'EDMP_TABLE_NAME', 'EDMP_TABLE_PROPERTY']
        ]
        sources_table_df = sources_table_df.loc[(
            (sources_table_df['EDMP_TABLE_NAME'].notna()) &
            (sources_table_df['EDMP_TABLE_PROPERTY'].notna())
        ), :].drop_duplicates()
        sources_table_df['StreamingSource'] = (
            sources_table_df['EDMP_TABLE_PROPERTY'].map(
                get_streaming_source)
        )
        sources_table_df.drop(columns=['EDMP_TABLE_PROPERTY'], inplace=True)
        sources_df = (
            pd.DataFrame(sources_table_df['StreamingSource'].drop_duplicates())
        )
        sources_df['ConfigurationName'] = self.isd_name
        LOGGER.info('Registering Streaming Sources')
        self.db_obj.insert_data_from_df(
            schema=SCHEMA,
            sp_name='uspUpdateStreamingSourceDetails',
            input_df=sources_df,
            table_type_name=TABLE_TYPE_NAME
        )
        self.isd_df = pd.merge(
            self.isd_df, sources_table_df, on=['EDMP_TABLE_NAME'], how='left'
        )
        source_df = self.db_obj.get_df_from_query(
            "SELECT * FROM metadata.StreamingSourceDetails"
        )
        sql_statement = merge_sql_metastore_to_adbk_metastore(
            SCHEMA, 'StreamingSourceDetails', source_df,
            self.spark
        )
        self.spark.sql(sql_statement)
        return sources_table_df

    def register_edmp_target_tables(self, input_df):
        '''
        This table is used to resgiter the unique set of tables
        for each source in the ISD file along with its HasExplode
        property, retrived from EDMP_EXPLODE_PROPERT Column into
        StreamingEDMPTargetTables in the metastore.
        The input_df is an output from register_streaming_sources()
        and contains unique set of Streaming Source and TableNames.
        '''
        table_explode_property_df = self.isd_df.loc[(
            (self.isd_df['EDMP_TABLE_NAME'].notna()) &
            (self.isd_df['EDMP_EXPLODE_PROPERTY'].notna())
        ), ['EDMP_TABLE_NAME', 'EDMP_EXPLODE_PROPERTY', 'StreamingSource']].\
            drop_duplicates()

        sources_table_df = pd.merge(
            input_df, table_explode_property_df,
            on=['EDMP_TABLE_NAME', 'StreamingSource'], how='left'
        )
        sources_table_df['HasExplode'] = (
            sources_table_df['EDMP_EXPLODE_PROPERTY'].map(
                get_has_explode_flag)
        )
        sources_table_df.rename(columns={
            'EDMP_TABLE_NAME': 'TargetTableName'
        }, inplace=True)
        table_explode_property_df = sources_table_df
        sources_table_df = sources_table_df.loc[:, [
            'TargetTableName', 'StreamingSource', 'HasExplode']
        ]
        LOGGER.info('Registering Streaming Target Tables')
        self.db_obj.insert_data_from_df(
            schema=SCHEMA,
            sp_name='uspUpdateStreamingEDMPTableDetails',
            input_df=sources_table_df,
            table_type_name=TABLE_TYPE_NAME
        )
        source_df = self.db_obj.get_df_from_query(
            "SELECT * FROM metadata.StreamingEDMPTableDetails"
        )
        sql_statement = merge_sql_metastore_to_adbk_metastore(
            SCHEMA, 'StreamingEDMPTableDetails', source_df,
            self.spark
        )
        self.spark.sql(sql_statement)
        return table_explode_property_df

    def register_edmp_column_details(self):
        '''
        This function is used to register column details in
        the metastore for each table found in the ISD
        config Mapping File dropped on ADLS.
        '''
        column_df = self.isd_df.loc[
            (self.isd_df['EDMP_TABLE_NAME'].notna()) &
            (self.isd_df['EDMP_COLUMN_NAME'].notna()) &
            (self.isd_df['StreamingSource'].notna()) &
            (self.isd_df['EDMP_JSONTAG'].notna()), [
                'EDMP_DATA_TYPE', 'EDMP_PRIMARY_KEY', 'EDMP_DATA_LENGTH',
                'EDMP_NULLABLE', 'EDMP_JSONTAG', 'EDMP_SENSITIVE_DATA',
                'EDMP_TABLE_NAME', 'EDMP_COLUMN_NAME', 'StreamingSource',
                'Data_Element_to_be_used', 'Protegrity_Function'
            ]
        ].drop_duplicates()
        LOGGER.info('Getting Column DestDataType Property')
        column_df['DestDataType'] = column_df['EDMP_DATA_TYPE'].apply(
            get_dest_data_type
        )
        LOGGER.info('Getting Column IsPrimary Property')
        column_df['IsPrimaryKey'] = column_df['EDMP_PRIMARY_KEY'].apply(
            get_is_primary_key_flag
        )
        LOGGER.info('Getting Column PkSequence Number')
        column_df['PKSequenceNumber'] = column_df['EDMP_PRIMARY_KEY'].apply(
            get_pk_seq_num
        )
        LOGGER.info('Getting Column IsNullable Property')
        column_df['IsNullable'] = column_df['EDMP_NULLABLE'].apply(
            get_is_nullable_flag
        )
        LOGGER.info('Getting Column IsExploded Property')
        column_df['IsExploded'] = column_df['EDMP_JSONTAG'].apply(
            get_is_exploded_flag
        )
        LOGGER.info('Getting Column IsTokenizable Property')
        column_df['IsTokenizable'] = column_df['EDMP_SENSITIVE_DATA'].apply(
            get_is_tokenisable_flag
        )
        LOGGER.info('Getting Column Tokenization Algorithm Property')
        column_df = column_df.apply(get_tokenization_algo, axis=1)
        column_df['IsActive'] = 1
        column_df['ConfigurationName'] = self.isd_name
        column_df.rename(columns={
            'EDMP_TABLE_NAME': 'TargetTableName',
            'EDMP_COLUMN_NAME': 'ColumnName',
            'EDMP_DATA_TYPE': 'SourceDataType',
            'EDMP_DATA_LENGTH': 'Length',
            'EDMP_JSONTAG': 'JSONTag'
        }, inplace=True)
        column_df = column_df.loc[:, [
            'TargetTableName', 'ColumnName', 'SourceDataType',
            'DestDataType', 'IsPrimaryKey', 'PKSequenceNumber',
            'Length', 'IsNullable', 'JSONTag', 'IsExploded',
            'IsActive', 'IsTokenizable', 'TokenizationAlgorithm',
            'TokenizationFunction', 'StreamingSource', 'ConfigurationName'
            ]
        ]
        column_df['Length'] = column_df['Length'].apply(
            lambda x: x if x is None else x.strip('\t')
        )
        column_df['Temp'] = column_df.index+1
        LOGGER.info('Getting Column Order Property')
        column_df['ColumnOrder'] = column_df.groupby(
            ['StreamingSource', 'TargetTableName'])['Temp'].\
            rank(method='first')
        column_df.reset_index(inplace=True)
        column_df.drop(columns=['Temp', 'index'], inplace=True)
        LOGGER.info('Registering Column Details in Metastore')
        self.db_obj.insert_data_from_df(
            schema=SCHEMA,
            sp_name='uspUpdateStreamingEDMPColumnDetails',
            input_df=column_df,
            table_type_name=TABLE_TYPE_NAME
        )
        source_df = self.db_obj.get_df_from_query(
            "SELECT * FROM metadata.StreamingEDMPColumnDetails"
        )
        sql_statement = merge_sql_metastore_to_adbk_metastore(
            SCHEMA, 'StreamingEDMPColumnDetails', source_df,
            self.spark
        )
        self.spark.sql(sql_statement)

    @staticmethod
    def split_table_explode_property(input_df):
        '''
        This is a static method which is used to split the
        explode property string into different explode levels
        for each Streaming Source Table Combination.
        The input_df contains EDMP_EXPLODE_PROPERTY,
        TargetTableName, StreamingSource.
        '''
        LOGGER.info('Splitting Table Explode Properties')
        final_df = pd.DataFrame()
        for _, row in input_df.iterrows():
            explode_property_list = row['EDMP_EXPLODE_PROPERTY'].split('&')
            table_explode_prop = pd.DataFrame(
                explode_property_list,
                columns=['ExplodeProperty']
            )
            table_explode_prop['TargetTableName'] = row['TargetTableName']
            table_explode_prop['StreamingSource'] = row['StreamingSource']
            final_df = final_df.append(table_explode_prop)
        return final_df

    def register_edm_table_explode_details(self, input_df):
        '''
        This function is used to split and register Table Explode
        Properties. The input_df contains TargetTableName,
        EDMP_EXPLODE_PROPERTY and StreamingSoucre Columns.
        This is an output from register_edmp_target_tables()
        '''
        input_df = input_df.loc[
            input_df['EDMP_EXPLODE_PROPERTY'].notna(), :]
        explode_property_df = IsdParser.split_table_explode_property(input_df)
        LOGGER.info("Getting Explode Property Details")
        explode_property_df = explode_property_df.apply(
            get_explode_string_details, axis=1
        )
        explode_property_df.drop(columns=['ExplodeProperty'], inplace=True)
        LOGGER.info('Registering Table Explode Properties')
        self.db_obj.insert_data_from_df(
            schema=SCHEMA,
            sp_name='uspUpdateStreamingTableExplodeProperties',
            input_df=explode_property_df,
            table_type_name=TABLE_TYPE_NAME
        )
        source_df = self.db_obj.get_df_from_query(
            "SELECT * FROM metadata.StreamingTableExplodeProperties"
        )
        self.spark.sql(
            "TRUNCATE TABLE metadata.StreamingTableExplodeProperties")
        sql_statement = merge_sql_metastore_to_adbk_metastore(
            SCHEMA, 'StreamingTableExplodeProperties', source_df,
            self.spark
        )
        self.spark.sql(sql_statement)

    def get_tables_properties(self, streaming_source):
        params = {
            "SourceName": streaming_source
        }
        source_tables_prop_df = self.db_obj.get_df_from_stored_proc(
            schema='metadata',
            stored_proc='uspGetStreamingTableColumnProperties',
            params=params
        )
        return source_tables_prop_df

    def update_schema_evolved(
        self, table_name, streaming_source, column_list, mode
    ):
        # uspUpdateSchemaEvolvedRealTime
        pd_df = pd.DataFrame(data=column_list, columns=['ColumnName'])
        pd_df['StreamingSource'] = streaming_source
        pd_df['TargetTableName'] = table_name
        pd_df['Mode'] = mode
        self.db_obj.insert_data_from_df(
            schema=SCHEMA,
            sp_name='uspUpdateSchemaEvolvedRealTime',
            input_df=pd_df,
            table_type_name='TableType_RealTimeIngestion'
        )
        source_df = self.db_obj.get_df_from_query(
            "SELECT * FROM metadata.StreamingEDMPColumnDetails"
        )
        sql_statement = merge_sql_metastore_to_adbk_metastore(
            SCHEMA, 'StreamingEDMPColumnDetails', source_df,
            self.spark
        )
        self.spark.sql(sql_statement)

    def schema_evolve_and_refresh_polybase_tables(
        self, streaming_source, table_name, table_prop_df,
        delta_table_name, delta_table_path, mode,
    ):
        is_schema_evolved = False
        is_poybase_refreshed = False
        if mode == 'staging':
            schema_evolved_col_name = 'IsSchemaEvolved'
            col_updated_col_name = 'IsColumnUpdated'
            schema = 'stg'
            external_data_source = 'StagingExternalDataSourceRealTime'
        else:
            schema_evolved_col_name = 'IsSchemaEvolvedStandardized'
            col_updated_col_name = 'IsColumnUpdatedStandardized'
            schema = 'standardized'
            external_data_source = 'StandardizedExternalDataSourceRealTime'

        sql_query = f"SHOW TABLES '{delta_table_name}'"
        show_tables_spark_df = self.spark.sql(sql_query)
        if show_tables_spark_df.count() != 0:
            # Delta table schema evolution
            schema_evolved_df = table_prop_df.loc[
                table_prop_df[schema_evolved_col_name] == 1, :
            ]
            if len(schema_evolved_df) != 0:
                is_schema_evolved = True
                LOGGER.info(f"Performing Schema Evolution for {delta_table_name}")
                SchemaEvolution(
                    table_name, streaming_source,
                    mode, delta_table_path,
                    self.spark, self.dbutils
                ).run(table_prop_df)

        # Check if Polybase Table needs to be refreshed for current table
        polybase_refresh_df = table_prop_df.loc[
            ((table_prop_df[schema_evolved_col_name] == 1) |
                (table_prop_df[col_updated_col_name] == 1)), :
        ]
        if len(polybase_refresh_df) != 0:
            LOGGER.info(f"Refreshing polybase table for {schema}.{table_name}")
            is_poybase_refreshed = True
            # check table existence
            sql_query = (
                f"SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE \
                    TABLE_SCHEMA = '{schema}' AND TABLE_NAME = '{table_name}'"
            )
            results, _ = self.synapse_obj.run_sql_query(
                sql_query
            )
            if len(results) != 0:
                self.synapse_obj.run_sql_query(
                    f"DROP EXTERNAL TABLE {schema}.{table_name}"
                )
            sql_statement = get_polybase_refresh_statement(
                schema, table_name, streaming_source, table_prop_df,
                external_data_source, mode)
            self.synapse_obj.run_sql_query(sql_statement)

        if is_schema_evolved or is_poybase_refreshed:
            column_list = list(table_prop_df['ColumnName'].values)
            self.update_schema_evolved(
                table_name, streaming_source, column_list, mode)

    def create_and_refresh_table_schema(self, sources_table_df):
        streaming_sources = list(
            sources_table_df['StreamingSource'].unique()
        )
        for source in streaming_sources:
            source_tables_prop_df = self.get_tables_properties(source)
            table_list = list(
                source_tables_prop_df['TargetTableName'].unique()
            )
            for table in table_list:
                table_prop_df = source_tables_prop_df.loc[
                    source_tables_prop_df['TargetTableName'] == table
                ]
                delta_table_name_stg = f"{table}_delta"
                delta_table_path_stg = REALTIME_STAGING_DELTA_PATH.replace(
                    'account', self.adls_account_name
                )
                delta_table_path_stg = (
                    delta_table_path_stg.rstrip('/') + '/' + source + '/' +
                    table
                )
                delta_table_name_std = table
                delta_table_path_std = (
                    REALTIME_STANDARDIZED_DELTA_PATH.replace(
                        'account', self.adls_account_name)
                )
                delta_table_path_std = (
                    delta_table_path_std.rstrip('/') + '/' + source + '/' +
                    table
                )
                LOGGER.info(
                    f"Schema Evolution and polybase Refresh in stg for {table}")
                self.schema_evolve_and_refresh_polybase_tables(
                    source, table, table_prop_df, delta_table_name_stg,
                    delta_table_path_stg, mode='staging'
                )
                LOGGER.info(
                    f"Schema Evolution and polybase Refresh in std for {table}")
                self.schema_evolve_and_refresh_polybase_tables(
                    source, table, table_prop_df, delta_table_name_std,
                    delta_table_path_std, mode='standardized'
                )

    def run(self):
        self.config, self.db_obj = initialise(
            self.spark, self.spn_credentials, self.kv_name,
            self.adls_account_name, self.config_path
        )
        self.synapse_obj = connect_to_synapse(
            self.spn_credentials, self.kv_name, self.config)
        self.isd_name, self.isd_version = self.get_register_isd_version()
        self.isd_df = self.read_isd_config()
        sources_table_df = self.register_streaming_sources()
        explode_table_prop_df = (
            self.register_edmp_target_tables(sources_table_df)
        )
        self.register_edm_table_explode_details(explode_table_prop_df)
        self.register_edmp_column_details()
        LOGGER.info("Perform Schema Evolution and Polybase Table Refresh")
        self.create_and_refresh_table_schema(sources_table_df)
        LOGGER.info('ISD Parsing Completed')