CREATE PROCEDURE [Metadata].[uspUpdateSchemaEvolvedRealTime]  
@Input metadata.TableType_RealTimeIngestion READONLY
AS  
-----------------------------------------------------------------------------------------------------------------------  
/****** StoredProcedure:  [metadata].[uspUpdateSchemaEvolvedRealTime]  
  Script Date:   2021-06-23   
  Author:     Divye Rastogi  
  Test Execute:   This SP is used to update the IsSchemaEvolved Flag for Columns in StreamingEDMPColumnDetails  
  CMD:     EXEC [metadata].[uspUpdateSchemaEvolvedRealTime]  
        @Input= '<value>'  
******/  
-----------------------------------------------------------------------------------------------------------------------  
BEGIN  
 BEGIN TRY
	
	  UPDATE cd   
	  SET 
		cd.IsSchemaEvolved = CASE WHEN Src.Mode = 'staging' THEN 0 ELSE cd.IsSchemaEvolved END,
		cd.IsSchemaEvolvedStandardized = CASE WHEN Src.Mode = 'standardized' THEN 0 ELSE cd.IsSchemaEvolvedStandardized END,
		cd.IsColumnUpdated = CASE WHEN Src.Mode = 'staging' THEN 0 ELSE cd.IsColumnUpdated END,
		cd.IsColumnUpdatedStandardized = CASE WHEN Src.Mode = 'standardized' THEN 0 ELSE cd.IsColumnUpdatedStandardized END
	  FROM @input Src  
	  INNER JOIN metadata.StreamingSourceDetails ssd ON ssd.StreamingSource = Src.StreamingSource  
	  INNER JOIN metadata.StreamingEDMPTableDetails td ON td.StreamingSourceID = ssd.ID  
	  AND td.TargetTableName = src.TargetTableName  
	  INNER JOIN metadata.StreamingEDMPColumnDetails cd ON cd.TargetTableID = td.ID  
	  AND cd.ColumnName = src.ColumnName  
  
	  UPDATE cd   
	  SET 
		cd.IsSchemaEvolved = CASE WHEN Src.Mode = 'staging' THEN 0 ELSE cd.IsSchemaEvolved END,
		cd.IsSchemaEvolvedStandardized = CASE WHEN Src.Mode = 'standardized' THEN 0 ELSE cd.IsSchemaEvolvedStandardized END,
		cd.IsColumnUpdated = CASE WHEN Src.Mode = 'staging' THEN 0 ELSE cd.IsColumnUpdated END,
		cd.IsColumnUpdatedStandardized = CASE WHEN Src.Mode = 'standardized' THEN 0 ELSE cd.IsColumnUpdatedStandardized END
	  FROM @input Src  
	  INNER JOIN metadata.StreamingSourceDetails ssd ON ssd.StreamingSource = Src.StreamingSource  
	  INNER JOIN metadata.StreamingEDMPTableDetails td ON td.StreamingSourceID = ssd.ID  
	  AND td.TargetTableName = src.TargetTableName  
	  INNER JOIN metadata.StreamingEDMPColumnDetails cd ON cd.TargetTableID = td.ID  
	  WHERE cd.IsSchemaEvolved = 1 AND cd.ColumnOrder = -1 AND cd.IsActive = 0 
	
	
 END TRY 
  
 BEGIN CATCH  
  DECLARE @Errmsg NVARCHAR(4000) = (  
    SELECT ERROR_MESSAGE()  
    )  
   ,@ErrorSeverity INT = ERROR_SEVERITY()  
   ,@ErrorState INT = ERROR_STATE()  
  
  RAISERROR (  
    @Errmsg  
    ,@ErrorSeverity  
    ,@ErrorState  
    )  
 END CATCH  
END