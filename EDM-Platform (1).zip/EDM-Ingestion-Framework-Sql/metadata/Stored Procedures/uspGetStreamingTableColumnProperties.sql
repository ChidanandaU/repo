CREATE PROCEDURE [Metadata].[uspGetStreamingTableColumnProperties]  
@SourceName NVARCHAR(50)  
AS  
-----------------------------------------------------------------------------------------------------------------------  
/****** StoredProcedure:  [metadata].[uspGetStreamingTableColumnProperties]  
  Script Date:   2021-06-08  
  Author:     Divye Rastogi  
  Test Execute:   This SP is used to get the Table and Column Properties for a given source Name  
  CMD:     EXEC [metadata].[uspGetStreamingTableColumnProperties]  
        @SourceName = '<value>'  
******/  
-----------------------------------------------------------------------------------------------------------------------  
BEGIN  
 BEGIN TRY   
  DECLARE @SourceID BIGINT  
  SELECT @SourceID = ID FROM Metadata.StreamingSourceDetails WHERE StreamingSource = @SourceName  
  
  SELECT   
  ssd.StreamingSource,  
  ssd.ID AS StreamingSourceID,  
  td.ID AS TargetTableID,  
  td.TargetTableName,  
  td.HasExplode,  
  cd.ColumnName,  
  cd.ColumnOrder,  
  cd.SourceDataType,  
  cd.DestDataType,  
  cd.IsPrimaryKey,  
  cd.PkSequenceNumber,  
  cd.[Length],  
  cd.IsNullable,  
  cd.JsonTag,  
  cd.IsExploded,  
  cd.IsActive,  
  cd.IsSchemaEvolved, 
  cd.IsSchemaEvolvedStandardized,
  cd.IsColumnUpdated,
  cd.IsColumnUpdatedStandardized,
  cd.IsTokenizable,  
  cd.TokenizationAlgorithm,
  cd.TokenizationFunction
  FROM Metadata.StreamingSourceDetails ssd  
  INNER JOIN Metadata.StreamingEDMPTableDetails td ON ssd.ID = td.StreamingSourceID  
  INNER JOIN Metadata.StreamingEDMPColumnDetails cd ON td.ID = cd.TargetTableID  
  WHERE ssd.ID = @SourceID  
 END TRY  
  
 BEGIN CATCH  
  DECLARE @Errmsg NVARCHAR(4000) = (  
    SELECT ERROR_MESSAGE()  
    )  
   ,@ErrorSeverity INT = ERROR_SEVERITY()  
   ,@ErrorState INT = ERROR_STATE()  
  
  RAISERROR (  
    @Errmsg  
    ,@ErrorSeverity  
    ,@ErrorState  
   )  
 END CATCH  
END  