CREATE TABLE [Recon].[StreamingTableReconciliation](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[ControlFileName] [nvarchar](100) NOT NULL,
	[TargetTableID] [bigint] NOT NULL,
	[ReconDate] [datetime2](7) NOT NULL,
	[ControlFileRecordCount] [bigint] NOT NULL,
	[FailedEDMPTableRowCount] [bigint] NOT NULL,
	[IsReconSkipped] [bit] NOT NULL,
	[IsReconSuccessful] [bit] NOT NULL,
	[ExceptionDetails] NVARCHAR(MAX) NULL,
	[CreatedBy] [nvarchar](100) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](100) NULL,
	[ModifiedOn] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [Recon].[StreamingTableReconciliation] ADD  DEFAULT (suser_name()) FOR [CreatedBy]
GO

ALTER TABLE [Recon].[StreamingTableReconciliation] ADD  DEFAULT (getutcdate()) FOR [CreatedOn]
GO

ALTER TABLE [Recon].[StreamingTableReconciliation]  WITH CHECK ADD FOREIGN KEY([TargetTableID])
REFERENCES [Metadata].[StreamingEDMPTableDetails] ([ID])
GO