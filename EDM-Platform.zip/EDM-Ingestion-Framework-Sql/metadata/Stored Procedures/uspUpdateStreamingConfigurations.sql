CREATE PROCEDURE [Metadata].[uspUpdateStreamingConfigurations]
@ConfigurationName nvarchar(100)
AS 
-----------------------------------------------------------------------------------------------------------------------
/****** StoredProcedure:		[metadata].[uspUpdateStreamingConfigurations]
		Script Date:			2021-03-06 
		Author:					Priyanka Bariki
		Test Execute:			This SP is used to insert or update records into the StreamingConfigurations Table.
		CMD:					EXEC [metadata].[uspUpdateStreamingConfigurations]
								@ConfigurationName = '<value>'
******/
-----------------------------------------------------------------------------------------------------------------------
BEGIN 
 	BEGIN TRY
 	   MERGE INTO [metadata].[StreamingConfigurations] AS Tar
			USING
			(
				SELECT 
				@ConfigurationName AS ConfigurationName
			) As Src
			ON 
			Tar.[Configuration] = Src.[ConfigurationName]

			WHEN NOT MATCHED THEN INSERT
			(
				[Configuration],
				IsActive,
				CreatedBy,
				CreatedOn
			)
			VALUES
			(
				Src.[ConfigurationName],
				1,
				suser_name(),
				GETUTCDATE()
			);
 	END TRY

    BEGIN CATCH
		DECLARE @Errmsg NVARCHAR(4000) = (
				SELECT ERROR_MESSAGE()
				)
			,@ErrorSeverity INT = ERROR_SEVERITY()
			,@ErrorState INT = ERROR_STATE()

		RAISERROR (
				@Errmsg
				,@ErrorSeverity
				,@ErrorState
				)
	END CATCH
END