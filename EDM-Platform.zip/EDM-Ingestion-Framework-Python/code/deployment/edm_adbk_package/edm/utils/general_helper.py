import re

from edm.utils.db_utility import DBConnection
from edm.utils.keyvault_utility import KeyvaultSecretsUtility
from edm.utils.logging_utility import add_azure_handler_to_all_loggers


def adls_connectivity(spark, storage_account_name, access_key):
    '''
    This function is used to set up connectivity to adls
    storage account on a spark session
    '''
    spark.conf.set(
        "fs.azure.account.key.{}.dfs.core.windows.net".
        format(storage_account_name), access_key
    )
    return spark


def blob_connectivity(spark, storage_account_name, access_key):
    '''
    This function is used to setup connectivity to Blob
    Storage Account on a Spark Session
    '''
    spark.conf.set(
        "fs.azure.account.key.{}.blob.core.windows.net".
        format(storage_account_name), access_key
    )
    return spark


def read_env_config(spark, storage_account_name, config_path):
    '''
    This method is uses to read the env config file from raw zone in the
    ADLS
    '''
    base_path = f'abfss://raw@{storage_account_name}.dfs.core.windows.net/'
    adls_config_path = base_path + config_path.lstrip('/')
    config_df = spark.read.option("multiline", "true").json(adls_config_path)
    config = config_df.toPandas().to_dict('dict')
    return config


def initialise(
    spark,
    spn_credentials,
    kv_name,
    adls_account_name,
    config_path
):
    '''
    This method sets up the Blob and ADLS connectivity by setting the
    spark.conf. This also sets the DBConnection to the Operational DB,
    add azure_handler to loggers, reads the env config.
    It returns the config and DBConnection Obj.
    '''
    kv_client = KeyvaultSecretsUtility(
        spn_credentials, kv_name)
    _, adls_access_key = kv_client.get_secret('AdlsAccessKey')
    spark = adls_connectivity(spark, adls_account_name, adls_access_key)
    config = read_env_config(
        spark, adls_account_name, config_path
    )
    _, blob_access_key = kv_client.get_secret(
        config['blob_details'][0]['blob_access_secret']
    )
    spark = blob_connectivity(
        spark, config['blob_details'][0]['name'],
        blob_access_key)
    _, db_user_name = kv_client.get_secret(
        config['db_connection_details'][0]['db_user_name_secret']
    )
    _, db_pwd = kv_client.get_secret(
        config['db_connection_details'][0]['db_password_secret']
    )
    db_obj = DBConnection(
        config['db_connection_details'][0]['db_server_name'],
        config['db_connection_details'][0]['db_name'],
        db_user_name,
        db_pwd
    )
    _, instr_key = kv_client.get_secret(
        config['app_insights'][0]['instr_key_secret']
    )
    add_azure_handler_to_all_loggers(instr_key)
    return config, db_obj


def get_filename_date_index(file_name):
    '''
    This method is used to provide the date index from the filename.
    '''
    date_regex = r"[0-9]{4}[0-9]{2}[0-9]{2}"
    regex = re.compile(date_regex)
    file_name_part_list = file_name.split("_")
    date_index = [i for i, item in enumerate(file_name_part_list) if re.search(
        regex, item)][0]
    return date_index
