LANDING_ZONE_CONFIG_PATH = (
    'wasbs://container@account.blob.core.windows.net/config'
)
LANDING_ZONE_DATA_PATH = (
    'wasbs://container@account.blob.core.windows.net/data'
)
RAW_ZONE_CONFIG_PATH = (
    'abfss://raw@account.dfs.core.windows.net/config'
)
SQL_ADBK_DTYPE_MAP = {"DECIMAL": "DOUBLE", "VARCHAR": "STRING"}