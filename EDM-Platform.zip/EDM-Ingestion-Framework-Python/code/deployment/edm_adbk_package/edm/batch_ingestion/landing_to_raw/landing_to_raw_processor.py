import json
import re
import datetime
import pyspark.sql.types as t
import pyspark.sql.functions as f

from edm.utils.const import (
    LANDING_ZONE_DATA_PATH, RAW_ZONE_DATA_PATH)
from edm.utils.general_helper import (
    initialise, get_filename_date_index
)
from edm.utils.logging_utility import get_logger

LOGGER = get_logger(__name__)


class LandingToRawProcessor:
    '''
    This class is used to process the data file
    from Landing to Raw zone. Data file will get
    reject if found empty and moved to reject zone.
    '''

    def __init__(self, source, country, file_name, pipeline_log_id, spark, sqlContext, dbutils, **kwargs):
        '''
        This instantiates a Param Config Parser Object
        '''
        self.source = source
        self.country = country
        self.file_name = file_name
        self.pipeline_log_id = pipeline_log_id
        self.spark = spark
        self.sqlContext = sqlContext
        self.dbutils = dbutils
        self.spn_credentials = kwargs.get("spn_credentials", None)
        self.kv_name = kwargs.get("kv_name", None)
        self.adls_account_name = kwargs.get("adls_account_name", None)
        self.config_path = kwargs.get("config_path", None)

    def landing_to_raw_processor(self):
        '''
        This method is used to process & tokenize the data file and
        move it to Raw zone if it's not empty otherwise
        moved to reject zone.
        '''
        # Defining destination and source path
        data_dest = (
            RAW_ZONE_DATA_PATH.replace(
                'account', self.adls_account_name
            ).replace(
                "source",
                self.source
            ).replace(
                "country",
                self.country
            )
        )
        landing_data_path = (
            LANDING_ZONE_DATA_PATH.replace(
                "container",
                self.config['blob_details'][0]['incoming_container_name']
                ).replace(
                    "account",
                    self.config['blob_details'][0]['name']
                ).replace(
                    "source",
                    self.source
                ).replace(
                    "country",
                    self.country
                )
        )
        landing_archive_path = (
            LANDING_ZONE_DATA_PATH.replace(
                "container",
                self.config['blob_details'][0]['archival_container_name']
                ).replace(
                    "account",
                    self.config['blob_details'][0]['name']
                ).replace(
                    "source",
                    self.source
                ).replace(
                    "country",
                    self.country
                )
        )

        # Checking file type
        if '.D' in self.file_name:
            file_name_part_list = self.file_name.split(".")
            business_date = file_name_part_list[1].strip('D')
            object_name = file_name_part_list[0].lower()
        else:
            date_index = get_filename_date_index(self.file_name)
            file_name_part_list = self.file_name.split("_")
            object_name = self.get_object_name(date_index, file_name_part_list)
            business_date = file_name_part_list[date_index].split('.')[0]

        output = {}
        if object_name:

            # Getting Source and Object properties from metastore
            propQuery = (
                f"select sm.SourceID, sm.CountrySourceProperties, \
                sm.SourceType,sod.SourceObjectID,sod.ObjectProperties \
                from Metadata.SourceMaster sm join \
                Metadata.SourceObjectDetail sod on \
                sod.SourceId=sm.SourceID where SourceName = '{self.source}'\
                and CountryCode= '{self.country}' and \
                ObjectName='{object_name}'"
            )
            meta_details = self.db_obj.run_sql_query(propQuery)[0][0]
            source_id = meta_details[0]
            cs_properties = json.loads(meta_details[1])
            source_object_id = meta_details[3]
            os_properties = json.loads(meta_details[4])

            # Defining control file identifier & Flag
            ctrl_file_identifier = '*CONTROL*'
            if 'control.file.identifier' in cs_properties.keys():
                ctrl_file_identifier = cs_properties['control.file.identifier']
            ctrl_file_flag = (
                re.search(ctrl_file_identifier.lstrip('*'), self.file_name)
            )

            # Extracting Source Type & control file property value
            source_type = cs_properties['sourcing.type']
            ctrl_file = cs_properties['control_file']

            # Defining year, month, date for partitioning
            d = datetime.date.today()
            year = str(d.year)
            month = str(d.strftime('%m'))
            date = str(d.strftime('%d'))

            # Getting schema info from metadata
            schema, schema_info, col_to_cast = self \
                .object_schema_width_rules(source_object_id)

            # Renaming the file if required
            common_path = (
                    f'{data_dest}/{object_name}/{year}/{month}/{date}'
                )
            if object_name not in self.file_name:
                new_file_name = (
                    f'{self.source}_{self.country}_{object_name}_{business_date}.csv'
                )
                destination = (
                    common_path + f'/{new_file_name}'
                )
            else:
                destination = (
                    common_path + f'/{self.file_name}'
                )

            # getting delimiter info
            delimiter = cs_properties['filedelimiter']
            if '.csv' in self.file_name:
                delimiter = ','
            if '\\u0001' in delimiter:
                delimiter = '\u0001'

            # Source File Path
            source_file_path = landing_data_path+'/'+self.file_name
            count = 0
            rts_flag = 0

            # Checking if file is control file
            if ctrl_file_flag:
                LOGGER.info("Moving Control File to raw Zone")
                control_dest = (
                    RAW_ZONE_DATA_PATH.replace(
                        'account', self.adls_account_name
                    ).replace(
                        "source",
                        self.source
                    ).replace(
                        "country",
                        self.country
                    ).replace(
                        "data",
                        "control"
                    )
                )
                self.dbutils.fs.mv(source_file_path, control_dest)
                rts_flag = 1
                LOGGER.info("File Moved Successfully")

            elif source_type == 'BATCH_FIXEDWIDTH':
                fw_df = self.spark.read.option("multiline", "true") \
                    .option("escape", " ") \
                    .text(landing_data_path+'/'+self.file_name)
                if ctrl_file in ('false', 'False'):
                    fw_df = self.extract_header_trailer(
                        fw_df, os_properties,
                        source_object_id,
                        object_name,
                        business_date,
                        source_type
                        )
                # Verify if dataframe is empty or not
                count = fw_df.count()
                if count != 0:
                    width = 1
                    for items in schema_info:
                        fw_df = fw_df \
                            .withColumn(
                                items[0],
                                f.col('value').substr(width, items[2])
                            )
                        width += items[2]
                    cols = [i[0] for i in schema_info]
                    dl_df = fw_df.select(cols)
                    dl_df = self.get_df_with_rules(dl_df, schema_info)
                    dl_df = self.spark.createDataFrame(dl_df.rdd, schema)
                    for key, value in col_to_cast.items():
                        dl_df = dl_df.withColumn(key, f.col(key).cast(value))
                    # Tokenization
                    dl_df = self.tokenization(dl_df, object_name)
                    dl_df = dl_df.coalesce(1).write. \
                        format("csv"). \
                        mode("overwrite"). \
                        option("sep", delimiter). \
                        option("compression", "snappy"). \
                        option("header", "true"). \
                        save(destination)
                else:
                    # Reject the file from ADF
                    output['IsArchived'] = True
                    LOGGER.info("Archiving the filename.")
            else:
                df = self.spark.read \
                    .option("multiline", "true") \
                    .option("escape", " ") \
                    .option('sep', delimiter) \
                    .csv(
                        landing_data_path+'/'+self.file_name,
                        schema=schema,
                        header=None
                    )
                for key, value in col_to_cast.items():
                    df = df.withColumn(key, f.col(key).cast(value))
                if ctrl_file in ('false', 'False'):
                    df = self.extract_header_trailer(
                        df, os_properties,
                        source_object_id,
                        object_name,
                        business_date=business_date
                    )
                df = self.get_df_with_rules(df, schema_info)
                count = df.count()
                if count != 0:
                    # Tokenization
                    df = self.tokenization(df, object_name)
                    # Write dataframe to raw zone
                    df.coalesce(1).write. \
                        format("csv"). \
                        mode("overwrite"). \
                        option("sep", delimiter). \
                        option("compression", "snappy"). \
                        option("header", "true"). \
                        save(destination)
                else:
                    # Reject the file from ADF
                    output['IsArchived'] = True
                    LOGGER.info("Archiving the filename.")

            # Archiving the data file
            if 'IsArchived' in output:
                self.dbutils.fs.mv(source_file_path, landing_archive_path)
                rts_flag = 1
                LOGGER.info("File Archived Successfully.")

            # Logging in Metastore
            LOGGER.info("Logging to Source File table")
            Query = (
                f"""select SourceFileProcessLogID from [EtlLog].[SourceFileProcessLog]
                where PipelineLogID = {self.pipeline_log_id} and filename = 
                '{self.file_name}'"""
            )
            source_file_details = self.db_obj.run_sql_query(Query)[0][0]
            sourcefileprocesslog_id = source_file_details[0]
            param = {
                'SourceFileProcessLogID': sourcefileprocesslog_id,
                'SourceCount': count,
                'SourceId': source_id,
                'SourceObjectId': source_object_id,
                'PipelineLogID': self.pipeline_log_id,
                'IsLandingToRawProcessed': 1,
                'IsRawtoStandardisedProcessed': rts_flag,
                'PipelineStatus': 'Succeeded',
                'TargetCount': None,
                'ErrorCount': None
                }
            self.db_obj.run_stored_proc(
                'ETLlog', 'uspUpdatePipelineLog', params=param
            )

        else:
            LOGGER.info("Date is not available in filename.")

    def get_object_name(self, date_index, file_name_part_list):
        object_name = None
        # Checking if filname has date in it and consists of multiple words
        if date_index is not None and len(file_name_part_list) > 1:
            # Checking naming convention of file
            if (self.source and self.country) not in self.file_name:
                # Checking the object in metastore
                query = (
                    f"select RenameProperties from [Metadata].[RelableObject] \
                        where sourceName = '{self.source}'\
                        and CountryCode = '{self.country}'"
                )
                rename_properties = self.db_obj.run_sql_query(query)[0][0]
                for obj in rename_properties:
                    rename_data_dict = json.loads(obj)
                if rename_data_dict:
                    object_name = (
                        "_".join(file_name_part_list[0:date_index])
                    )
                    if object_name in rename_data_dict.keys():
                        object_name = (
                            rename_data_dict[object_name]
                        )
                    else:
                        LOGGER.info("Object not available in properties.")
                else:
                    LOGGER.info("Rename properties is not available.")
            else:
                # Extracting object name from filename
                object_name = (
                    "_".join(file_name_part_list[2:date_index])
                )
        return object_name

    def tokenization(self, df, object_name):
        # Creating temp view for tokenization
        # filename = self.file_name.split('.')[0].replace('$', '')
        # df.createOrReplaceTempView(filename)
        # param = {'objectname': object_name}
        # tokenCols = self.db_obj.run_stored_proc(
        #     'dbo', 'usp_RetrieveTokenizedColumns', params=param
        # )
        # registring function
        # self.sqlContext \
        #     .sql("create or replace temporary function ptyProtectString as 'com.protegrity.hive.udf.ptyProtectStr'")
        # self.sqlContext \
        #     .sql("create or replace temporary function ptyUNprotectstring as 'com.protegrity.hive.udf.ptyUnprotectStr'")
        # Tokenizing data
        # if tokenCols[0][0]:
        #     columnlist = tokenCols[0][0]
        #     query = "select "+columnlist+" from "+filename
        #     df = self.spark.sql(query)
        return df

    def object_schema_width_rules(self, source_object_id, stype=None):
        '''
        This method is used to extract schema,
        width and rules information from metastore and
        create a structtype schema for spark.
        '''
        if stype:
            query = (
                f"select ColumnName, DataType, \
                Width, [Rule], IsPrimaryKey, Length, \
                isnullable from [Metadata].[SourceObjectMetadataSchema]  \
                where SourceObjectID = {source_object_id} and \
                SchemaType = '{stype}' \
                and IsActive = 1 order by ColumnOrder"
            )
        else:
            query = (
                f"select ColumnName, DataType, \
                Width, [Rule], IsPrimaryKey, Length, \
                isnullable from [Metadata].[SourceObjectSchema]  \
                where SourceObjectID = {source_object_id} and \
                IsActive = 1 order by ColumnOrder"
            )
        schema_info = self.db_obj.run_sql_query(query)[0]
        schema = t.StructType()
        col_to_cast = {}
        for items in schema_info:
            col = items[0]
            if (items[1] == 'integer') or ('decimal' in items[1]):
                schema.add(col, 'string', True)
                col_to_cast[col] = items[1]
            else:
                schema.add(col, items[1].lower(), True)
        return schema, schema_info, col_to_cast

    def get_df_with_rules(self, df, schema_info):
        '''
        This method is used to apply the rules
        on Columns.
        '''
        for item in schema_info:
            rule_info = item[3]
            column = item[0]
            if rule_info:
                if rule_info.startswith("Trim"):
                    replace_to = rule_info.rstrip(',').lstrip('(').split(')')[0] \
                        .split(',')[0].strip("'")
                    replace_by = rule_info.rstrip(',').lstrip('(').split(')')[0] \
                        .split(',')[1].strip("'")
                    df = df.withColumn(
                        column, f.regexp_replace(
                            column, replace_to, replace_by
                        )
                    )
                elif rule_info == "ReplaceWhiteSpaces('0')":
                    replace_to = ' '
                    replace_by = rule_info \
                        .strip('ReplaceWhiteSpaces') \
                        .strip("('") \
                        .strip("')")
                    df = df.withColumn(
                        column, f.regexp_replace(
                            column, replace_to, replace_by
                        )
                    )
                elif rule_info.startswith("DIVIDE"):
                    N = int(
                        rule_info.split(',')[0].strip('DIVIDE').strip("(").strip(")")
                    )
                    replace_to = ' '
                    replace_by = rule_info.split(',')[1]. \
                        strip('ReplaceWhiteSpaces'). \
                        strip("('") \
                        .strip("')")
                    df = df.withColumn(
                        column,
                        f.col(column).cast(t.DoubleType())
                        ) \
                        .withColumn(column, f.col(column)/N) \
                        .withColumn(column, f.regexp_replace(
                            column, replace_to, replace_by)
                        )
                    if 'DECIMAL' in item[1]:
                        df = df.withColumn(
                            column, f.col(column).cast(t.DecimalType())
                        )

        return df

    def extract_header_trailer(
        self,
        df,
        os_properties,
        source_object_id,
        object_name,
        business_date,
        stype=None
    ):
        '''
        This method is used to extract header & trailer data
        from dataframe and store it in metastore.
        '''
        icol = df.columns[0]
        prop_ex = f'{self.source}_{self.country}_{object_name}'
        h_ind = os_properties[f'{prop_ex}.headerindicator']
        tr_ind = os_properties[f'{prop_ex}.trailerindicator']
        if (h_ind == '') or (tr_ind == ''):
            h_ind = 'H'
            tr_ind = 'T'
        header = df.filter(f.col(icol).startswith(h_ind))
        trailer = df.filter(f.col(icol).startswith(tr_ind))
        if (header.count() or trailer.count()) != 0:
            df = df.filter(~f.col(icol).startswith(h_ind)) \
                .filter(~f.col(icol).startswith(tr_ind))
            # Getting Schema for header & trailer
            hschema, hschema_info, hcol_to_cast = (
                self.object_schema_width_rules(
                    source_object_id, 'headercolschema'
                )
            )
            tschema, tschema_info, tcol_to_cast = (
                self.object_schema_width_rules(
                    source_object_id, 'trailercolschema'
                )
            )
            if stype == 'BATCH_FIXEDWIDTH':
                hwidth = 1
                for items in hschema_info:
                    header = header \
                        .withColumn(
                            items[0], f.col(icol).substr(hwidth, items[2])
                        )
                    hwidth += items[2]
                twidth = 1
                for items in tschema_info:
                    if items[2]:
                        awidth = items[2]
                    else:
                        awidth = 8
                    trailer = trailer \
                        .withColumn(
                            items[0], f.col(icol).substr(twidth, awidth)
                        )
                    twidth += awidth
            else:
                header = header.select(header.columns[:len(hschema_info)])
                trailer = trailer.select(trailer.columns[:len(tschema_info)])
                header = self.spark.createDataFrame(header.rdd, hschema)
                trailer = self.spark.createDataFrame(trailer.rdd, tschema)
                for key, value in tcol_to_cast.items():
                    trailer = trailer.withColumn(key, f.col(key).cast(value))
                for key, value in hcol_to_cast.items():
                    header = header.withColumn(key, f.col(key).cast(value))
            Metadata = {'header': header.collect()[0].asDict(),
                        'trailer': trailer.collect()[0].asDict()}
            row_count = Metadata['trailer']['ROWCOUNT']
            param = {
                'SourceObjectID': source_object_id,
                'Metadata': json.dumps(Metadata),
                'RowCount': row_count,
                'BusinessDate': business_date
                }
            self.db_obj.run_stored_proc(
                'ETLlog', 'SourceFileHeaderTrailerLogProc', params=param
            )
        return df

    def run(self):
        '''
        This method is used to run the Landing to raw pipeline
        end-to-end.
        '''
        LOGGER.info("Starting Landing to Raw pipeline")
        LOGGER.info("Started Initialisation")
        self.config, self.db_obj = initialise(
            self.spark, self.spn_credentials, self.kv_name,
            self.adls_account_name, self.config_path
        )
        LOGGER.info("Ended Initialisation")
        LOGGER.info("Starting Processing Data Files")
        self.landing_to_raw_processor()
