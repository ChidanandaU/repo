import json
import pandas as pd

from edm.utils.const import (
    LANDING_ZONE_CONFIG_PATH, SQL_ADBK_DTYPE_MAP, RAW_ZONE_CONFIG_PATH)
from edm.utils.general_helper import (
    initialise, get_filename_date_index
)
from edm.utils.logging_utility import get_logger

LOGGER = get_logger(__name__)


class ParamConfigParser:
    '''
    This class is used to parse the config and Param files for
    the data file being processed from landing to raw zone
    '''
    def __init__(self, source, country, file_name, spark, dbutils, **kwargs):
        '''
        This instantiates a Param Config Parser Object
        '''
        self.source = source
        self.country = country
        self.file_name = file_name
        self.spark = spark
        self.dbutils = dbutils
        self.spn_credentials = kwargs.get("spn_credentials", None)
        self.kv_name = kwargs.get("kv_name", None)
        self.adls_account_name = kwargs.get("adls_account_name", None)
        self.config_path = kwargs.get("config_path", None)

    def parse_param_config(self):
        '''
        This method is used to get the list of param and config files for
        the data file being processed, parse the xml and save the properties
        to the DB in respective tables.
        '''
        param_dest = RAW_ZONE_CONFIG_PATH.replace(
            'account', self.adls_account_name
        )
        landing_config_path = (
            LANDING_ZONE_CONFIG_PATH.replace(
                "container",
                self.config['blob_details'][0]['incoming_container_name']
                ).replace(
                    "account",
                    self.config['blob_details'][0]['name']
                ).replace(
                    "source",
                    self.source
                ).replace(
                    "country",
                    self.country
                )
        )
        dbutils_files_list = self.dbutils.fs.ls(landing_config_path)
        file_process_flag = True
        param_file_name = None
        config_file_name = None
        rename_config_file_name = None
        rename_file_flag = False
        rename_data_dict = {}
        file_name_wo_sc_date = None
        cs_prop = None
        cdc_file_flag = False

        # Fetching date index from file name
        if '.D' in self.file_name:
            cdc_file_flag = True
            file_name_part_list = self.file_name.split(".")
            # business_date = file_name_part_list[1].strip('D')
            file_name_wo_sc_date = file_name_part_list[0].lower()
        else:
            date_index = get_filename_date_index(self.file_name)
            file_name_part_list = self.file_name.split("_")

            # TODO : check for rename.xml everytime
            # Checking if filname has date in it and consists of multiple words
            if date_index is not None and len(file_name_part_list) > 1:
                # Checking naming convention of file
                if (self.source and self.country) not in self.file_name:
                    rename_file_flag = True
                    rename_config_file_name = (
                        f'{self.source}_{self.country}_tables_rename.xml'
                    )
                    # Checking for rename.xml
                    file_row_list = ParamConfigParser._get_file_row_list(
                        dbutils_files_list,
                        param_file_name,
                        config_file_name,
                        rename_config_file_name
                    )
                    if file_row_list:
                        LOGGER.info("Getting Rename Properties from config")
                        filepath = file_row_list[0]
                        file_name = filepath.name
                        rename_prop = self.get_config_properties(
                            file_name, landing_config_path
                        )
                        for key, value in rename_prop.items():
                            if '.rename.' in key:
                                dict_key = key.split(f'_{self.country}_')[1]
                                dict_value = (
                                    value.split(f'_{self.country}_')[1]
                                )
                                rename_data_dict[dict_key] = dict_value
                        # Inserting data in Metastore
                        params = {
                            'SourceName': self.source,
                            'CountryCode': self.country,
                            'RenameProperties': json.dumps(rename_data_dict)
                        }
                        sp_name = 'uspUpdateRelableObject'
                        schema = 'metadata'
                        self.db_obj.run_stored_proc(schema, sp_name, params)
                    else:
                        # Checking the object in metastore
                        query = (
                            f"select RenameProperties from [Metadata].[RelableObject] \
                                where sourceName = '{self.source}'\
                                and CountryCode = '{self.country}'"
                        )
                        rename_properties = self.db_obj.run_sql_query(query)[0][0]
                        for obj in rename_properties:
                            rename_data_dict = json.loads(obj)

                    # Fetching object name from filename
                    object_name = (
                        "_".join(file_name_part_list[0:date_index])
                    )
                    if object_name in rename_data_dict.keys():
                        file_name_wo_sc_date = (
                            rename_data_dict[object_name]
                        )
                    else:
                        LOGGER.info(
                            "Alternative name not present for file"
                        )
                        file_process_flag = False
            else:
                LOGGER.info("Filename is incorrect")
                file_process_flag = False

        if file_process_flag:
            if (rename_file_flag and cdc_file_flag) is False:
                file_name_wo_sc_date = (
                    "_".join(file_name_part_list[2:date_index])
                )
            if file_name_wo_sc_date:
                config_file_flag = False
                param_file_flag = False
                param_file_name = f'{self.source}_{self.country}_param.xml'
                config_file_name = (
                    f'{self.source}_{self.country}_{file_name_wo_sc_date}'
                )
                config_file_name += "_tables_config.xml"
                file_row_list = ParamConfigParser._get_file_row_list(
                    dbutils_files_list,
                    param_file_name,
                    config_file_name,
                    rename_config_file_name
                )
                if len(file_row_list) != 0:
                    if param_file_name in file_row_list:
                        file_row_list.sort(key=lambda x: x != param_file_name)
                    for filepath in file_row_list:
                        file_name = filepath.name
                        file_type = file_name.split("_")[-1]
                        if file_type == 'config.xml':
                            config_file_flag = True
                            LOGGER.info(
                                "Getting Object Properties from config"
                            )
                            os_prop = self.get_config_properties(
                                file_name, landing_config_path
                            )
                            source_type = (
                                os_prop[
                                    f'{self.source}_{self.country}_{file_name_wo_sc_date}.sourcetype'
                                    ]
                            )
                            os_prop_str = json.dumps(os_prop)
                            schema_list = self.get_object_schema(
                                os_prop, self.source, self.country,
                                file_name_wo_sc_date, cs_prop
                            )
                            schema_df = pd.DataFrame(schema_list)
                            schema_df['ColumnOrder'] = schema_df.index+1
                            schema_df['IsActive'] = 1
                            schema_df['Source'] = self.source
                            schema_df['Country'] = self.country
                            schema_df['ObjectName'] = file_name_wo_sc_date
                        if file_type == 'param.xml':
                            param_file_flag = True
                            LOGGER.info(
                                "Getting Country Source Properities from Param"
                            )
                            cs_prop = self.get_config_properties(
                                file_name, landing_config_path
                            )
                            cs_prop_str = json.dumps(cs_prop)
                    if param_file_flag:
                        params = {
                            'SourceName': self.source,
                            'CountryCode': self.country,
                            'Property': cs_prop_str
                        }
                        schema = 'metadata'
                        sp_name = 'uspUpdateSourceMaster'
                        self.db_obj.run_stored_proc(schema, sp_name, params)
                        self.dbutils.fs.mv(
                            landing_config_path.rstrip('/') + '/' + param_file_name,
                            param_dest.rstrip('/') + '/' + param_file_name
                        )
                    if config_file_flag:
                        params = {
                            'SourceName': self.source,
                            'CountryCode': self.country,
                            'TableName': file_name_wo_sc_date,
                            'Property': os_prop_str.replace("'", "''"),
                            'SourceType': source_type
                        }
                        sp_name = 'uspUpdateSourceObjectDetail'
                        schema = 'metadata'
                        self.db_obj.run_stored_proc(schema, sp_name, params)

                        schema_df['Rules'] = schema_df['Rules'].apply(
                            lambda x: x.replace("'", "''") if x is not None else x
                        )

                        schema_type = ['col_schema', 'headercolschema']
                        for stype in schema_type:
                            if stype != 'col_schema':
                                final_df = schema_df[schema_df['SchemaType'].notnull()]
                                stored_proc = 'uspInsertObjectMetadataSchema'
                                table_type = (
                                    'TableType_SourceObjectMetadataSchema'
                                )
                            else:
                                final_df = (
                                    schema_df[schema_df['SchemaType'].isnull()]
                                )
                                final_df = final_df.drop(
                                    ['SchemaType'], axis=1
                                )
                                stored_proc = 'uspInsertObjectSchema'
                                table_type = 'TableType_SourceObjectSchema'
                            if not final_df.empty:
                                self.db_obj.insert_data_from_df(
                                    schema,
                                    stored_proc,
                                    final_df,
                                    table_type
                                )
                else:
                    LOGGER.info("No Param and Config Files in Blob Account.")
            else:
                LOGGER.info("Object name is not available.")
        else:
            LOGGER.info(
                '''
                File name is not is correct format
                or rename config is not available.
                '''
            )

    def get_object_schema(
        self,
        os_prop,
        source,
        country,
        object_name,
        cs_prop
    ):
        '''
        This method prepares the schema dict from the col_schema Object
        Property.
        '''
        LOGGER.info('Getting Source Object Schema')
        schema_list = []
        key_base_str = f'{source}_{country}_{object_name}'
        schema_type = ['col_schema', 'headercolschema', 'trailercolschema']
        for type in schema_type:
            if type in ('headercolschema', 'trailercolschema'):
                if key_base_str + '.' + type not in os_prop:
                    continue
            column_schema_str = os_prop[f'{key_base_str}.{type}']
            if f'{key_base_str}.keycols' not in os_prop.keys():
                os_prop[f'{key_base_str}.keycols'] = ''
            key_cols_str = os_prop[f'{key_base_str}.keycols']
            if key_cols_str != '':
                key_cols_list = key_cols_str.split(",")
            else:
                key_cols_list = []

            # removing comments from the string as that is not required
            column_schema_str = column_schema_str.replace('COMMENT', '')
            # not null to not_null so that on splitting, it does not become two
            # items
            column_schema_str = column_schema_str.replace(
                'NOT NULL', 'NOT_NULL'
            )
            column_schema_str = column_schema_str.replace("''", "")
            column_schema_str = column_schema_str.replace("'NULL'", '')

            col_schema_list = column_schema_str.split('^')
            col_schema_list_new = [item.strip() for item in col_schema_list]

            # get column properties for each column in col_schema_list from
            # col_schema_str
            for col_str in col_schema_list_new:
                col_part_list = col_str.split(' ')
                if 'WIDTH' in col_part_list:
                    file_type = 'FIXEDWIDTH'
                else:
                    file_type = 'DELIMITED'
                col_dict = dict()
                column_name = col_part_list[0]
                source_dtype = col_part_list[1]
                col_dict['ColumnName'] = column_name
                col_dict['SourceDataType'] = source_dtype

                # getting the column's Databricks Data Type
                source_dtype_wo_bracket = source_dtype
                length = None
                if "(" in source_dtype and ('DECIMAL' not in source_dtype):
                    bracket_start_index = source_dtype.index('(')
                    bracket_end_index = source_dtype.index(')')
                    source_dtype_wo_bracket = (
                        source_dtype[0:bracket_start_index]
                    )
                    if ',' not in source_dtype[bracket_start_index+1:bracket_end_index]:
                        length = int(source_dtype[bracket_start_index+1:bracket_end_index])
                if source_dtype_wo_bracket in SQL_ADBK_DTYPE_MAP:
                    adbk_dtype = SQL_ADBK_DTYPE_MAP[source_dtype_wo_bracket]
                elif source_dtype_wo_bracket == 'DATE' or source_dtype_wo_bracket == 'TIMESTAMP':
                    adbk_dtype == 'STRING'
                    property = 'datecolformat'
                    prop_val = 'yyyy-MM-dd'
                    if source_dtype_wo_bracket == 'TIMESTAMP':
                        property = 'timestampcolformat'
                        prop_val = 'yyyy-MM-dd HH:mm:ss'
                    if cs_prop:
                        if cs_prop[property] == prop_val:
                            adbk_dtype == source_dtype_wo_bracket.lower()
                    else:
                        # propQuery = (
                        #     f"select CountrySourceProperties from [Metadata].[SourceMaster] \
                        #     where SourceName='{self.source}' and \
                        #     CountryCode='{self.country}'"
                        # )
                        # meta_details = (
                        #     self.db_obj.run_sql_query(propQuery)[0][0]
                        # )
                        if cs_prop:
                            # cs_prop = json.loads(meta_details[0])
                            if cs_prop[property] == prop_val:
                                adbk_dtype = source_dtype_wo_bracket.lower()
                else:
                    adbk_dtype = source_dtype

                col_dict['DataType'] = adbk_dtype
                if length is None:
                    length = 0
                col_dict['Length'] = str(length)
                if type != 'col_schema':
                    col_dict['SchemaType'] = type
                else:
                    col_dict['SchemaType'] = None

                # Checking if the column is nullable or not
                if 'NOT_NULL' in col_part_list:
                    col_dict['IsNullable'] = 0
                else:
                    col_dict['IsNullable'] = 1

                # check if the column is primary key or not
                if column_name in key_cols_list:
                    col_dict['IsPrimaryKey'] = 1
                else:
                    col_dict['IsPrimaryKey'] = 0

                # check if rule is present or not
                LOGGER.info(f'Getting Rules for {column_name}')
                if 'RULES' in col_part_list:
                    # Rules can be separated either by , or ' '
                    rules_str = col_str.split("RULES")[1].strip()
                    # checking the delimiter of the rules str
                    if " " in rules_str:
                        # the rules are separated by space then
                        rules_str = rules_str.replace(" ", ",")
                    col_dict['Rules'] = rules_str
                else:
                    col_dict['Rules'] = None

                if file_type == 'DELIMITED':
                    col_dict['Width'] = None
                # fetching width and rule info for FIXEDWIDTH file
                else:
                    width_str_index = col_part_list.index('WIDTH')
                    col_dict['Width'] = col_part_list[width_str_index+1]
                schema_list.append(col_dict)
        return schema_list

    def get_config_properties(self, param_file_name, landing_config_path):
        '''
        This method is used to read the xml file as a text, parse it
        into a dict and return the dict
        '''
        param_file_full_path = (
            landing_config_path.rstrip('/') + '/' + param_file_name
        )
        param_df = (
            self.spark.read.format("text").option("multiline", "true")
            .load(param_file_full_path)
        )
        prop_dict = ParamConfigParser.parse_text_xml_to_dict(
            param_df
        )
        return prop_dict

    @staticmethod
    def _get_file_row_list(
        dbutils_file_list,
        param_file_name,
        config_file_name,
        rename_config_file_name
    ):
        '''
        This method is used to filter the dbutils file list in incoming/config
        folder to search for param and config file for the data file being
        processed.
        '''
        file_row_list = []
        if dbutils_file_list:
            for file_row in dbutils_file_list:
                if (param_file_name and config_file_name is not None):
                    if file_row.name in [param_file_name, config_file_name]:
                        file_row_list.append(file_row)
                    else:
                        continue
                else:
                    if file_row.name in [rename_config_file_name]:
                        file_row_list.append(file_row)
                    else:
                        continue
        else:
            LOGGER.info("No Config Files Found in Config Folder")
        return file_row_list

    @staticmethod
    def parse_text_xml_to_dict(spark_xml_df):
        '''
        This method is used to convert the xml read as spark df
        to a dict
        '''
        LOGGER.info("Parsing Texttual xml to dict")
        prop_dict = dict()
        pd_xml_df = spark_xml_df.toPandas()
        for index, row in pd_xml_df.iterrows():
            if "<name>" in row.value and "</name>" in row.value:
                key_value = (
                    row.value.replace("<name>", "").
                    replace("</name>", "").strip()
                )
                key_value = key_value.replace("edmhdpif.table.", "")
                key_value = key_value.replace("edmhdpif.config.", "")
                value = pd_xml_df.iloc[index+1].values[0]
                value_start = value.index("<value>") + len("<value>")
                value_end = value.index("</value>")
                actual_value = value[value_start:value_end]
                prop_dict[key_value] = actual_value
        return prop_dict

    def run(self):
        '''
        This method is used to run the param config parser pipeline
        end-to-end.
        '''
        LOGGER.info("Starting config Param Parser")
        LOGGER.info("Started Initialisation")
        self.config, self.db_obj = initialise(
            self.spark, self.spn_credentials, self.kv_name,
            self.adls_account_name, self.config_path
        )
        LOGGER.info("Ended Initialisation")
        LOGGER.info("Starting Parsing XML Files")
        self.parse_param_config()
