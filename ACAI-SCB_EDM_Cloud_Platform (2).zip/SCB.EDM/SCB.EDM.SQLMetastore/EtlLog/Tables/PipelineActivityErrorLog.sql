﻿CREATE TABLE [EtlLog].[PipelineActivityErrorLog] (
    [PipelineActivityErrorLogID] INT            IDENTITY (1, 1) NOT NULL,
    [PipelineActivityLogID]      INT            NOT NULL,
    [ErrorMessage]               NVARCHAR (MAX) NULL,
    [CreatedBy]                  NVARCHAR (100) DEFAULT (suser_name()) NOT NULL,
    [CreatedOn]                  DATETIME       DEFAULT (switchoffset(sysdatetimeoffset(),'+05:30')) NOT NULL,
    [ModifiedBy]                 NVARCHAR (100) DEFAULT (suser_name()) NOT NULL,
    [ModifiedOn]                 DATETIME       DEFAULT (switchoffset(sysdatetimeoffset(),'+05:30')) NOT NULL,
    FOREIGN KEY ([PipelineActivityLogID]) REFERENCES [EtlLog].[PipelineActivityLog] ([PipelineActivityLogID])
);

