﻿/***************************************************************************************************
-- <copyright file="EtlLog.uspGetFileSlicesToProcess.sql" company="Bajaj Finserv and Microsoft Corporation">
-- Copyright (c) Bajaj Finserv and Microsoft Corporation. All rights reserved.
-- THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, 
-- INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
-- </copyright>

Procedure:          EtlLog.uspGetFileSlicesToProcess
Create Date:        2019-04-30
Author:             Lakesh
Description:        To get all the slices to process for the file based on last success.
Call by:              
Affected table(s):   
                    
Used By:            Functional Area this is used in
Parameter(s):       @SourceID - source ID,
					@SliceDateTime - slice date time,
					@ToBeResumed - to be resumed
					@LoadType - load type

Usage:              EXEC EtlLog.[uspGetFileSlicesToProcess]
						@SourceObjectID = '1',
						@SliceDateTime = '2019-04-24 09:06:19.260',
						@LastRefreshDateTime = '2019-04-25 09:06:19.260'
						
****************************************************************************************************
SUMMARY OF CHANGES
Date(yyyy-mm-dd)    Author              Comments
------------------- ------------------- ------------------------------------------------------------

***************************************************************************************************/
CREATE PROCEDURE [EtlLog].[uspGetFileSlicesToProcess]
( 
  @SourceObjectID INT,
  @SliceDateTime DATETIME,
  @LastRefreshDateTime DATETIME
)
AS 
BEGIN

	SET NOCOUNT ON;

	;WITH cteSlicesToBeRun
	AS
	(
		SELECT [SliceDateTime], [PipelineStatus], ROW_NUMBER() OVER(PARTITION BY [SliceDateTime] ORDER BY [StartTime] DESC) AS RowNumber
		  FROM [EtlLog].[PipelineLog] WITH (NOLOCK)
		 WHERE [SliceDateTime] > @LastRefreshDateTime
		   AND [SliceDateTime] <= @SliceDateTime
		   AND [SourceObjectID] = @SourceObjectID
	)
	SELECT [SliceDateTime]
	FROM cteSlicesToBeRun
	WHERE RowNumber = 1
	AND [PipelineStatus] NOT IN ('Succeeded')
	ORDER BY [SliceDateTime] ASC

END