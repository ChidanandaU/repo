﻿/***************************************************************************************************
-- <copyright file="EtlLog.uspUpdateSourceFileProcessLog.sql" company="Bajaj Finserv and Microsoft Corporation">
-- Copyright (c) Bajaj Finserv and Microsoft Corporation. All rights reserved.
-- THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, 
-- INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
-- </copyright>

Procedure:          EtlLog.uspUpdateSourceFileProcessLog
Create Date:        2019-04-22
Author:             LAKESH
Description:        To update SOURCE FILE PROCESS Log.
Call by:              
Affected table(s):  [EtlLog].[SourceFileProcessLog]
                    
Used By:            Functional Area this is used in
Parameter(s):       @PipelineLogID - PIPELINE LOG ID,
					@fileList - a type of EtlLog.SourceFileList

Usage:              DECLARE @tbl [dbo].[SourceFileList]
					INSERT @tbl	 select 'abs.txt',20,12,8	

					EXEC EtlLog.[uspUpdateSourceFileProcessLog]
						@PipelineLogID=1,
						@fileList=@tbl
						
****************************************************************************************************
SUMMARY OF CHANGES
Date(yyyy-mm-dd)    Author              Comments
------------------- ------------------- ------------------------------------------------------------
2019-04-24          Durgesh Nandini     Added Headers

***************************************************************************************************/
CREATE PROCEDURE [EtlLog].[uspUpdateSourceFileProcessLog]
(
@PipelineLogID INT,
@FileList AS [EtlLog].[SourceFileList] READONLY
)
AS
BEGIN

	MERGE [EtlLog].[SourceFileProcessLog] AS TARGET  
    USING (SELECT @PipelineLogID, [FileName], [RecordCount] FROM @FileList) AS SOURCE ([PipelineLogID], [FileName], [RecordCount])  
    ON (TARGET.[PipelineLogID] = SOURCE.[PipelineLogID]
		AND TARGET.[FileName] = SOURCE.[FileName])  
    WHEN MATCHED THEN   
        UPDATE SET 
			[RecordCount] = SOURCE.[RecordCount],
			[ModifiedOn] = SWITCHOFFSET(SYSDATETIMEOFFSET(), '+05:30'),
			[ModifiedBy] = SUSER_NAME()
	WHEN NOT MATCHED THEN  
		INSERT ([PipelineLogID], [FileName], [RecordCount])  
		VALUES (SOURCE.[PipelineLogID], SOURCE.[FileName], SOURCE.[RecordCount]);

END