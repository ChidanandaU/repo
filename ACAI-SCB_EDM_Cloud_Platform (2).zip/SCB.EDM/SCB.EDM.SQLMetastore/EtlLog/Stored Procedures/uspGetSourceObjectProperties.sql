﻿/***************************************************************************************************
-- <copyright file="EtlLog.uspGetSourceObjectProperties.sql" company="Bajaj Finserv and Microsoft Corporation">
-- Copyright (c) Bajaj Finserv and Microsoft Corporation. All rights reserved.
-- THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, 
-- INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
-- </copyright>

Procedure:          EtlLog.uspGetSourceObjectProperties
Create Date:        2019-04-22
Author:             Lakesh
Description:        To get Source object properties.
Call by:              
Affected table(s):   
                    
Used By:            Functional Area this is used in
Parameter(s):       @SourceID - source ID,
					@SourceObjectID - Source Object ID.

Usage:              EXEC EtlLog.[uspGetSourceObjectProperties]
						@SourceID = '1',
						@SourceObjectID =1
						
****************************************************************************************************
SUMMARY OF CHANGES
Date(yyyy-mm-dd)    Author              Comments
------------------- ------------------- ------------------------------------------------------------


***************************************************************************************************/

CREATE PROCEDURE [EtlLog].[uspGetSourceObjectProperties]
( 
  @SourceID INT,
  @SourceObjectID INT,
  @SliceDateTime DATETIME,
  @LoadType NVARCHAR(50)
)
AS
BEGIN
	
	SET NOCOUNT ON;

	BEGIN TRY

		DECLARE @ObjectProperties NVARCHAR(MAX),
				@FrequencyDurationUnit NVARCHAR(50),
				@SourceName NVARCHAR (200),
				@ObjectGroup NVARCHAR(200),
				@ObjectName NVARCHAR(200),
				@LandingFolderPath NVARCHAR(1000),
				@LandingFolderDatePatition NVARCHAR(1000)

		-- Get Source Name.
		SELECT @SourceName = [SourceName] FROM [Metadata].[SourceMaster] WITH (NOLOCK) WHERE [SourceID] = @SourceID

		-- Get the Object Properties.
		SELECT 
			@FrequencyDurationUnit = ISNULL(SOD.[FrequencyDurationUnit], SM.[FrequencyDurationUnit]),
			@ObjectProperties = SOD.[ObjectProperties], 
			@ObjectGroup = SOD.[ObjectGroup],
			@ObjectName = SOD.[ObjectName]
		 FROM [Metadata].[SourceObjectDetail] SOD WITH (NOLOCK) 
		 INNER JOIN [Metadata].[SourceMaster] SM
		 ON SM.[SourceID] = SOD.[SourceID]
		 WHERE [SourceObjectID] = @SourceObjectID

		-- Set landing folder path.
		SET @LandingFolderPath = CONCAT('data/', @ObjectGroup, '/', @ObjectName)

		-- Set landing folder path based on frequency.
		SET @LandingFolderDatePatition =
		CASE 
			WHEN @FrequencyDurationUnit = 'YEAR'
			THEN 
				CONVERT(NVARCHAR(14), YEAR(@SliceDateTime))
			WHEN @FrequencyDurationUnit = 'MONTH'
			THEN 
				CONVERT(NVARCHAR(14), FORMAT(@SliceDateTime, 'yyyy/MM'))
			WHEN @FrequencyDurationUnit = 'DAY'
			THEN 
				CONVERT(NVARCHAR(14), FORMAT(@SliceDateTime, 'yyyy/MM/dd'))
			WHEN @FrequencyDurationUnit = 'HOUR'
			THEN 
				CONVERT(NVARCHAR(14), FORMAT(@SliceDateTime, 'yyyy/MM/dd/HH'))
			WHEN @FrequencyDurationUnit = 'MINUTE'
			THEN 
				CONVERT(NVARCHAR(14), FORMAT(@SliceDateTime, 'yyyy/MM/dd/mm'))
		END
		
		-- Check for JSON validity.
		IF (ISJSON(@ObjectProperties) = 1)
			BEGIN
				IF @SourceName = 'EDW'
						SELECT
							LOWER(@SourceName) AS SourceName,
							@ObjectGroup AS SchemaName,
							@ObjectName AS TableName,
							LOWER(CONCAT(@LandingFolderPath, '/', @LandingFolderDatePatition)) AS LandingFolderPath,
							NULLIF(TRIM(JSON_VALUE(@ObjectProperties, '$.dataExtractFilter')), '') AS DataExtractFilter

			ELSE IF @SourceName = 'FinnOne'

				BEGIN
					IF @LoadType = 'Full'
						SET @LoadType = 'Initial'

							SELECT
								LOWER(@SourceName) AS SourceName,
								LOWER(CONCAT(@LandingFolderPath, '/', @LoadType, '/', @LandingFolderDatePatition)) AS LandingFolderPath,
								CASE 
									WHEN @LoadType = 'Initial'
									THEN REPLACE(
										REPLACE(
										REPLACE(
										REPLACE( 
										REPLACE(
										REPLACE(
										REPLACE(JSON_VALUE(@ObjectProperties, '$.initial.sourceFolderPath'), 
											'{SourceName}', @SourceName),
											'{ObjectGroup}', @ObjectGroup),
											'{ObjectName}', @ObjectName), 
											'{year}', YEAR(@SliceDateTime)),
											'{month}', FORMAT(@SliceDateTime, 'MM')),
											'{day}', FORMAT(@SliceDateTime, 'dd')),
											'{minute}', FORMAT(@SliceDateTime, 'mm'))

									WHEN @LoadType = 'Incremental'
									THEN REPLACE(
										REPLACE(
										REPLACE(
										REPLACE( 
										REPLACE(
										REPLACE(
										REPLACE(JSON_VALUE(@ObjectProperties, '$.incremental.sourceFolderPath'), 
											'{SourceName}', @SourceName),
											'{ObjectGroup}', @ObjectGroup),
											'{ObjectName}', @ObjectName), 
											'{year}', YEAR(@SliceDateTime)),
											'{month}', FORMAT(@SliceDateTime, 'MM')),
											'{day}', FORMAT(@SliceDateTime, 'dd')),
											'{minute}', FORMAT(@SliceDateTime, 'mm'))
									END	AS SourceFolderPath,
								
								CASE 
									WHEN @LoadType = 'Initial'
									THEN JSON_VALUE(@ObjectProperties, '$.initial.fileFilter') 
									WHEN @LoadType = 'Incremental'
									THEN JSON_VALUE(@ObjectProperties, '$.incremental.fileFilter') 
								END AS FileFilter
					END
				
				END
		ELSE
			RAISERROR('The Object properties is not in a valid JSON format.', 16, 1);

	END TRY
	BEGIN CATCH
		THROW;		
	END CATCH
END