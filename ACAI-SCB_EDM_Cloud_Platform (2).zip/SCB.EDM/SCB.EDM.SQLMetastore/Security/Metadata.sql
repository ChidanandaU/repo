﻿CREATE SCHEMA [Metadata]
    AUTHORIZATION [dbo];

