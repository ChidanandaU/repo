﻿/***************************************************************************************************
-- <copyright file="Recon.uspUpdateQualitativePipelineLog.sql" company="Bajaj Finserv and Microsoft Corporation">
-- Copyright (c) Bajaj Finserv and Microsoft Corporation. All rights reserved.
-- THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, 
-- INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
-- </copyright>

Procedure:          Recon.uspUpdateQualitativePipelineLog
Create Date:        2019-09-13
Author:             LAKESH
Description:        To update QualitativePipelineLog.
Call by:              
Affected table(s):  [Recon].[Recon.uspUpdateQualitativePipelineLog]
                    
Used By:            Functional Area this is used in
Parameter(s):       @PipelineLogID - PIPELINE LOG ID,
					@PipelineStatus - PIPELINE STATUS

Usage:              EXEC Recon.uspUpdateQualitativePipelineLog
						@PipelineLogID=1,
						@PipelineStatus='Success'
						
****************************************************************************************************
SUMMARY OF CHANGES
Date(yyyy-mm-dd)    Author              Comments
------------------- ------------------- ------------------------------------------------------------

***************************************************************************************************/

CREATE PROCEDURE [Recon].[uspUpdateQualitativePipelineLog]
( @PipelineLogID INT,
  @PipelineStatus NVARCHAR(50)
)
AS 
BEGIN
	
	SET NOCOUNT ON;

	BEGIN TRY

			IF @PipelineLogID IS NOT NULL
			BEGIN

				-- In case this is the master pipeline and child pipelines failed, then fail the master pipeline as well.
				IF (@PipelineStatus = 'Succeeded' AND (EXISTS (SELECT 1 FROM [Recon].[QualitativePipelineLog] WITH (NOLOCK)
									WHERE [ParentPipelineLogID] = @PipelineLogID
									AND [PipelineStatus] != 'Succeeded'
						  ))
					)
					SET @PipelineStatus = 'Failed'

				UPDATE [Recon].[QualitativePipelineLog]
				SET
					[PipelineStatus] = @PipelineStatus,
					[EndTime] = SWITCHOFFSET(SYSDATETIMEOFFSET(), '+05:30'),
					[ModifiedOn] = SWITCHOFFSET(SYSDATETIMEOFFSET(), '+05:30'),
					[ModifiedBy] = SUSER_NAME()
				WHERE [ParentPipelineLogID] = @PipelineLogID
				AND [PipelineStatus] NOT IN ('Succeeded', 'Failed');

				UPDATE [Recon].[QualitativePipelineLog]
				SET 
					[PipelineStatus] = @PipelineStatus,
					[EndTime] = SWITCHOFFSET(SYSDATETIMEOFFSET(), '+05:30'),
					[ModifiedOn] = SWITCHOFFSET(SYSDATETIMEOFFSET(), '+05:30'),
					[ModifiedBy] = SUSER_NAME()
				WHERE PipelineLogID = @PipelineLogID;
			END

			-- If pipeline status is failed then throw the exception.
			IF @PipelineStatus = 'Failed'
				RAISERROR('Pipeline failed. Please check pipeline logs.', 16, 1);
		END TRY
		BEGIN CATCH
			THROW;
		END CATCH
END