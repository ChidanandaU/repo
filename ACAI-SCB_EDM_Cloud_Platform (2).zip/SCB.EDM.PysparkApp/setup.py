from setuptools import setup

setup(name='pipelines',
      version='0.0.1',
      description='PySpark Application + Wheels + DBConnect',
      author='SCB EDM DevTeam',
      author_email='samisra@microsoft.com',
      packages=['pipelines', 'pipelines.utils', 'pipelines.jobs'],
      zip_safe=False)
