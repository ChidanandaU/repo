﻿CREATE TABLE [Metadata].[SourceObjectDetail] (
    [SourceObjectID]                  INT            IDENTITY (1, 1) NOT NULL,
    [SourceID]                        INT            NOT NULL,
    [ObjectGroup]                     NVARCHAR (200) NOT NULL,
    [ObjectName]                      NVARCHAR (200) NULL,
    [ObjectProperties]                NVARCHAR (MAX) NOT NULL,
    [Frequency]                       INT            NULL,
    [FrequencyDurationUnit]           NVARCHAR (50)  NULL,
    [LoadOrder]                       INT            NOT NULL,
    [CreatedBy]                       NVARCHAR (100) DEFAULT (suser_name()) NOT NULL,
    [CreatedOn]                       DATETIME       DEFAULT (switchoffset(sysdatetimeoffset(),'+05:30')) NOT NULL,
    [ModifiedBy]                      NVARCHAR (100) DEFAULT (suser_name()) NOT NULL,
    [ModifiedOn]                      DATETIME       DEFAULT (switchoffset(sysdatetimeoffset(),'+05:30')) NOT NULL,
    PRIMARY KEY CLUSTERED ([SourceObjectID] ASC),
    FOREIGN KEY ([SourceID]) REFERENCES [Metadata].[SourceMaster] ([SourceID])
);

