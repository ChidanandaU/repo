﻿/***************************************************************************************************
-- <copyright file="Recon.uspGetQualitativeCorrectionDetails.sql" company="Bajaj Finserv and Microsoft Corporation">
-- Copyright (c) Bajaj Finserv and Microsoft Corporation. All rights reserved.
-- THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, 
-- INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
-- </copyright>

Procedure:          Recon.uspGetQualitativeCorrectionDetails
Create Date:        2019-10-02
Author:             Lakesh
Description:        To get Source object level details for recondetails for the recon correction.
Call by:              
Affected table(s): 
						
****************************************************************************************************
SUMMARY OF CHANGES
Date(yyyy-mm-dd)    Author              Comments
------------------- ------------------- ------------------------------------------------------------

***************************************************************************************************/

CREATE PROCEDURE [Recon].[uspGetQualitativeCorrectionDetails]
( 
  @SourceID INT,
  @MaxReconCorrectionRuns INT
)
AS
BEGIN
	
	SET NOCOUNT ON;

	BEGIN TRY
		-- Get all the objects that need to be processed based on Frequency.
		;WITH cteReconCorrections
		AS
		(
			SELECT QS.[QualitativeSummaryID],
				   QS.[SourceObjectID],
				   QS.[CorrectionQuery],
				   SOD.[ObjectGroup],
				   SOD.[SourceID],
				   SOD.[ObjectName],
				   ROW_NUMBER() OVER(ORDER BY QS.[BatchStartDateTime] ASC) AS RowNumber
			FROM [Recon].[QualitativeSummary] QS WITH (NOLOCK)
			INNER JOIN [Metadata].[SourceObjectDetail] SOD WITH (NOLOCK)
			ON QS.[SourceObjectID] = SOD.[SourceObjectID]
			WHERE [SourceID] = @SourceID
				AND [CorrectionStatus] = 'NOTSTARTED'
		)
		SELECT
			[QualitativeSummaryID],
			[SourceObjectID],
			[SourceID],
			CONCAT(' WHERE ' ,[CorrectionQuery]) AS DataExtractFilter,
			[ObjectGroup] AS SchemaName,
			[ObjectName] AS TableName,
			LOWER(CONCAT('recon_recorrection_records/',[ObjectGroup], '/', [ObjectName], '/', [QualitativeSummaryID])) AS [LandingFolderPath]
		FROM cteReconCorrections
		WHERE RowNumber <= @MaxReconCorrectionRuns;

	END TRY
	BEGIN CATCH
		THROW;		
	END CATCH
END