﻿/***************************************************************************************************
-- <copyright file="Recon.uspQualitativePipelineStartLog.sql" company="Bajaj Finserv and Microsoft Corporation">
-- Copyright (c) Bajaj Finserv and Microsoft Corporation. All rights reserved.
-- THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, 
-- INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
-- </copyright>

Procedure:          Recon.uspQualitativePipelineStartLog
Create Date:        2019-09-10
Author:             Lakesh
Description:        To log Qualitative pipeline level details and to determine whether a pipeline to be run or not
Call by:              
Affected table(s):  [Recon].[QualitativePipelineLog] 
                    
Used By:            Functional Area this is used in
Parameter(s):       @SourceName - source name,
					@SliceDateTime - slice date time,
					@PipelineRunID - pipeline run id,
					@LoadType - load type,
					@ToBeResumed - to be resumed

Usage:              EXEC EtlLog.[uspSourcePipelineStartLog]
						@SourceName = 'FINNCAS',
						@SliceDateTime ='2019-04-24 09:06:19.260',
						@PipelineRunId =NEWID(),
						@LoadType = 'Full',
						@ToBeResumed = 1
****************************************************************************************************
SUMMARY OF CHANGES
Date(yyyy-mm-dd)    Author              Comments
------------------- ------------------- ------------------------------------------------------------

***************************************************************************************************/

CREATE PROCEDURE [Recon].[uspQualitativePipelineStartLog]
( 
  @SourceName NVARCHAR(200),
  @SliceDateTime DATETIME,
  @PipelineRunID UNIQUEIDENTIFIER
)
AS
BEGIN
	
	SET NOCOUNT ON;

	BEGIN TRY

		DECLARE @SourceID INT,
				@PipelineLogID INT;

		-- Check whether source exists or not.
		IF NOT EXISTS (SELECT 1 FROM [Metadata].[SourceMaster] WITH (NOLOCK) WHERE [SourceName] = @SourceName)
			RAISERROR('Invalid Source. Source %s doesnt exist.', 16, 1, @SourceName);

		-- Get the Source Id.
		SELECT @SourceID = [SourceID] FROM [Metadata].[SourceMaster] WITH (NOLOCK) WHERE [SourceName] = @SourceName;

		-- Check whether any other run for this Source is already in progress.
		IF EXISTS (SELECT 1 FROM [Recon].[QualitativePipelineLog] WITH (NOLOCK)
							WHERE [SourceID] = @SourceID
							AND [PipelineStatus] = 'InProgress'
							AND [SourceObjectID] IS NULL
				  )
				RAISERROR('Another qualitative recon pipeline for this source is already in progress, please check.', 16, 1);

		-- Insert record into [Recon].[QualitativePipelineLog] table to start the pipeline log.
		EXEC [Recon].[uspInsertQualitativePipelineLog] 
			@ParentPipelineLogID = NULL, 
			@SourceID = @SourceID, 
			@SourceObjectID = NULL,
			@ReconStartDateTime = NULL,
			@SliceDateTime = @SliceDateTime,
			@PipelineRunID = @PipelineRunID;

	END TRY
	BEGIN CATCH
		THROW;		
	END CATCH
END