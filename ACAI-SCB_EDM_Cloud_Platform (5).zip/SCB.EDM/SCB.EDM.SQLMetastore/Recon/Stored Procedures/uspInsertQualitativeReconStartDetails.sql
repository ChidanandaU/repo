﻿/***************************************************************************************************
-- <copyright file="Recon.uspInsertQualitativeReconStartDetails.sql" company="Bajaj Finserv and Microsoft Corporation">
-- Copyright (c) Bajaj Finserv and Microsoft Corporation. All rights reserved.
-- THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, 
-- INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
-- </copyright>

Procedure:          Recon.uspInsertQualitativeReconStartDetails
Create Date:        2019-06-18
Author:             Lakesh
Description:        To insert the Qualitative recon start log for the table/object.
Call by:              
Affected table(s):   
                    
Used By:            Functional Area this is used in recon process.
Parameter(s):       @SourceObjectID - Source Object ID,
					@BatchWindowStart - Recon Batch window start,
					@BatchWindowEnd - Recon Batch window end.

Usage:              EXEC [Recon].[uspInsertQualitativeReconStartDetails]
						@SourceObjectID = 1,
						@BatchWindowStart = '2019/06/01',
						@BatchWindowEnd = '2019/06/30'
						
****************************************************************************************************
SUMMARY OF CHANGES
Date(yyyy-mm-dd)    Author              Comments
------------------- ------------------- ------------------------------------------------------------

***************************************************************************************************/
CREATE PROCEDURE [Recon].[uspInsertQualitativeReconStartDetails]
	@SourceObjectID INT,
	@BatchWindowStart DATETIME,
	@BatchWindowEnd DATETIME
AS
BEGIN
	INSERT INTO [Recon].[QualitativeSummary]
	(
		[SourceObjectID],
		[BatchWindowStart],
		[BatchWindowEnd],
		[BatchStartDateTime],
		[BatchStatus]
	)
	VALUES 
	(
		@SourceObjectID,
		@BatchWindowStart,
		@BatchWindowEnd,
		SWITCHOFFSET(SYSDATETIMEOFFSET(), '+05:30'),
		'InProgress'
	);
	
		-- Return [QualitativeSummaryID].
		SELECT SCOPE_IDENTITY() AS [QualitativeSummaryID];
END