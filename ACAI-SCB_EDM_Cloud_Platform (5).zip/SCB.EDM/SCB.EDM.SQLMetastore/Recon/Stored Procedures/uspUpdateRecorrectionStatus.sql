﻿/***************************************************************************************************
-- <copyright file="Recon.uspUpdateRecorrectionStatus.sql" company="Bajaj Finserv and Microsoft Corporation">
-- Copyright (c) Bajaj Finserv and Microsoft Corporation. All rights reserved.
-- THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, 
-- INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
-- </copyright>

Procedure:          Recon.uspUpdateRecorrectionStatus
Create Date:        2019-10-02
Author:             Lakesh
Description:        To update recorrection status.
Call by:              
Affected table(s): 
						
****************************************************************************************************
SUMMARY OF CHANGES
Date(yyyy-mm-dd)    Author              Comments
------------------- ------------------- ------------------------------------------------------------

***************************************************************************************************/
CREATE PROCEDURE [Recon].[uspUpdateRecorrectionStatus]
(
	@QualitativeSummaryID INT,
	@CorrectionStatus NVARCHAR(1000)

)
AS
BEGIN
	
	UPDATE [Recon].[QualitativeSummary]
	SET [CorrectionStatus] = @CorrectionStatus
	WHERE [QualitativeSummaryID] = @QualitativeSummaryID
END