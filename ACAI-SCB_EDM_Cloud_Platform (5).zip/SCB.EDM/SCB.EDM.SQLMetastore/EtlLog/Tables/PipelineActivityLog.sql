﻿CREATE TABLE [EtlLog].[PipelineActivityLog] (
    [PipelineActivityLogID] INT            IDENTITY (1, 1) NOT NULL,
    [PipelineLogID]         INT            NOT NULL,
    [ActivityName]          NVARCHAR (200) NOT NULL,
    [ActivityType]          NVARCHAR (200) NOT NULL,
    [SourceCount]           BIGINT         NULL,
    [TargetCount]           BIGINT         NULL,
    [SourceDataVolume]      BIGINT         NULL,
    [TargetDataVolume]      BIGINT         NULL,
    [StartTime]             DATETIME       NOT NULL,
    [EndTime]               DATETIME       NULL,
    [ActivityStatus]        NVARCHAR (50)  NULL,
    [CreatedBy]             NVARCHAR (100) DEFAULT (suser_name()) NOT NULL,
    [CreatedOn]             DATETIME       DEFAULT (switchoffset(sysdatetimeoffset(),'+05:30')) NOT NULL,
    [ModifiedBy]            NVARCHAR (100) DEFAULT (suser_name()) NOT NULL,
    [ModifiedOn]            DATETIME       DEFAULT (switchoffset(sysdatetimeoffset(),'+05:30')) NOT NULL,
    PRIMARY KEY CLUSTERED ([PipelineActivityLogID] ASC),
    FOREIGN KEY ([PipelineLogID]) REFERENCES [EtlLog].[PipelineLog] ([PipelineLogID])
);

