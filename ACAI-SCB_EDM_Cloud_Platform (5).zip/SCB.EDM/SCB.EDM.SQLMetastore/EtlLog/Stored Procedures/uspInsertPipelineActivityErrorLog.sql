﻿/***************************************************************************************************
-- <copyright file="EtlLog.uspInsertPipelineActivityErrorLog.sql" company="Bajaj Finserv and Microsoft Corporation">
-- Copyright (c) Bajaj Finserv and Microsoft Corporation. All rights reserved.
-- THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, 
-- INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
-- </copyright>

Procedure:          EtlLog.uspInsertPipelineActivityErrorLog
Create Date:        2019-04-22
Author:             Pranay
Description:        Insert PipelineActivityLogId and Error Message into [EtlLog].[PipelineActivityErrorLog] Table,
					Update Pipeline Activity Log with Failed status.
Call by:            
Affected table(s):  [EtlLog].[PipelineActivityErrorLog] 
                    
Used By:            Functional Area this is used in

Parameter(s):       @PipelineActivityLogID - Pipeline Activity Log ID
					@ActivityName - activity name
                    @ErrorMessage - error message

Usage:              EXEC EtlLog.uspInsertPipelineActivityErrorLog
                        @PipelineActivityLogID = 1,
						@ActivityName = 'activity',
                        @ErrorMessage = 'An error has occurred'
****************************************************************************************************
SUMMARY OF CHANGES
Date(yyyy-mm-dd)    Author              Comments
------------------- ------------------- ------------------------------------------------------------
2019-04-24          Durgesh Nandini     Added Headers

***************************************************************************************************/

CREATE PROCEDURE [EtlLog].[uspInsertPipelineActivityErrorLog]
( 
  @PipelineLogID INT,
  @PipelineActivityLogID INT,
  @ErrorMessage NVARCHAR(MAX)
)
AS 
BEGIN
	
	SET NOCOUNT ON;

	INSERT INTO [EtlLog].[PipelineActivityErrorLog] 
	(PipelineActivityLogID, ErrorMessage)
	VALUES
	(@PipelineActivityLogID, @ErrorMessage);

	-- Update the activity status as failed.
	EXEC [EtlLog].[uspUpdatePipelineActivityLog]
		@PipelineActivityLogID = @PipelineActivityLogID,
		@SourceCount = NULL,
		@TargetCount = NULL,
		@SourceDataVolume = NULL,
		@TargetDataVolume = NULL,
		@ActivityStatus = 'Failed'

	-- Update the pipeline status as failed.
	EXEC [EtlLog].[uspUpdatePipelineLog]
	@PipelineLogID = @PipelineLogID,
	@PipelineStatus = 'Failed'
END