﻿/***************************************************************************************************
-- <copyright file="EtlLog.uspGetSourceObjectDetails.sql" company="Bajaj Finserv and Microsoft Corporation">
-- Copyright (c) Bajaj Finserv and Microsoft Corporation. All rights reserved.
-- THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, 
-- INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
-- </copyright>

Procedure:          EtlLog.uspGetSourceObjectDetails
Create Date:        2019-04-22
Author:             Lakesh
Description:        To get Source object level details.
Call by:              
Affected table(s):   
                    
Used By:            Functional Area this is used in
Parameter(s):       @SourceID - source ID,
					@SliceDateTime - slice date time,
					@ToBeResumed - to be resumed
					@LoadType - load type

Usage:              EXEC EtlLog.[uspGetSourceObjectDetails]
						@SourceID = '1',
						@SliceDateTime ='2019-04-24 09:06:19.260',
						@ToBeResumed = 1
						@LoadType = 'Full'
						
****************************************************************************************************
SUMMARY OF CHANGES
Date(yyyy-mm-dd)    Author              Comments
------------------- ------------------- ------------------------------------------------------------
2019-04-24          Durgesh Nandini     Added Headers

***************************************************************************************************/

CREATE PROCEDURE [EtlLog].[uspGetSourceObjectDetails]
( 
  @SourceID INT,
  @SliceDateTime DATETIME,
  @ToBeResumed BIT,
  @ToBeReRun BIT,
  @RunFrequencyDurationUnit NVARCHAR(50),
  @LoadType NVARCHAR(20)
)
AS
BEGIN
	
	SET NOCOUNT ON;

	BEGIN TRY

		IF @ToBeReRun = 0
			BEGIN
				-- Get all the objects that need to be processed based on Frequency.
				;WITH cteLastMaxSliceDateTime
				AS
				(
					SELECT MAX(SliceDateTime) AS LastSliceDateTime,
						   [SourceObjectID]
					FROM [EtlLog].[PipelineLog] WITH (NOLOCK)
					WHERE [SourceID] = @SourceID
					  AND [PipelineStatus] = 'Succeeded'
					  AND [SourceObjectID] IS NOT NULL
					GROUP BY [SourceObjectID]
				),
				cteSourceObjectEligibility AS
				(
					SELECT SOD.[SourceObjectID],
					CTE.LastSliceDateTime,
					CASE WHEN 
								CASE 
									WHEN ISNULL(SOD.[FrequencyDurationUnit], SM.[FrequencyDurationUnit]) = 'YEAR'
											THEN DATEDIFF(YEAR, LastSliceDateTime, @SliceDateTime)
									WHEN ISNULL(SOD.[FrequencyDurationUnit], SM.[FrequencyDurationUnit]) = 'MONTH'
											THEN DATEDIFF(MONTH, LastSliceDateTime, @SliceDateTime)
									WHEN ISNULL(SOD.[FrequencyDurationUnit], SM.[FrequencyDurationUnit]) = 'DAY' 
											THEN DATEDIFF(DAY, LastSliceDateTime, @SliceDateTime)
									WHEN ISNULL(SOD.[FrequencyDurationUnit], SM.[FrequencyDurationUnit]) = 'HOUR'
											THEN DATEDIFF(HOUR, LastSliceDateTime, @SliceDateTime)						
									WHEN ISNULL(SOD.[FrequencyDurationUnit], SM.[FrequencyDurationUnit]) = 'MINUTE' 
											THEN DATEDIFF(MINUTE, LastSliceDateTime, @SliceDateTime)
									ELSE -1
								END >= ISNULL(SOD.[Frequency], SM.[Frequency])
							 THEN 1
							 ELSE 0
						END AS ToBeRun
					FROM [Metadata].[SourceObjectDetail] SOD WITH (NOLOCK)
					INNER JOIN [Metadata].[SourceMaster] SM WITH (NOLOCK)
					ON SOD.[SourceID] = SM.[SourceID]
					INNER JOIN cteLastMaxSliceDateTime CTE
					ON CTE.[SourceObjectID] = SOD.[SourceObjectID]
				)
				SELECT
					SOD.[SourceObjectID],
					SOD.[ObjectGroup],
					SOD.[ObjectName],
					CASE 
						WHEN @LoadType = 'Full' THEN CAST('1900-01-01' AS DATETIME)
						ELSE ISNULL(SOE.[LastSliceDateTime], CAST('1900-01-01' AS DATETIME)) 
					END AS LastRefreshDate
				FROM [Metadata].[SourceObjectDetail] SOD WITH (NOLOCK)
				INNER JOIN [Metadata].[SourceMaster] SM WITH (NOLOCK)
				ON SOD.[SourceID] = SM.[SourceID]
				LEFT OUTER JOIN cteSourceObjectEligibility SOE WITH (NOLOCK)
				ON SOD.[SourceObjectID] = SOE.[SourceObjectID]
				WHERE (SOE.[ToBeRun] IS NULL OR SOE.[ToBeRun] = 1)
				AND CASE WHEN @LoadType = 'Full' THEN SOD.[IsFullLoadActive] ELSE SOD.[IsIncrementalLoadActive] END = 1
				AND SOD.[SourceID] =  @SourceID
				AND ISNULL(@RunFrequencyDurationUnit, ISNULL(SOD.[FrequencyDurationUnit], SM.[FrequencyDurationUnit])) =
					ISNULL(SOD.[FrequencyDurationUnit], SM.[FrequencyDurationUnit])
				ORDER BY SOD.[LoadOrder]
			END
		ELSE
			BEGIN

				IF @ToBeResumed = 0
				BEGIN

					-- Get all the objects that need to be re-run.
					;WITH cteSliceAllPreviousRunDetails
					AS
					(
						SELECT [SourceID], [SourceObjectID], [ObjectLoadStartDateTime],
							   ROW_NUMBER() OVER(PARTITION BY [SourceID], [SourceObjectID] ORDER BY [StartTime] ASC) AS RowNumber
						  FROM [EtlLog].[PipelineLog] WITH (NOLOCK)
						WHERE [SourceID] = @SourceID
						  AND [SliceDateTime] = @SliceDateTime
						  AND ISNULL([RunFrequencyDurationUnit], '') = ISNULL(@RunFrequencyDurationUnit, '')
						  AND [LoadType] = @LoadType
						  AND [SourceObjectID] IS NOT NULL
					)
					SELECT
						SOD.[SourceObjectID],
						SOD.[ObjectGroup],
						SOD.[ObjectName],
						CTE.[ObjectLoadStartDateTime] AS LastRefreshDate
					FROM [Metadata].[SourceObjectDetail] SOD WITH (NOLOCK)
					INNER JOIN cteSliceAllPreviousRunDetails CTE WITH (NOLOCK)
					ON SOD.[SourceID] = CTE.[SourceID]
					AND SOD.[SourceObjectID] = CTE.[SourceObjectID]
					WHERE CTE.RowNumber = 1 AND
				    CASE WHEN @LoadType = 'Full' THEN SOD.[IsFullLoadActive] ELSE SOD.[IsIncrementalLoadActive] END = 1
					ORDER BY SOD.[LoadOrder]
				END

				ELSE
				BEGIN

					-- Get all the objects that need to be resumed.
					;WITH cteSlicePreviousSuccessfulRunDetails
					AS
					(
						SELECT DISTINCT [SourceObjectID]
						  FROM [EtlLog].[PipelineLog] WITH (NOLOCK)
						WHERE [SourceID] = @SourceID
						  AND [SliceDateTime] = @SliceDateTime
						  AND [PipelineStatus] = 'Succeeded'
						  AND ISNULL([RunFrequencyDurationUnit], '') = ISNULL(@RunFrequencyDurationUnit, '')
						  AND [LoadType] = @LoadType
						  AND [SourceObjectID] IS NOT NULL
					),
					cteSlicePreviousFailedRunDetails
					AS
					(
						SELECT [SourceID], [SourceObjectID], [ObjectLoadStartDateTime],
							   ROW_NUMBER() OVER(PARTITION BY [SourceID], [SourceObjectID] ORDER BY [StartTime] ASC) AS RowNumber
						  FROM [EtlLog].[PipelineLog] WITH (NOLOCK)
						WHERE [SourceID] = @SourceID
						  AND [SliceDateTime] = @SliceDateTime
						  AND ISNULL([RunFrequencyDurationUnit], '') = ISNULL(@RunFrequencyDurationUnit, '')
						  AND [LoadType] = @LoadType
						  AND [SourceObjectID] IS NOT NULL
						  AND [SourceObjectID] NOT IN (SELECT [SourceObjectID] FROM cteSlicePreviousSuccessfulRunDetails)
					)
					SELECT
						SOD.[SourceObjectID],
						SOD.[ObjectGroup],
						SOD.[ObjectName],
						CTE.[ObjectLoadStartDateTime] AS LastRefreshDate
					FROM [Metadata].[SourceObjectDetail] SOD WITH (NOLOCK)
					INNER JOIN cteSlicePreviousFailedRunDetails CTE WITH (NOLOCK)
					ON SOD.[SourceID] = CTE.[SourceID]
					AND SOD.[SourceObjectID] = CTE.[SourceObjectID]
					WHERE CTE.RowNumber = 1 AND
				    CASE WHEN @LoadType = 'Full' THEN SOD.[IsFullLoadActive] ELSE SOD.[IsIncrementalLoadActive] END = 1
					ORDER BY SOD.[LoadOrder]

				END
			END

	END TRY
	BEGIN CATCH
		THROW;		
	END CATCH
END