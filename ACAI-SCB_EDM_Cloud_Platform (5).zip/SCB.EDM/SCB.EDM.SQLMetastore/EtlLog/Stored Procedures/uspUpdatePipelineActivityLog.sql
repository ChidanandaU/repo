﻿/***************************************************************************************************
-- <copyright file="EtlLog.uspUpdatePipelineActivityLog.sql" company="Bajaj Finserv and Microsoft Corporation">
-- Copyright (c) Bajaj Finserv and Microsoft Corporation. All rights reserved.
-- THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, 
-- INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
-- </copyright>

Procedure:          EtlLog.uspUpdatePipelineActivityLog
Create Date:        2019-04-22
Author:             DURGESH NANDINI
Description:        To update Pipeline Activity Log.
Call by:              
Affected table(s):  [EtlLog].[PipelineActivityLog]
                    
Used By:            Functional Area this is used in
Parameter(s):       @PipelineActivityLogID - PIPELINE ACTIVITY LOG ID,
					@SourceCount -SOURCE COUNT,
					@TargetCount -TARGET COUNT,
					@ActivityStatus -ACTIVITY STATUS

Usage:              EXEC EtlLog.[uspGetSourceObjectDetails]
						@PipelineActivityLogID=1,
						@SourceCount =9,
						@TargetCount =9,
						@ActivityStatus='Success'
						
****************************************************************************************************
SUMMARY OF CHANGES
Date(yyyy-mm-dd)    Author              Comments
------------------- ------------------- ------------------------------------------------------------
2019-04-24          Durgesh Nandini     Added Headers

***************************************************************************************************/

CREATE PROCEDURE [EtlLog].[uspUpdatePipelineActivityLog]
( 
  @PipelineActivityLogID INT,
  @SourceCount BIGINT,
  @TargetCount BIGINT,
  @SourceDataVolume BIGINT,
  @TargetDataVolume BIGINT,
  @ActivityStatus NVARCHAR(50)
)
AS 
BEGIN
	
	SET NOCOUNT ON;

	IF @PipelineActivityLogID IS NOT NULL

		UPDATE [EtlLog].[PipelineActivityLog]
		SET 
		[SourceCount] = @SourceCount,
		[TargetCount] = @TargetCount,
		[SourceDataVolume] = @SourceDataVolume,
		[TargetDataVolume] = @TargetDataVolume,
		[ActivityStatus] = @ActivityStatus,
		[EndTime] = SWITCHOFFSET(SYSDATETIMEOFFSET(), '+05:30'),
		[ModifiedOn] = SWITCHOFFSET(SYSDATETIMEOFFSET(), '+05:30'),
		[ModifiedBy] = SUSER_NAME()
		WHERE PipelineActivityLogID = @PipelineActivityLogID;
	
END