﻿/***************************************************************************************************
-- <copyright file="EtlLog.uspInsertSourceFileProcessLog.sql" company="Bajaj Finserv and Microsoft Corporation">
-- Copyright (c) Bajaj Finserv and Microsoft Corporation. All rights reserved.
-- THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, 
-- INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
-- </copyright>

Procedure:          EtlLog.uspInsertSourceFileProcessLog
Create Date:        2019-04-22
Author:             DURGESH NANDINI
Description:        Insert FileName, FileSizeInMB into [EtlLog].[SourceFileProcessLog] Table
Call by:            
Affected table(s):  [EtlLog].[SourceFileProcessLog]
                    
Used By:            Functional Area this is used in
Parameter(s):       
					@PipelineLogID - Pipeline Log ID
					@MetadataJson - JSON metadata

Usage:              EXEC EtlLog.uspInsertSourceFileProcessLog
						@PipelineLogID =3,
						@MetadataJson='{
								"name": "MyDataset",
								"properties": {
								"type": "AzureBlob",
								"linkedService": {
												"referenceName": "StorageLinkedService",
												"type": "LinkedServiceReference"
												},
								"typeProperties": {
												"folderPath":"container/folder",
												"filename": "file.json",
												"format":{
														"type":"JsonFormat"
														}
												}
												}
								}'
****************************************************************************************************
SUMMARY OF CHANGES
Date(yyyy-mm-dd)    Author              Comments
------------------- ------------------- ------------------------------------------------------------


***************************************************************************************************/
CREATE  PROCEDURE EtlLog.uspInsertSourceFileProcessLog
( @PipelineLogID INT, 
  @MetadataJson VARCHAR(MAX)
)
AS 
	BEGIN

	SET NOCOUNT ON;

		IF ISJSON (@MetadataJson) = 1
		BEGIN
			INSERT INTO [EtlLog].[SourceFileProcessLog]
					([PipelineLogID], [FileName])

			SELECT @PipelineLogID, [FileName] FROM OPENJSON(@MetadataJson)  
			WITH ([FileName] NVARCHAR(200) '$.name')
		
			SELECT COUNT([FileName]) AS FilesCount FROM OPENJSON(@MetadataJson) WITH ([FileName] NVARCHAR(200) '$.name')
  
		END
		ELSE
			SELECT 0 AS FilesCount
		
END