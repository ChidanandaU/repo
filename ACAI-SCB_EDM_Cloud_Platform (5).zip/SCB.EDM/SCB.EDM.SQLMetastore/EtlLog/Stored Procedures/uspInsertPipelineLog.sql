﻿/***************************************************************************************************
-- <copyright file="EtlLog.uspInsertPipelineLog.sql" company="Bajaj Finserv and Microsoft Corporation">
-- Copyright (c) Bajaj Finserv and Microsoft Corporation. All rights reserved.
-- THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, 
-- INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
-- </copyright>

Procedure:          EtlLog.uspInsertPipelineLog
Create Date:        2019-04-22
Author:             Pranay
Description:        Insert ParentPipelineLogId, SourceID, SourceObjectID, SliceDateTime,PipelineRunId into [EtlLog].[PipelineLog] Table

Call by:            [EtlLog].[uspSourcePipelineStartLog]

Affected table(s):  [EtlLog].[PipelineLog] 
                    
Used By:            Functional Area this is used in
Parameter(s):       @ParentPipelineLogId -Parent Pipeline Log ID
					@SourceID - Source ID
					@SourceObjectID - Source Object ID
					@SliceDateTime - slice date time
					@PipelineRunId - Pipeline Run ID
					@PipelineLogID - Output as Pipeline Log ID

Usage:              EXEC EtlLog.uspInsertPipelineLog
						@ParentPipelineLogId =3
						@SourceID=1,
						@SourceObjectID =3,
						@SliceDateTime ='2019-04-24 09:06:19.260',
						@PipelineRunId =NEWID()
****************************************************************************************************
SUMMARY OF CHANGES
Date(yyyy-mm-dd)    Author              Comments
------------------- ------------------- ------------------------------------------------------------
2019-04-24          Durgesh Nandini     Added Headers

***************************************************************************************************/

CREATE PROCEDURE [EtlLog].[uspInsertPipelineLog]
( 
  @ParentPipelineLogID  INT,
  @SourceID INT,
  @SourceObjectID INT,
  @SliceDateTime DATETIME,
  @PipelineRunID UNIQUEIDENTIFIER,
  @RunFrequencyDurationUnit NVARCHAR(50),
  @ObjectLoadStartDateTime DATETIME,
  @LoadType NVARCHAR(20)
)
AS 
BEGIN
	
	SET NOCOUNT ON;

	BEGIN TRY

		-- Check whether any other run for this Source Object is already in progress.
		IF @SourceObjectID IS NOT NULL AND EXISTS (SELECT 1 FROM [EtlLog].[PipelineLog] WITH (NOLOCK)
							WHERE [SourceID] = @SourceID
							AND [PipelineStatus] = 'InProgress'
							AND [SourceObjectID] = @SourceObjectID
				  )
				RAISERROR('Another pipeline for this object is already in progress, please check.', 16, 1);

		-- Check whether any recorrection run for this Source Object is in progress.
		IF @SourceObjectID IS NOT NULL AND EXISTS (SELECT 1 FROM [Recon].[QualitativeSummary] WITH (NOLOCK)
							WHERE [CorrectionStatus] = 'InProgress'
							AND [SourceObjectID] = @SourceObjectID
				  )
				RAISERROR('Recon recorrection pipeline for this object is in progress, please check.', 16, 1);

		DECLARE @SourceType NVARCHAR(200);

		-- Get the Source Type.
		SET @SourceType = (SELECT [SourceType] FROM [Metadata].[SourceMaster] WITH (NOLOCK) WHERE [SourceID] = @SourceID);

		INSERT INTO [EtlLog].PipelineLog 
		(	
			ParentPipelineLogID,
			PipelineStatus,
			SourceID,
			SourceObjectID,
			StartTime,
			SliceDateTime,
			RunID,
			RunFrequencyDurationUnit,
			ObjectLoadStartDateTime,
			LoadType
		)
		VALUES 
		(
			@ParentPipelineLogID,
			'InProgress',
			@SourceID,
			@SourceObjectID,
			SWITCHOFFSET(SYSDATETIMEOFFSET(), '+05:30'),
			@SliceDateTime,
			@PipelineRunID,
			UPPER(@RunFrequencyDurationUnit),
			@ObjectLoadStartDateTime,
			UPPER(@LoadType)
		);
	
		-- Return PipelineLogID, source type, source ID.
		SELECT SCOPE_IDENTITY() AS PipelineLogID, @SourceID AS SourceID, @SourceType AS SourceType;

	END TRY
	BEGIN CATCH
		THROW;		
	END CATCH
END