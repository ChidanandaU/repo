# SCB EDM pyspark application
A step by step guide to set up pyspark development environment locally

## About
This is a sample Databricks-Connect PySpark application that is designed as a template for best practice and useability.

The project is designed for:
* Python local development in an IDE (VSCode) using Databricks-Connect
* Well structured PySpark application 
* Simple data pipelines with reusable code
* Unit Testing with Pytest
* Build into a Python Wheel
* CI Build with Test results published
* Automated deployments/promotions

## Setup

## install anaconda/miniconda on Windows
Install anaconda for windows to help with packaging python app and creating virtual environments
https://www.anaconda.com/products/individual#windows 

## install python on Windows.
Please download python using the below link
https://www.python.org/downloads/
and install python 3.9.* or the latest version . While installing please select the "Add Python to PATH"

## install java on Windows.
Download and install Java SE Runtime Version 8 due to compatibility with Spark which does not work well with higher Java versions.
https://www.oracle.com/java/technologies/javase-jre8-downloads.html

When you install Java change the install location to be C:\Java. 
By default it will try to install into Program Files - this is a problem for Spark as it does not work well with spaces in the path.
Once installed create an environment variable - JAVA_HOME as "C:\Java"

## set up conda environment.
1. open Conda prompt
2. Create a Conda Environment using the below command :
    conda create --name scbedmpysparkapp python=3.9
3. Activate the environment:
    conda activate scbedmpysparkapp
4. Install the requirements into your environments:
    NOTE: Open the installutilities.txt in the root folder and ensure the version of databrick-connect matches your cluster runtime.
    command : 
    pip install -r installutilities.txt

5. Set up databricks connect for VS Code using the steps mentioned below and test it : 
https://docs.microsoft.com/en-us/azure/databricks/dev-tools/databricks-connect 

6. Build the pyspark project into a wheel file :
The setup.py in the root folder contains the configuration that will be used while building the project to a wheel file.
Command to build :
python setup.py bdist_wheel

This execution generate several folders in the project (dist, build and pipelines.egg-info). These folders are excluded through .gitingnore

