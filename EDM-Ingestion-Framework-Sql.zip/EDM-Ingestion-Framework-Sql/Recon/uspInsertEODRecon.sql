Create PROCEDURE [Recon].[uspInsertEODRecon]
( 
	@SourceId int,
	@SourceObjectId [int] ,
	@Identifier nvarchar(500),
	@SourceQuery nvarchar(max),
	@SourceValue bigint,
	@TargetQuery nvarchar(max),
	@TargetValue bigint,
	@BusinessDate datetime,
	@SourceReconStatus nvarchar(500),
	@LastSourceReconDateTime datetime
)
AS 
BEGIN
	
	SET NOCOUNT ON;

		INSERT INTO [Recon].[EODRecon]
           ([SourceID]
           ,[SourceObjectID]
           ,[identifier]
           ,[SourceQuery]
           ,[SourceValue]
           ,[TargetQuery]
           ,[TargetValue]
           ,[BusinessDate]
           ,[SourceReconStatus]
           ,[LastSourceReconDateTime]
           )
     VALUES
           (@SourceId
           ,@SourceObjectId
           ,@Identifier
           ,@SourceQuery
           ,@SourceValue
           ,@TargetQuery
           ,@TargetValue
           ,@BusinessDate
           ,@SourceReconStatus
           ,@LastSourceReconDateTime
			)

END