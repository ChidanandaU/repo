CREATE PROCEDURE [Metadata].[uspUpdateSourceObjectDetail]
@SourceName Nvarchar(100), 
@CountryCode Nvarchar(100), 
@TableName Nvarchar(100), 
@Property nvarchar(max),
@SourceType Nvarchar(20)
AS
-----------------------------------------------------------------------------------------------------------------------
/****** StoredProcedure:		[metadata].[uspUpdateSourceObjectDetail]
		Script Date:			2021-05-24 
		Author:					Divye Rastogi
		Test Execute:			This SP is used to insert or update records into the SourceObjectDetail Table.
		CMD:					EXEC [metadata].[uspUpdateSourceObjectDetail] 
								@SourceName = <value>, @CountryCode=<value>, @TableName=<value>,
								@Property = <value>, @SourceType=<value>
******/
-----------------------------------------------------------------------------------------------------------------------
BEGIN
	BEGIN TRY
		DECLARE @SourceID INT
		SELECT @SourceID = SourceID FROM Metadata.SourceMaster
		WHERE SourceName = @SourceName AND CountryCode = @CountryCode

		MERGE INTO [metadata].[SourceObjectDetail] AS Tar
		USING
		(
			SELECT
			@SourceID AS [SourceID],
			@TableName AS [ObjectName],
			@Property AS [ObjectProperties],
			@SourceType AS [ObjectType]
		) AS Src
		ON Tar.SourceID = Src.SourceID
		AND Tar.ObjectName = Src.ObjectName

		WHEN MATCHED THEN UPDATE
		SET
		Tar.ObjectGroup = Src.ObjectType,
		Tar.ObjectProperties = Src.ObjectProperties,
		Tar.ObjectType = Src.ObjectType,
		Tar.IsActive = 1,
		Tar.ModifiedBy = suser_name(),
		Tar.ModifiedOn = GETUTCDATE()

		WHEN NOT MATCHED THEN INSERT
		(
			SourceID,
			ObjectGroup,
			ObjectName,
			ObjectProperties,
			Frequency,
			FrequencyDurationUnit,
			LoadOrder,
			IsActive,
			ObjectType,
			CreatedBy,
			CreatedOn
		)
		VALUES
		(
			Src.SourceID,
			Src.ObjectType,
			Src.ObjectName,
			Src.ObjectProperties,
			1,
			'Day',
			1,
			1,
			Src.ObjectType,
			suser_name(),
			GETUTCDATE()
		);
	END TRY

	BEGIN CATCH
	DECLARE @Errmsg NVARCHAR(4000) = (
				SELECT ERROR_MESSAGE()
				)
			,@ErrorSeverity INT = ERROR_SEVERITY()
			,@ErrorState INT = ERROR_STATE()

		RAISERROR (
				@Errmsg
				,@ErrorSeverity
				,@ErrorState
				)
	END CATCH
END
