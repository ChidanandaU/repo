Create PROCEDURE [Metadata].[uspInsertRelableObject]
@SourceName Nvarchar(200),
@CountryCode Nvarchar(200),
@RenameProperties Nvarchar(max)
AS
-----------------------------------------------------------------------------------------------------------------------
/****** StoredProcedure:		[Metadata].[uspInsertRenameObject]
		Script Date:			2021-05-24 
		Author:					Vikash Jangid
		Test Execute:			This SP is used to insert or update records into the RenameObject Table.
		CMD:					EXEC [metadata].[uspInsertRenameObject] 
								@ObjectName = <value>, @RenamedBy=<value>
******/
-----------------------------------------------------------------------------------------------------------------------
BEGIN
	INSERT INTO [Metadata].[RelableObject]
           (
		   [SourceName],
		   [CountryCode]
           ,[RenameProperties]
           )
     VALUES
           (
		   @SourceName
           ,@CountryCode
		   ,@RenameProperties
           )
END
GO