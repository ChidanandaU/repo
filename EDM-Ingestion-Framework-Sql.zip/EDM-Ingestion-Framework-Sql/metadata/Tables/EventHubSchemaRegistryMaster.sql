CREATE TABLE [Metadata].[EventHubSchemaRegistryMaster](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[SchemaName] [varchar](100) NOT NULL,
	[SchemaGuid] [nvarchar](40) NULL,
	[AdlsFilePath] [nvarchar](255) NULL,
	[IsActive] [bit] NOT NULL,
	[SourceStreamingID] [bigint] NULL,
	[CreatedBy] [nvarchar](100) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](100) NULL,
	[ModifiedOn] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [Metadata].[EventHubSchemaRegistryMaster] ADD  DEFAULT (suser_name()) FOR [CreatedBy]
GO

ALTER TABLE [Metadata].[EventHubSchemaRegistryMaster] ADD  DEFAULT (getutcdate()) FOR [CreatedOn]
GO

ALTER TABLE [Metadata].[EventHubSchemaRegistryMaster]  WITH CHECK ADD FOREIGN KEY([SourceStreamingID])
REFERENCES [Metadata].[StreamingSourceDetails] ([ID])
GO