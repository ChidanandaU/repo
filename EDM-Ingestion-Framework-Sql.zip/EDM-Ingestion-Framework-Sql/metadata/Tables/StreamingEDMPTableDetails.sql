CREATE TABLE [Metadata].[StreamingEDMPTableDetails](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[TargetTableName] [nvarchar](100) NOT NULL,
	[StreamingSourceID] [bigint] NOT NULL,
	[HasExplode] BIT NOT NULL,
	[CreatedBy] [nvarchar](100) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](100) NULL,
	[ModifiedOn] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [Metadata].[StreamingEDMPTableDetails] ADD  DEFAULT (user_name()) FOR [CreatedBy]
GO

ALTER TABLE [Metadata].[StreamingEDMPTableDetails] ADD  DEFAULT (getutcdate()) FOR [CreatedOn]
GO

ALTER TABLE [Metadata].[StreamingEDMPTableDetails]  WITH CHECK ADD FOREIGN KEY([StreamingSourceID])
REFERENCES [Metadata].[StreamingSourceDetails] ([ID])
GO