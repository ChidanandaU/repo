CREATE TABLE [Metadata].[StreamingEDMPColumnDetails](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[ColumnName] [nvarchar](50) NOT NULL,
	[TargetTableID] [bigint] NOT NULL,
	[ColumnOrder] [int] NOT NULL,
	[SourceDataType] [nvarchar](50) NOT NULL,
	[DestDataType] [nvarchar](50) NOT NULL,
	[IsPrimaryKey] [bit] NOT NULL,
	[PkSequenceNumber] [int] NULL,
	[Length] [int] NULL,
	[IsNullable] [bit] NOT NULL,
	[JsonTag] [nvarchar](max) NOT NULL,
	[IsExploded] [bit] NOT NULL,
	[IsActive] [bit] NOT NULL,
	[IsSchemaEvolved] [bit] NOT NULL,
	[IsTokenizable] [bit] NOT NULL,
	[TokenizationAlgorithm] [nvarchar](50) NULL,
	[ConfigurationVersionID] [bigint] NOT NULL,
	[CreatedBy] [nvarchar](100) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](100) NULL,
	[ModifiedOn] [datetime] NULL,
	[IsSchemaEvolvedStandardized] [bit] NOT NULL,
	[IsColumnUpdated] [bit] NOT NULL,
	[IsColumnUpdatedStandardized] [bit] NOT NULL,
	[TokenizationFunction] [nvarchar](100) NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [Metadata].[StreamingEDMPColumnDetails] ADD  DEFAULT ((0)) FOR [IsPrimaryKey]
GO

ALTER TABLE [Metadata].[StreamingEDMPColumnDetails] ADD  DEFAULT ((1)) FOR [IsNullable]
GO

ALTER TABLE [Metadata].[StreamingEDMPColumnDetails] ADD  DEFAULT ((0)) FOR [IsExploded]
GO

ALTER TABLE [Metadata].[StreamingEDMPColumnDetails] ADD  DEFAULT ((1)) FOR [IsActive]
GO

ALTER TABLE [Metadata].[StreamingEDMPColumnDetails] ADD  DEFAULT ((1)) FOR [IsSchemaEvolved]
GO

ALTER TABLE [Metadata].[StreamingEDMPColumnDetails] ADD  DEFAULT ((0)) FOR [IsTokenizable]
GO

ALTER TABLE [Metadata].[StreamingEDMPColumnDetails] ADD  DEFAULT (suser_name()) FOR [CreatedBy]
GO

ALTER TABLE [Metadata].[StreamingEDMPColumnDetails] ADD  DEFAULT (getutcdate()) FOR [CreatedOn]
GO

ALTER TABLE [Metadata].[StreamingEDMPColumnDetails] ADD  DEFAULT ((1)) FOR [IsSchemaEvolvedStandardized]
GO

ALTER TABLE [Metadata].[StreamingEDMPColumnDetails] ADD  DEFAULT ((0)) FOR [IsColumnUpdated]
GO

ALTER TABLE [Metadata].[StreamingEDMPColumnDetails] ADD  DEFAULT ((0)) FOR [IsColumnUpdatedStandardized]
GO

ALTER TABLE [Metadata].[StreamingEDMPColumnDetails]  WITH CHECK ADD FOREIGN KEY([ConfigurationVersionID])
REFERENCES [Metadata].[StreamingConfigurationVersions] ([ID])
GO

ALTER TABLE [Metadata].[StreamingEDMPColumnDetails]  WITH CHECK ADD FOREIGN KEY([TargetTableID])
REFERENCES [Metadata].[StreamingEDMPTableDetails] ([ID])
GO


