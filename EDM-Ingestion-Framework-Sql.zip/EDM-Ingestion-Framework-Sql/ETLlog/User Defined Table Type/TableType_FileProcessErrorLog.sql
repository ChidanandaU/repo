﻿CREATE TYPE [ETLlog].[TableType_FileProcessErrorLog] AS TABLE(
	[PipeLineId] [int] NOT NULL,
	[SourceObjectId] [int] NULL,
	[SourceFileProcessLogId] [int] NULL,
	[ErrorType] [nvarchar](200) NULL,
	[ErrorCode] [nvarchar](200) NULL,
	[ErrorDescription] [nvarchar](4000) NULL,
	[ErrorData] [nvarchar](max) NULL,
	[RowId] [nvarchar](200) NULL
)
GO


