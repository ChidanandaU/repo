CREATE PROCEDURE [ETLlog].[uspInsertPipelineLog]
    (
    @ParentPipelineLogID  INT,
    @SourceObjectID INT,
    @PipelineRunID UNIQUEIDENTIFIER,
    @ObjectLoadStartDateTime DATETIME,
    @LoadType NVARCHAR(20),
    @FileName nvarchar(1000),
    @PipeLineName nvarchar(2000),
	@FilePath NVARCHAR(MAX) = NULL,
	@SourceFileStatus VARCHAR(20) = NULL,
	@RawFileStatus NVARCHAR(20) = NULL
)
AS
-----------------------------------------------------------------------------------------------------------------------    
/****** StoredProcedure:	[ETLlog].[uspInsertPipelineLog]
  Script Date:				2021-07-14     
  Author:					Sonam Jain 
  Test Execute:				This SP is used to insert pipeline logs
  CMD:						EXEC [ETLlog].[uspInsertPipelineLog]
							@ParentPipelineLogID = '<value>'
							,@SourceObjectID = '<value>'
							,@PipelineRunID = '<value>'
							,@ObjectLoadStartDateTime = '<value>'
							,@LoadType = '<value>'
							,@FileName = '<value>'
							,@PipeLineName = '<value>'
							,@FilePath = '<value>'
							,@SourceFileStatus = '<value>'
******/    
-----------------------------------------------------------------------------------------------------------------------    

BEGIN

    SET NOCOUNT ON;

    BEGIN TRY


		DECLARE @SourceType NVARCHAR(200);
		Declare @pipelineLogid int ;

		-- Get the Source Type.
		set @ObjectLoadStartDateTime= GETUTCDATE()

		IF (@LoadType=N'PROCESSSOURCEFILE')
		BEGIN

        INSERT INTO [EtlLog].PipelineLog
            (
            ParentPipelineLogID,
            PipelineStatus,
            SourceObjectID,
            RunID,
            StartTime,
            LoadType,
            PipeLineName

            )
        VALUES
            (
                @ParentPipelineLogID,
                'InProgress',
                @SourceObjectID,
                @PipelineRunID,
                @ObjectLoadStartDateTime,
                UPPER(@LoadType),
                @PipeLineName
		);


        -- Return PipelineLogID, source type, source ID.
        SELECT @pipelineLogid=SCOPE_IDENTITY();

        Insert into [Etllog].sourcefileprocesslog
            (
            PipelineLogID
            ,[FileName]
            ,IsLandingToRawProcessed
            ,IsRawtoStandardisedProcessed
			,FilePath
			,SourceFileStatus
			,RawFileStatus
            )
        VALUES( @pipelineLogid,
                @filename,
                0,
                0,
				@filepath,
				@sourcefilestatus,
				@RawFileStatus
				);

        SELECT @pipelineLogid AS PipelineLogID, SCOPE_IDENTITY() AS SourceFileProcessLogID
    END 
    ELSE 
	BEGIN
        INSERT INTO [EtlLog].PipelineLog
            (
            ParentPipelineLogID,
            PipelineStatus,
            SourceObjectID,
            RunID,
            StartTime,
            LoadType,
            PipeLineName
            )
        VALUES
            (
                @ParentPipelineLogID,
                'InProgress',
                @SourceObjectID,
                @PipelineRunID,
                @ObjectLoadStartDateTime,
                UPPER(@LoadType),
                @PipeLineName
		);
        SELECT @pipelineLogid=SCOPE_IDENTITY();
        SELECT @pipelineLogid AS PipelineLogID
    END 

	END TRY
	BEGIN CATCH
	
		DECLARE @Errmsg NVARCHAR(4000) = (    
		   SELECT ERROR_MESSAGE() )    
		  ,@ErrorSeverity INT = ERROR_SEVERITY()    
		  ,@ErrorState INT = ERROR_STATE()    
    
		  RAISERROR (    
			@Errmsg    
			,@ErrorSeverity    
			,@ErrorState    
			)   

	END CATCH		
	
END
