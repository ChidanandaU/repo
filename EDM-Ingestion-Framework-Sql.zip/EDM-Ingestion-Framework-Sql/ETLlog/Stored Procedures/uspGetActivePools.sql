CREATE PROCEDURE [ETLlog].[uspGetActivePools] 
AS
-----------------------------------------------------------------------------------------------------------------------
/****** StoredProcedure:		[ETLlog].[uspGetActivePools]
		Script Date:			2021-06-01
		Author:					Santhosh Boyapally	
		Test Execute:			This SP is used to get the sources to processed
		CMD:					EXEC [ETLlog].[uspGetActivePools]
******/
-----------------------------------------------------------------------------------------------------------------------
BEGIN
	BEGIN TRY
	
	SELECT PoolConfigurationID,
		   InstancePoolId,
		  '{"instance_pool_id":"'+InstancePoolId+'"}' As ConfigurationBody
   FROM  [ETLlog].[PoolConfigurationLog]
   WHERE IsActive=1

	END TRY

	BEGIN CATCH
	DECLARE @Errmsg NVARCHAR(4000) = (
				SELECT ERROR_MESSAGE()
				)
			,@ErrorSeverity INT = ERROR_SEVERITY()
			,@ErrorState INT = ERROR_STATE()

		RAISERROR (
				@Errmsg
				,@ErrorSeverity
				,@ErrorState
				)
	END CATCH
END



