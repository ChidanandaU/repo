CREATE PROCEDURE [ETLlog].[uspInsertFileProcessErrorLog]
@FileProcessErrorLog [ETLlog].TableType_FileProcessErrorLog READONLY 
AS
-----------------------------------------------------------------------------------------------------------------------
/****** StoredProcedure:		[ETLlog].[uspInsertFileProcessErrorLog]
		Script Date:			2021-05-18 
		Author:					Vikash Jangid
		Test Execute:			This SP is used to insert or update records into the FileProcessErrorLog Table.
		CMD:					EXEC [ETLlog].[uspInsertFileProcessErrorLog] 
								@FileProcessErrorLog = @TableTypeParameter
******/
----------------------------------------------------------------------------------------------------------------------- 
BEGIN
	BEGIN TRY
		DECLARE @PipeLineId int, 
		@SourceObjectId int, 
		@SourceFileProcessLogId int,
		@RowId [nvarchar](200),
		@ErrorCode [nvarchar](200),
		@ErrorDescription [nvarchar](4000),
		@ErrorData [nvarchar](max)

		SELECT @PipeLineId = [PipeLineId] from @FileProcessErrorLog
		SELECT @SourceObjectId = [SourceObjectId] from @FileProcessErrorLog
		SELECT @RowId = [RowId] from @FileProcessErrorLog
		SELECT @ErrorCode = [ErrorCode] from @FileProcessErrorLog
		SELECT @ErrorDescription = [ErrorDescription] from @FileProcessErrorLog
		SELECT @ErrorData = [ErrorData] from @FileProcessErrorLog
		SELECT @SourceFileProcessLogId = [SourceFileProcessLogId] from @FileProcessErrorLog
 
		SET NOCOUNT ON;
		INSERT INTO  [ETLlog].[FileProcessErrorLog](
							[PipeLineId],
							[SourceObjectId] ,
							[SourceFileProcessLogId],
							[RowId],
							[ErrorCode],
							[ErrorDescription],
							[ErrorData] 
						)

		Values( @PipeLineId, @SourceObjectId, @SourceFileProcessLogId, @RowId, @ErrorCode, @ErrorDescription, @ErrorData)

	END TRY

	BEGIN CATCH
	DECLARE @Errmsg NVARCHAR(4000) = (
				SELECT ERROR_MESSAGE()
				)
			,@ErrorSeverity INT = ERROR_SEVERITY()
			,@ErrorState INT = ERROR_STATE()

		RAISERROR (
				@Errmsg
				,@ErrorSeverity
				,@ErrorState
				)
	END CATCH
END