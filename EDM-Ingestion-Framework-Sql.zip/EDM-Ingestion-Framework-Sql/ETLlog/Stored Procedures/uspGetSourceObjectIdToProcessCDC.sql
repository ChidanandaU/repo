﻿CREATE PROCEDURE [ETLlog].[uspGetSourceObjectIdToProcessCDC] 
	@SourceId INT
AS
-----------------------------------------------------------------------------------------------------------------------
/****** StoredProcedure:		[ETLLOG].[uspGetSourceObjectIdToProcessCDC]
		Script Date:			2021-08-17
		Author:					Ankita Kumari	
		Test Execute:			This SP is used to get the object Ids to be processed from raw to standardized for CDC files
		CMD:					EXEC [ETLLOG].[uspGetSourceObjectIdToProcess] 
								@SourceId=''<value>'				              
								                                                            
******/
-----------------------------------------------------------------------------------------------------------------------
/****** Object:  StoredProcedure [ETLlog].[uspGetSourceObjectIdToProcessed]    Script Date: 31-08-2021 06:34:49 PM ******/
BEGIN
	BEGIN TRY
	
		DECLARE @SourceObjectList TABLE
		(
			SourceID INT,
			SourceObjectId INT,
			FileName NVARCHAR(200)
		)

		INSERT INTO @SourceObjectList
		SELECT SourceId, SourceObjectId, FileName
		FROM Etllog.SourceFileProcessLog 
		WHERE IsLandingToRawProcessed = 1
			AND IsRawtoStandardisedProcessed = 0
			AND SourceFileStatus = 'Completed'
			AND RawFileStatus = 'Not Processed'
			AND sourceid = @SourceId
			AND IsCDCFile = 1

		UPDATE sfpl
		SET RawFileStatus = 'In Progress'
		FROM @SourceObjectList AS sol
		INNER JOIN Etllog.SourceFileProcessLog  sfpl
		ON sol.SourceID = sfpl.SourceID
		AND sol.SourceObjectId = sfpl.SourceObjectID
		AND sol.FileName = sfpl.FileName

		SELECT SourceObjectId, FileName FROM @SourceObjectList

	END TRY

	BEGIN CATCH
	DECLARE @Errmsg NVARCHAR(4000) = (
				SELECT ERROR_MESSAGE()
				)
			,@ErrorSeverity INT = ERROR_SEVERITY()
			,@ErrorState INT = ERROR_STATE()

		RAISERROR (
				@Errmsg
				,@ErrorSeverity
				,@ErrorState
				)
	END CATCH
END
GO


