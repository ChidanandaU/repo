CREATE TABLE [ETLlog].[ParamConfigErrorLog](
	[ParamConfigErrorLogId] [int] IDENTITY(1,1) NOT NULL,
	[SourceFileProcessLogId] [int] NOT NULL,
	[OnSchemaEvolution] [bit] NOT NULL,
	[ExceptionTimestamp] [datetime2](7) NOT NULL,
	[ExceptionDetails] [nvarchar](max) NOT NULL,
	[CreatedBy] [nvarchar](100) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](100) NULL,
	[ModifiedOn] [datetime] NULL
PRIMARY KEY CLUSTERED 
(
	[ParamConfigErrorLogId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [ETLlog].[ParamConfigErrorLog] ADD  DEFAULT (suser_name()) FOR [CreatedBy]
GO

ALTER TABLE [ETLlog].[ParamConfigErrorLog] ADD  DEFAULT (getutcdate()) FOR [CreatedOn]
GO

ALTER TABLE [ETLlog].[ParamConfigErrorLog]  WITH CHECK ADD FOREIGN KEY([SourceFileProcessLogId])
REFERENCES [ETLlog].[SourceFileProcessLog] ([SourceFileProcessLogID])
GO