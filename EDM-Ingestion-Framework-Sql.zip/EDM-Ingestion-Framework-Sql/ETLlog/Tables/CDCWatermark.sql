﻿CREATE TABLE [ETLlog].[CDCWatermark](
	[CDCWatermarkId] [bigint] IDENTITY(1,1) NOT NULL,
	[SourceId] [int] NOT NULL,
	[ObjectName] [nvarchar](200) NULL,
	[EODMarkerStrategy] [nvarchar](50) NULL,
	[PreviousEOD] [nvarchar](50) NULL,
	[CurrentEOD] [nvarchar](50) NULL,
	[CreatedBy] [nvarchar](100) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](100) NULL,
	[ModifiedOn] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[CDCWatermarkId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [ETLlog].[CDCWatermark]  WITH CHECK ADD FOREIGN KEY([SourceId])
REFERENCES [Metadata].[SourceMaster] ([SourceID])
GO