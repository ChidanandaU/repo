from edm.utils.logging_utility import get_logger
from edm.utils.general_helper import (
    initialise
)

LOGGER = get_logger(__name__)


class SchemaEvolution:
    '''
    This class is used to handle the schema
    evolution scenarios.
    '''
    def __init__(self, source, country, file_name, spark, dbutils, **kwargs):
        '''
        This instantiates a Param Config Parser Object
        '''
        self.source = source
        self.country = country
        self.file_name = file_name
        self.spark = spark
        self.dbutils = dbutils
        self.spn_credentials = kwargs.get("spn_credentials", None)
        self.kv_name = kwargs.get("kv_name", None)
        self.adls_account_name = kwargs.get("adls_account_name", None)
        self.config_path = kwargs.get("config_path", None)

    def schema_evolution_handling(self):
        '''
        This method is used to run the schema
        evolution scenerios.
        '''
        standardize_data_path = (
            STANDARDIZE_ZONE_DATA_PATH.replace(
                "container",
                self.config['adls_details'][0]['standardized_container_name']
                ).replace(
                    "account",
                    self.config['adls_details'][0]['name']
                ).replace(
                    "source",
                    self.source
                ).replace(
                    "country",
                    self.country
                )
        )

        transformed_data_path = (
            TRANSFORMED_ZONE_DATA_PATH.replace(
                "container",
                self.config['adls_details'][0]['transformed_container_name']
                ).replace(
                    "account",
                    self.config['adls_details'][0]['name']
                ).replace(
                    "source",
                    self.source
                ).replace(
                    "country",
                    self.country
                )
        )

        object_name = 'gpws725'
        df = self.get_metainfo_sql(object_name)
        print('hsh')

    def get_metainfo_sql(self, object_name):
        '''Add description'''

        query=f'''(select TOP 100 Percent
            sod.ObjectName, 
            sm.SourceName,
            sm.CountryCode,
            ColumnName,
            ColumnOrder,
            DataType,
            IsPrimaryKey, 
            sob.IsActive,
            sob.IsSchemaEvolved,
            sod.ObjectType
        FROM [Metadata].[sourceobjectschema] sob
        JOIN [Metadata].[SourceObjectDetail] sod 
        ON sob.SourceObjectID=sod.SourceObjectID
        JOIN [metadata].[SourceMaster] AS SM   
            ON sm.SourceID=sod.SourceID
        AND sob.sourceobjectid in (SELECT DISTINCT sourceobjectid FROM [Metadata].[SourceObjectSchema]  where IsSchemaEvolved=1)
        and (sob.isactive=1 OR sob.IsSchemaEvolved=1)
        and sob.ObjectName = {object_name} and sm.SourceName = {self.source}
        and sm.CountryCode = {self.country} order by sod.SourceObjectID,sob.columnorder)src'''
        df = self.db_obj.get_df_from_query(query)
        pddf = df.orderBy('ObjectName', 'ColumnOrder').toPandas()

        return pddf

    def run(self):
        '''
        This method is used to run the schema evolution
        process end-to-end.
        '''
        LOGGER.info("Starting Schema evolution process")
        LOGGER.info("Started Initialisation")
        self.config, self.db_obj = initialise(
            self.spark, self.spn_credentials, self.kv_name,
            self.adls_account_name, self.config_path
        )
        LOGGER.info("Ended Initialisation")
        LOGGER.info("Starting Processing ")
        self.schema_evolution_handling()