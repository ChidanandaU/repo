/****** Object:  StoredProcedure [Metadata].[uspUpdateStreamingSourceDetails]    Script Date: 6/7/2021 10:11:51 AM ******/

CREATE PROCEDURE [Metadata].[uspUpdateStreamingSourceDetails]
@RealTimeMetastore [Metadata].[TableType_RealTimeIngestion] READONLY 
AS 
-----------------------------------------------------------------------------------------------------------------------
/****** StoredProcedure:		[metadata].[uspUpdateStreamingSourceDetails]
		Script Date:			2021-03-06 
		Author:					Priyanka Bariki
		Test Execute:			This SP is used to insert or update records into the StreamingSourceDetails Table.
		CMD:					EXEC [metadata].[uspUpdateStreamingSourceDetails]
								@RealTimeMetastore = '<value>',
******/
-----------------------------------------------------------------------------------------------------------------------

BEGIN 
    
   BEGIN TRY
	
	MERGE INTO [metadata].[StreamingSourceDetails] AS Tar
		USING
		(
			SELECT StreamingSource AS StreamingSource,
			SC.ID AS ConfigurationID		      
			from @RealTimeMetastore  RTM
			JOIN [Metadata].[StreamingConfigurations] SC ON
			RTM.ConfigurationName = SC.[Configuration]
		) As Src
		ON 
		Tar.StreamingSource = Src.StreamingSource

		WHEN MATCHED  AND (Tar.ConfigurationID<>Src.ConfigurationID) THEN UPDATE 
		SET 
		Tar.ConfigurationID=Src.ConfigurationID,
		Tar.ModifiedBy = suser_name(),
		Tar.ModifiedOn = GETUTCDATE()

		WHEN NOT MATCHED THEN INSERT
		(
			[StreamingSource],
			[ConfigurationID],
			CreatedBy,
			CreatedOn
		)
		VALUES
		(
			Src.[StreamingSource],
			Src.ConfigurationID,
			suser_name(),
			GETUTCDATE()
		);

		UPDATE SRM
		SET SRM.SourceStreamingID = SSD.ID
		FROM @RealTimeMetastore RTM
		INNER JOIN Metadata.StreamingSourceDetails SSD ON SSD.StreamingSource = RTM.StreamingSource
		INNER JOIN metadata.EventHubSchemaRegistryMaster SRM ON SSD.StreamingSource = SRM.SchemaName
   END TRY
   BEGIN CATCH
		DECLARE @Errmsg NVARCHAR(4000) = (
				SELECT ERROR_MESSAGE()
				)
			,@ErrorSeverity INT = ERROR_SEVERITY()
			,@ErrorState INT = ERROR_STATE()

		RAISERROR (
				@Errmsg
				,@ErrorSeverity
				,@ErrorState
				)
	END CATCH

   END