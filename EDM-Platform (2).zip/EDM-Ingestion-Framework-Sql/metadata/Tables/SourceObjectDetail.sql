CREATE TABLE [Metadata].[SourceObjectDetail](
	[SourceObjectID] [int] IDENTITY(1,1) NOT NULL,
	[SourceID] [int] NOT NULL,
	[ObjectGroup] [nvarchar](200) NOT NULL,
	[ObjectName] [nvarchar](200) NULL,
	[ObjectProperties] [nvarchar](max) NOT NULL,
	[Frequency] [int] NULL,
	[FrequencyDurationUnit] [nvarchar](50) NULL,
	[LoadOrder] [int] NOT NULL,
	[IsActive] [bit] NULL,
	[CreatedBy] [nvarchar](100) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](100) NOT NULL,
	[ModifiedOn] [datetime] NOT NULL,
	[ObjectType] [nvarchar](200) NULL,
	[ObjectNameBeforeRename] [nvarchar](200) NULL,
PRIMARY KEY CLUSTERED 
(
	[SourceObjectID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [Metadata].[SourceObjectDetail] ADD  DEFAULT (suser_name()) FOR [CreatedBy]
GO

ALTER TABLE [Metadata].[SourceObjectDetail] ADD  DEFAULT (switchoffset(sysdatetimeoffset(),'+05:30')) FOR [CreatedOn]
GO

ALTER TABLE [Metadata].[SourceObjectDetail] ADD  DEFAULT (suser_name()) FOR [ModifiedBy]
GO

ALTER TABLE [Metadata].[SourceObjectDetail] ADD  DEFAULT (switchoffset(sysdatetimeoffset(),'+05:30')) FOR [ModifiedOn]
GO

ALTER TABLE [Metadata].[SourceObjectDetail]  WITH CHECK ADD FOREIGN KEY([SourceID])
REFERENCES [Metadata].[SourceMaster] ([SourceID])
GO