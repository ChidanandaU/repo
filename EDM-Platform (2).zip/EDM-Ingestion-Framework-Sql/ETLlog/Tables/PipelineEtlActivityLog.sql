CREATE TABLE [ETLlog].[PipelineEtlActivityLog](
	[PipelineActivityLogID] [int] IDENTITY(1,1) NOT NULL,
	[PipelineLogID] [int] NOT NULL,
	[ActivityName] [nvarchar](200) NOT NULL,
	[ActivityType] [nvarchar](200) NOT NULL,
	[StartTime] [datetime] NOT NULL,
	[EndTime] [datetime] NULL,
	[ActivityStatus] [nvarchar](50) NULL,
	[CreatedBy] [nvarchar](100) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](100) NOT NULL,
	[ModifiedOn] [datetime] NOT NULL,
	[ErrorMessage] [nvarchar](max) NULL,
PRIMARY KEY CLUSTERED 
(
	[PipelineActivityLogID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [ETLlog].[PipelineEtlActivityLog] ADD  DEFAULT (suser_name()) FOR [CreatedBy]
GO

ALTER TABLE [ETLlog].[PipelineEtlActivityLog] ADD  DEFAULT (switchoffset(sysdatetimeoffset(),'+05:30')) FOR [CreatedOn]
GO

ALTER TABLE [ETLlog].[PipelineEtlActivityLog] ADD  DEFAULT (suser_name()) FOR [ModifiedBy]
GO

ALTER TABLE [ETLlog].[PipelineEtlActivityLog] ADD  DEFAULT (switchoffset(sysdatetimeoffset(),'+05:30')) FOR [ModifiedOn]
GO

ALTER TABLE [ETLlog].[PipelineEtlActivityLog]  WITH CHECK ADD FOREIGN KEY([PipelineLogID])
REFERENCES [ETLlog].[PipelineLog] ([PipelineLogID])
GO