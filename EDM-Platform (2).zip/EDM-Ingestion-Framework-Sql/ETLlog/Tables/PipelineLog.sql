CREATE TABLE [ETLlog].[PipelineLog](
	[PipelineLogID] [int] IDENTITY(1,1) NOT NULL,
	[PipeLineName] [nvarchar](1000) NULL,
	[ParentPipelineLogID] [int] NULL,
	[PipelineStatus] [nvarchar](50) NOT NULL,
	[SourceObjectID] [int] NULL,
	[StartTime] [datetime] NOT NULL,
	[EndTime] [datetime] NULL,
	[SliceDateTime] [datetime] NULL,
	[RunID] [uniqueidentifier] NOT NULL,
	[LoadType] [nvarchar](20) NOT NULL,
	[RunFrequencyDurationUnit] [nvarchar](50) NULL,
	[CreatedBy] [nvarchar](100) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](100) NOT NULL,
	[ModifiedOn] [datetime] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[PipelineLogID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [ETLlog].[PipelineLog] ADD  DEFAULT (suser_name()) FOR [CreatedBy]
GO

ALTER TABLE [ETLlog].[PipelineLog] ADD  DEFAULT (switchoffset(sysdatetimeoffset(),'+05:30')) FOR [CreatedOn]
GO

ALTER TABLE [ETLlog].[PipelineLog] ADD  DEFAULT (suser_name()) FOR [ModifiedBy]
GO

ALTER TABLE [ETLlog].[PipelineLog] ADD  DEFAULT (switchoffset(sysdatetimeoffset(),'+05:30')) FOR [ModifiedOn]
GO

ALTER TABLE [ETLlog].[PipelineLog]  WITH CHECK ADD FOREIGN KEY([SourceObjectID])
REFERENCES [Metadata].[SourceObjectDetail] ([SourceObjectID])
GO