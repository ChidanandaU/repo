#
#
# PowerShell Script for FailOver of Storage Account
#
#

$primaryResourceGroup=$args[1]
$primaryStorageAccount=$args[2]

$SecondaryResourceGroup=$args[3]
$SecondaryStorageAccount=$args[4]
$sku=$args[5]


if($args[0] -eq $True){
# To Check the last Replication Time
Write-output "To Check the last Replication Time"
az storage account show  --name $primaryStorageAccount  --resource-group $primaryResourceGroup --expand geoReplicationStats --query geoReplicationStats.lastSyncTime  --output tsv

# Run a Failover
Write-output "Run a FailOver"
az storage account failover --name $primaryStorageAccount

# Update the Secondary Storage account as RA-GRS
Write-output "Update the Secondary Storage account as RA-GRS"
az storage account update --name $SecondaryStorageAccount --resource-group $SecondaryResourceGroup --sku $sku
}

else
{
        Write-output "Storage Account FailOver Aborted"
}

