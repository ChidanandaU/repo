CREATE MASTER KEY ENCRYPTION BY PASSWORD = '{PASSWORD}' 
GO

DECLARE @Count INT
DECLARE @ScopedCredential NVARCHAR(50)
SELECT @ScopedCredential = 'WorkspaceIdentity'


DECLARE @ExternalFileFormat NVARCHAR(50)
SELECT @ExternalFileFormat = 'DeltaLakeFormat'

DECLARE @ExternalDataSource1 NVARCHAR(50)
SELECT @ExternalDataSource1 = 'ExternalDataSourceTransformed'

SELECT @Count = COUNT(1) FROM sys.database_scoped_credentials WHERE name = @ScopedCredential
IF @Count <> 0
BEGIN
DROP EXTERNAL DATA SOURCE ExternalDataSourceTransformed
DROP DATABASE SCOPED CREDENTIAL WorkspaceIdentity
END
CREATE DATABASE SCOPED CREDENTIAL WorkspaceIdentity WITH IDENTITY = 'MANAGED IDENTITY'
GO

SELECT @Count = COUNT(1) FROM sys.external_file_formats WHERE name = @ExternalFileFormat
IF @Count <> 0
BEGIN
DROP EXTERNAL FILE FORMAT DeltaLakeFormat
END
CREATE EXTERNAL FILE FORMAT DeltaLakeFormat WITH (FORMAT_TYPE = DELTA)
GO



SELECT @Count = COUNT(1) FROM sys.external_data_sources WHERE name = @ExternalDataSource1
IF @Count <> 0
BEGIN
DROP EXTERNAL DATA SOURCE ExternalDataSourceTransformed
END

CREATE EXTERNAL DATA SOURCE ExternalDataSourceTransformed
WITH (
LOCATION = N'abfss://transformed@{account_name}.dfs.core.windows.net/data/',
CREDENTIAL = [WorkspaceIdentity]
)
GO
