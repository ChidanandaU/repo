import json
import datetime
import uuid

from edm.batch_ingestion.landing_to_raw.landing_to_raw_processor import (
    LandingToRawProcessor
)
from edm.utils.const import (
        RAW_ZONE_DATA_PATH,
        RAW_ZONE_CDC_PATH,
        TRANSFORMED_ZONE_DATA_PATH)

from edm.utils.general_helper import (
    initialise, get_filename_date_index
)
from edm.utils.logging_utility import get_logger
from pyspark.sql import types as t
from pyspark.sql import functions as f
from pyspark.sql import DataFrame

LOGGER = get_logger(__name__)


class RawToStandardizeProcessor:
    '''
    This class is used to process the data file
    from Raw to Standardize zone after applying
    all the necessary validations.
    '''

    def __init__(self, source_id, source_object_id, file_name, spark, dbutils, **kwargs):
        '''
        This instantiates a Raw To Standardized Object
        '''
        self.source_id = source_id
        self.source_object_id = source_object_id
        self.file_name = file_name
        self.spark = spark
        self.dbutils = dbutils
        self.spn_credentials = kwargs.get("spn_credentials", None)
        self.kv_name = kwargs.get("kv_name", None)
        self.adls_account_name = kwargs.get("adls_account_name", None)
        self.config_path = kwargs.get("config_path", None)

    def raw_to_standardize_processor(self):
        '''
        This method is used to process the data files
        present in raw zone and move it to standardized
        layer.
        '''
        try:
            # Getting info of file to be processed.
            query = (
                f"select * from edmsbxseasqldb.ETLlog.SourceFileProcessLog \
                where IsRawtoStandardisedProcessed = 0 \
                and IsLandingToRawProcessed = 1 \
                and SourceID={self.source_id} \
                and SourceObjectID={self.source_object_id} \
                and SourceFileStatus='Completed'\
                and FileName = '{self.file_name}'"
            )
            results = self.db_obj.get_df_from_query(query)

            # Defining year, month, date for partitioning
            d = datetime.date.today()
            year = str(d.year)
            month = str(d.strftime('%m'))
            date = str(d.strftime('%d'))

            eod_marker_strategy = None

            # Processing all the required files
            for _, file_info in results.iterrows():
                pipeline_log_id = file_info['PipelineLogID']
                source_file_process_log_id = file_info['SourceFileProcessLogID']
                file_name = file_info['FileName']
                source_count = file_info['SourceCount']
                source_path = file_info['RawPath']
                cdc_file_flag = file_info['IsCDCFile']

                # Getting Source name & country code using source id
                query = (
                    f"select SourceName, CountryCode from [Metadata].[SourceMaster] \
                    where SourceID={self.source_id}"
                )
                results = self.db_obj.get_df_from_query(query)
                source_name = results['SourceName'].values[0]
                country_name = results['CountryCode'].values[0]
            

                # Reading data from source master and source object tables
                query = (
                    f"select sm.CountrySourceProperties, sm.SourceType, \
                    sod.ObjectName ,sod.ObjectType ,sod.ObjectProperties \
                    from Metadata.SourceMaster sm join \
                    Metadata.SourceObjectDetail sod on \
                    sod.SourceId=sm.SourceID where \
                    SourceObjectID={self.source_object_id}"
                )
                results = self.db_obj.run_sql_query(query)
                cs_properties = json.loads(results[0][0][0])
                source_type = results[0][0][1]
                object_name = results[0][0][2]
                object_type = results[0][0][3]
                os_properties = json.loads(results[0][0][4])

                #Defining destination path
                transformed_path = (
                    TRANSFORMED_ZONE_DATA_PATH.replace(
                        'account', self.adls_account_name
                    ).replace(
                        "source",
                        source_name
                    ).replace(
                        "country",
                        country_name
                    )
                ) 
                

                # Get date index
                if cdc_file_flag:
                    file_name_part_list = file_name.split(".")
                    business_date = file_name_part_list[1].strip('D')
                    business_date= datetime.datetime.strptime(business_date, '%Y%j').date()
                    business_date = business_date.strftime('%Y%m%d')
                    business_time = file_name_part_list[1].strip('T')
                    eod_marker_strategy = cs_properties['eod.marker.strategy']
                else:
                    date_index = get_filename_date_index(file_name)

                # Defining source path
                if cdc_file_flag:
                    data_source = (
                    RAW_ZONE_CDC_PATH.replace(
                        'account', self.adls_account_name
                        )
                    )
                    raw_path = (
                        f'{data_source}{source_path}' 
                        )
                else:
                    data_source = (
                        RAW_ZONE_DATA_PATH.replace(
                            'account', self.adls_account_name
                        ).replace(
                            "source",
                            source_name
                        ).replace(
                            "country",
                            country_name
                        )
                    )
                    source_path = source_path.split(country_name+'/')[1]
                    raw_path = (
                    f'{data_source}/{source_path}'
                    )

                # Reading data
                schema, schema_info, col_to_cast = LandingToRawProcessor \
                    .object_schema_width_rules(self, self.source_object_id)
                if cdc_file_flag:
                    data = self.spark.read \
                    .option("multiline","true") \
                    .option("parserLib", "univocity") \
                    .option('delimiter','\u0001') \
                    .option("ignoreTrailingWhiteSpace", "true") \
                    .csv(raw_path + '/*.snappy', schema=schema, header=True)
                else:
                    data = self.spark.read \
                        .option("parserLib", "univocity") \
                        .option("ignoreTrailingWhiteSpace", "true") \
                        .csv(raw_path + '/*.snappy', schema=schema, header=True)

                
                for key, value in col_to_cast.items():
                    data = data.withColumn(key, f.col(key).cast(value))

                # Control File Processing
                LOGGER.info("Control file processing started.")
                ctrl_file = cs_properties['control_file']
                if ctrl_file in ('true', 'True'):
                    # Defining control file path
                    control_file_path = (
                        RAW_ZONE_DATA_PATH.replace(
                            'account', self.adls_account_name
                        ).replace(
                            "data", "control"
                        ).replace(
                            "source", source_name
                        ).replace(
                            "country", country_name
                        )
                    )
                    hschema, hschema_info, hcol_to_cast = LandingToRawProcessor \
                        .object_schema_width_rules(
                            self,
                            self.source_object_id,
                            'headercolschema'
                        )
                    tschema, tschema_info, tcol_to_cast = LandingToRawProcessor \
                        .object_schema_width_rules(
                            self,
                            self.source_object_id,
                            'trailercolschema'
                            )
                    control_data = self.spark.read \
                        .option("parserLib", "univocity") \
                        .option("ignoreTrailingWhiteSpace", "true") \
                        .csv(f'{control_file_path}/{source_name}_{country_name}*')
                    h_data = self.spark \
                        .createDataFrame(
                            control_data.where(f.col('_c0') == 'H').rdd,
                            schema=hschema
                            )
                    for key, value in hcol_to_cast.items():
                        if 'DECIMAL' or 'decimal' in value:
                            continue
                        else:
                            h_data = h_data.withColumn(key, f.col(key).cast(value))
                    trailer = control_data.where(f.col('_c0') == 'T')
                    countNullValues = trailer \
                        .select(
                            [f.count(f.when(f.col(a).isNull(), a)).alias(a) for a in trailer.columns]
                            ).collect()[0].asDict()
                    columnDrop = [d for d, n in countNullValues.items() if n > 0]
                    trailer = trailer.drop(*columnDrop)
                    t_data = self.spark.createDataFrame(
                        trailer.rdd,
                        schema=tschema
                        )
                    for key, value in tcol_to_cast.items():
                        if 'DECIMAL' or 'decimal' in value:
                            continue
                        else:
                            t_data = t_data.withColumn(key, f.col(key).cast(value))
                    hdata_dict = h_data.collect()
                    tdata_dict = t_data.collect()
                    for record in range(len(hdata_dict)):
                        metadata = {
                            'header': hdata_dict[record].asDict(),
                            'trailer': tdata_dict[record].asDict()
                        }
                        table_name = metadata['header']['table'].lower()
                        rowcount = metadata['trailer']['ROWCOUNT']
                        businessdate = metadata['header']['hDate']
                        query = (
                            f"select SourceObjectID from \
                            Metadata.SourceObjectDetail where \
                            ObjectName = '{table_name}'"
                        )
                        results = self.db_obj.run_sql_query(query)
                        if results:
                            object_id = results[0][0]
                            param = (
                                {'SourceObjectID': object_id,
                                'Metadata': json.dumps(metadata),
                                'RowCount': rowcount,
                                'BusinessDate': businessdate}
                            )
                            self.db_obj.run_stored_proc(
                                'ETLlog',
                                'SourceFileHeaderTrailerLogProc',
                                params=param
                            )

                # Row Count Validation
                LOGGER.info("Row count validation started.")
                query = (
                            f"select [RowCount] from \
                            [ETLlog].[SourceFileHeaderTrailerLog] where \
                            SourceObjectID = {self.source_object_id} \
                            and IsActive = 1"
                        )
                results = self.db_obj.run_sql_query(query)
                df_count = data.count()
                skip_row_flag = True
                if results[0]:
                    received_row_count = results[0][0][0]
                    if 'skip.row.count' in cs_properties:
                        if cs_properties['skip.row.count'].lower() == 'false':
                            skip_row_flag = False
                        else:
                            if results:
                                skip_row_flag = False
                            else:
                                LOGGER.info("Skip Row count is True.")
                    else:
                        if results:
                            skip_row_flag = False

                if not skip_row_flag:
                    if results:
                        if df_count != received_row_count:
                            LOGGER.info(
                                '''
                                Rejecting the file due to row count
                                mismatch.
                                '''
                            )
                            # TODO: Reject the file
                            break
                        else:
                            LOGGER.info("Row count validation successful !!.")
                    else:
                        LOGGER.info(
                            '''
                            Rejecting the file as skip row count is false
                            and metadata info is not available.
                            '''
                        )
                        # TODO: Reject the file
                        break

                # Column count validation
                LOGGER.info("Column count validation started.")
                col_count_from_properties = len(schema_info)
                if col_count_from_properties == len(data.columns):
                    LOGGER.info("Column count validation successful.")
                else:
                    LOGGER.info(
                        "Rejecting the file due to column length mismatch."
                    )
                    # TODO: Move to reject directory
                    break

                # Adding columns to data
                LOGGER.info("Adding audit columns to data.")
                uuidUdf = f.udf(lambda: str(uuid.uuid4()), t.StringType())
                
                #If file is a CDC file, use business date as date
                if cdc_file_flag:
                    df_added_columns = data.withColumn(
                        "date", f.lit(business_date)
                        ) \
                        .withColumn(
                            'time', f.expr(
                                "reflect('java.time.LocalDateTime', 'now')"
                            ).cast("string")
                        ) \
                        .withColumn('RowID',  uuidUdf()) \
                        .withColumn('file', f.lit(file_name))
                else:
                    file_content = file_name.split('_')
                    df_added_columns = data.withColumn(
                            "date", f.lit(file_content[date_index].strip('.csv'))
                            ) \
                            .withColumn(
                                'time', f.expr(
                                    "reflect('java.time.LocalDateTime', 'now')"
                                ).cast("string")
                            ) \
                            .withColumn('RowID',  uuidUdf()) \
                            .withColumn('file', f.lit(file_name))

                df_added_columns = df_added_columns\
                    .withColumn('time', f.translate(f.col("time"), "-:.", ""))
                df_added_columns = df_added_columns\
                    .withColumn('time', f.trim(f.col('time')))
                df_added_columns = df_added_columns\
                    .withColumn(
                        'RowID', f.concat(
                            f.col('time'), f.lit('_'), f.col('RowID')
                        )
                    )
                df_added_columns = df_added_columns\
                    .select(data.columns+['date', 'RowID', 'file'])
                
                LOGGER.info("Audit columns added successfully")

                # Date Columns Transformation
                LOGGER.info("Date columns transformation started.")
                # TODO: Integrate ColumnTransformationRules.xml
                func = f.udf(
                    lambda x: datetime.datetime.strptime(x, '%Y%m%d'), t.DateType()
                )
                df_added_columns = df_added_columns \
                    .withColumn(
                        'date', f.date_format(func(f.col('date')), 'MM-dd-yyy')
                    )
                LOGGER.info("Date columns transformation completed.")

                # TODO : Default capturing, replacement & logging.

                LOGGER.info("Generating necessary info for validations.")
                pk_stmt = ' is NULL) '
                dtype_list = []
                for items in schema_info:
                    col_name = items[0]
                    col_type = items[1]
                    # Generating pk statement
                    if items[4]:
                        if pk_stmt == ' is NULL) ':
                            pk_stmt = '(' + col_name + pk_stmt
                        else:
                            pk_stmt += f'or ({col_name} is NULL) '
                    # Generating datatype validation tuple
                    dtype_list.append((col_name, col_type.lower()))

                # Key Columns Check
                LOGGER.info("Key columns check started.")
                invalid_rec_dict = {}
                key_column_flag = {}
                df_invalid_col = None
                if pk_stmt != ' is NULL) ':
                    df_key_col_check = df_added_columns \
                        .filter(pk_stmt)
                    if df_key_col_check.count() > 0:
                        col_list = list(df_key_col_check.columns)
                        df_invalid_col = df_key_col_check\
                            .select('RowID',
                                    f.to_json(
                                        f.struct(col_list)
                                    ).alias("ErrorData")
                                    )
                        df_invalid_col = df_invalid_col \
                            .withColumn(
                                'PipeLineId',
                                f.lit(pipeline_log_id)) \
                            .withColumn(
                                'SourceObjectId',
                                f.lit(self.source_object_id)) \
                            .withColumn(
                                'SourceFileProcessLogId',
                                f.lit(source_file_process_log_id)) \
                            .withColumn(
                                'ErrorCode',
                                f.lit('PK Null Check')) \
                            .withColumn(
                                'ErrorDescription',
                                f.lit('Primary Key column are Null')
                                )
                        df_invalid_col = df_invalid_col.toPandas()
                LOGGER.info("Key columns check completed.")

                # Data Type Validation
                LOGGER.info("Data Type Validation started.")
                df_dtype_val = df_added_columns.dtypes
                dtype_validation = set(df_dtype_val).difference(set(dtype_list))
                if dtype_validation == {('date', 'string'), ('RowID', 'string'), ('file', 'string')}:
                    LOGGER.info('Data Type Validation successful')
                else:
                    LOGGER.info('Data Type Validation falied')
                    # TODO: Log the invalid columns and datatypes

                # Max Length Check
                LOGGER.info('Max Length check started')
                max_length_inv_list = []
                for item in schema_info:
                    col_name = item[0]
                    col_type = item[1]
                    col_len = item[5]
                    if (col_len is not None and col_len != 0) and col_type == 'string':
                        len_col_name = col_name + '_len'
                        df_length = df_added_columns \
                            .withColumn(len_col_name, f.length(f.col(col_name)))
                        first_value = df_length \
                            .orderBy(len_col_name) \
                            .select(len_col_name) \
                            .first()[len_col_name]
                        if first_value is not None:
                            ordered_df = df_added_columns\
                                .withColumn(
                                    len_col_name, f.length(f.col(col_name))
                                ).orderBy(len_col_name).select(len_col_name)
                            first_rec = (ordered_df.first())[len_col_name]
                            if int(first_rec) > col_len:
                                df_records = df_length.where(
                                    f.col(len_col_name) > col_len
                                )
                                ml_data_dict = map(
                                    lambda row: row.asDict(), df_records.collect()
                                )
                                for i in ml_data_dict:
                                    max_length_inv_list.append(json.dumps(i))
                invalid_rec_dict['Max Length Check'] = max_length_inv_list
                
                # Not Null check

                # Error Logging
                schema = 'ETLlog'
                stored_proc = 'uspInsertFileProcessErrorLog'
                table_type = 'TableType_FileProcessErrorLog'

                if df_invalid_col is not None:
                    self.db_obj.insert_data_from_df(
                                        schema,
                                        stored_proc,
                                        df_invalid_col,
                                        table_type
                                    )

                if invalid_rec_dict['Max Length Check']:
                    for key, value in invalid_rec_dict.items():
                        params = {
                            'PipeLineId': pipeline_log_id,
                            'SourceObjectId': self.source_object_id,
                            'SourceFileProcessLogId': source_file_process_log_id,
                            'RowID': i['RowID'],
                            'ErrorCode': key,
                            'ErrorDescription': 'Primary Key column is Null',
                            'ErrorData': json.dumps(i)
                            }

                        self.db_obj.run_stored_proc(schema, stored_proc, params)
                        key_column_flag[items[0]] = 'Failed'

                # Source Reconciliation
                LOGGER.info('Source Reconciliation started')
                if ('recon' or 'RECON') in file_name:
                    self.recon(df_added_columns)
                LOGGER.info('Source Reconciliation completed')
                
                # CDC File processing
                if cdc_file_flag:
                    LOGGER.info('Starting CDC File Processing')
                    final_df = self.process_cdc_data(
                            df_added_columns, 
                            source_name,
                            country_name,
                            object_name,
                            source_count,
                            eod_marker_strategy,
                            data_source,
                            pipeline_log_id,
                            source_file_process_log_id
                            )
                    if final_df == 'data saved':
                        # self.update_source_db(final_df, source_count, pipeline_log_id, source_file_process_log_id)
                        LOGGER.info('CDC File processed successfully')
                        continue

                # Flat File processing
                part_col = None
                if object_type == 'delta':
                    LOGGER.info('Starting Master Data Processing')
                    final_df = self.master_data_load(
                        df_added_columns,
                        source_name,
                        country_name,
                        object_name,
                        source_count,
                        pipeline_log_id,
                        source_file_process_log_id
                        )
                    if final_df == 'data saved':
                        LOGGER.info('Master Data processed successfully')
                        continue
                    else:
                        part_col = 'EffectiveEndDate'
                else:
                    df_added_columns = df_added_columns.withColumn('isDeleted', f.lit(0))
                    final_df = df_added_columns
                    part_col = 'date'     
                destination_transformed = f'{transformed_path}/{object_name}/'
                # getting log counts
                final_df_distinct = final_df.distinct()
                distinct_count = final_df_distinct.count()
                target_count = final_df.count()
                duplicate_count = target_count - distinct_count

                # Saving data in delta format
                LOGGER.info('Saving Data in Delta Format')
                final_df.coalesce(1).write \
                    .format("delta") \
                    .mode("append") \
                    .option("mergeSchema", "true") \
                    .partitionBy(part_col) \
                    .save(destination_transformed)

                # creating delta tables
                delta_table = source_name + '_' + country_name + '_' + object_name + '_delta'
                delta_table = delta_table.replace('$','')
                self.spark.sql(f'drop table if exists {delta_table}')
                self.spark.sql(f"CREATE TABLE {delta_table} USING DELTA OPTIONS(path '{destination_transformed}/')")
                LOGGER.info('Flat file processing successful')
                # updating source file process log table
                self.update_source_db(
                    target_count, source_count,
                    duplicate_count, pipeline_log_id,
                    source_file_process_log_id
                )

        except Exception as err:
            LOGGER.exception("Exception: " + str(err))
            param = {
                'SourceFileProcessLogID': source_file_process_log_id,
                'SourceId': self.source_id,
                'SourceCount': source_count,
                'TargetCount': None,
                'ErrorCount':None,
                'DuplicateCount': None,
                'SourceObjectId': self.source_object_id,
                'PipelineLogID': pipeline_log_id,
                'RawFileStatus': 'Failed',
                'IsLandingToRawProcessed': 1,
                'IsRawtoStandardisedProcessed': 0,
                'PipelineStatus': 'Failed'
                }
            self.db_obj.run_stored_proc(
                'ETLlog', 'uspUpdatePipelineLog', params=param
            )

    def recon(self, df_added_columns):
        func =  f.udf (lambda x: datetime.datetime.strptime(x, '%m-%d-%Y'), t.DateType())
        df_recon = df_added_columns.withColumn('date', f.date_format(func(f.col('date')), 'yyyMMdd'))    
        for row in map(lambda row: row.asDict(), df_recon.collect()):
            recon_status = 'Failed'
            source_name = row['src_stm']
            country_name = row['src_ctry']
            table_name = row['tbl_name'].lower()
            row_count = row['row_cnt']
            checksum_feild = row['chksum_fld_nm']
            checksum_tot = row['chksum_tot']
            date_fld = row['date_fld_nm']
            delta_table = source_name + '_' +country_name + '_' + table_name
            df = self.spark.sql('select count(*) from {} where date="{}"'.format(delta_table, date_fld))
            if df.first()['count(1)'] == row_count:
                recon_status = 'Success'     
            source_query = f"select row_cnt from {source_name}_{country_name}_{table_name} \
                where ods='{date_fld}' and TBL_NAME='{delta_table}'"
            target_query = f"select count(*) from {source_name}_{country_name}_{table_name} \
                where date='{date_fld}'"
            target_cnt = df.count()
            business_date = date_fld
            identifier = f'{source_name}_{country_name}_{table_name}_rowcount'
            params = {
            'SourceID':self.source_id,
            'SourceObjectID': self.source_object_id,
            'identifier': identifier,
            'SourceQuery': source_query, 
            'SourceValue': row_count, 
            'TargetQuery': target_query,
            'TargetValue': target_cnt,
            'BusinessDate': business_date,
            'SourceReconStatus': recon_status,
            'LastSourceReconDateTime': 'None'
            }
            schema = 'Recon'
            stored_proc = 'uspInsertEODRecon'
            self.db_obj.run_stored_proc(schema, stored_proc, params)

    def update_source_db(
        self,
        target_count,
        source_count,
        duplicate_count,
        pipeline_log_id,
        source_file_process_log_id
    ):
        error_count = source_count - (target_count + duplicate_count)
        params = {
            'PipelineLogID':pipeline_log_id,
            'SourceFileProcessLogID': source_file_process_log_id,
            'SourceCount': source_count,
            'TargetCount': target_count,
            'ErrorCount': error_count,
            'DuplicateCount': duplicate_count,
            'IsLandingToRawProcessed': 1,
            'IsRawtoStandardisedProcessed': 1,
            'sourceObjectID': self.source_object_id,
            'sourceID': self.source_id,
            'PipelineStatus': 'Succeeded',
            'RawFileStatus': 'Completed'
            }
        schema = 'ETLlog'
        stored_proc = 'uspUpdatePipelineLog'
        self.db_obj.run_stored_proc(schema, stored_proc, params)

    def master_data_load(
        self,
        df,
        source_name,
        country_name,
        object_name,
        source_count,
        pipeline_log_id,
        source_file_process_log_id
        ):
        '''
        This function is used to perform SCD type 2
        on master data.
        '''
        
        transformed_path = (
                    TRANSFORMED_ZONE_DATA_PATH.replace(
                        'account', self.adls_account_name
                    ).replace(
                        "source",
                        source_name
                    ).replace(
                        "country",
                        country_name
                    )
                ) 
                
        destination_transformed = f'{transformed_path}/{object_name}/'

        # Defining table name
        table_name = source_name + '_' + country_name + '_' + object_name

        # Adding StartDate, EndDate, isActive columns to master data
        df=df \
            .withColumn('EffectiveStartDate', f.current_timestamp()) \
            .withColumn('EffectiveEndDate', f.lit('9999_12_31 11_31_08')) \
            .withColumn('isActive', f.lit('1'))    
        df = df \
            .withColumn('EffectiveStartDate', f.to_timestamp("EffectiveStartDate", "yyyy_MM_dd HH_mm_ss")) \
            .withColumn('EffectiveEndDate', f.to_timestamp("EffectiveEndDate", "yyyy_MM_dd HH_mm_ss"))

        # Query to fetch all the columns for particular source, country and object 
        get_columns='''SELECT soc.ColumnName,soc.IsPrimaryKey
            FROM Metadata.SourceMaster sm with(nolock)
            JOIN Metadata.SourceObjectDetail sod with(nolock)
            ON sm.SourceID=sod.SourceID
            JOIN Metadata.SourceObjectSchema soc with(nolock)
            ON sod.SourceObjectID=soc.SourceObjectID 
            AND soc.columnname!='DUMMY'
            AND sm.SourceName=\''''+source_name+\
            '''\' AND sm.CountryCode=\''''+country_name+\
            '''\' AND sod.ObjectName=\''''+object_name+\
            '''\' AND soc.IsActive=1'''

        object_cols = self.db_obj.get_df_from_query(get_columns)
        object_cols_sdf = self.spark.createDataFrame(object_cols)

        column_list = (
            ','.join(object_cols["ColumnName"])+',EffectiveStartDate,EffectiveEndDate,isActive, file, RowID, date'
            )
        src_column_list = (
            'src.'+',src.'.join(object_cols["ColumnName"])+',current_timestamp(),src.EffectiveEndDate,src.isActive, src.file, src.RowID, src.date'
        )
        src_column_select_list = (
            'src.' + ',src.'.join(object_cols["ColumnName"]) + ',current_timestamp() as EffectiveStartDate,src.EffectiveEndDate,src.isActive, src.file, src.RowID, src.date'
        )
        key_columns = object_cols_sdf \
            .filter("IsPrimaryKey==1") \
            .withColumn(
                'KeyColumnCondition',f.concat(f.lit('tar.'),f.col("ColumnName"),f.lit('=src.'),f.col("ColumnName"))
            ) \
            .select("ColumnName",'KeyColumnCondition').toPandas()
        Key_column_condition_string=' and '.join(key_columns["KeyColumnCondition"])
        non_key_columns=object_cols_sdf \
            .filter("IsPrimaryKey==0") \
            .withColumn(
                'KeyColumnCondition', f.concat(f.lit('tar.'),f.col("ColumnName"),f.lit('=src.'),f.col("ColumnName"))
            ) \
            .select('ColumnName','KeyColumnCondition').toPandas()
        non_key_columns_rowhash_list_srcstring=',"|",'.join('src.'+non_key_columns["ColumnName"])
        non_key_columns_rowhash_list_string=',"|",'.join('tar.'+non_key_columns["ColumnName"])

        table_name=table_name.replace('$','')
        delta_table_name = table_name+'master'
        df.createOrReplaceTempView(delta_table_name)

        pk_columns = object_cols_sdf \
            .filter("IsPrimaryKey==1")\
            .select("ColumnName").toPandas()
        partition_string = ' , \n'.join(key_columns["ColumnName"])        
        
        df_distinct_data=self.spark.sql(f"""SELECT {column_list} FROM
                              (
                                select ROW_NUMBER() over (partition by {partition_string} ORDER BY {partition_string}) AS ROWNUMBER, {column_list}
                                from {delta_table_name} 
                              )
                              WHERE ROWNUMBER = 1""")
        df_distinct_data.createOrReplaceTempView(delta_table_name)
        # getting log counts for master load
        target_count = df.count()
        duplicate_count = target_count - df_distinct_data.count()

        check_if_table_exists = self.spark.sql("show tables '"+table_name+"_delta'") 
        if (check_if_table_exists.count()==0):
            df=df.withColumn("EffectiveEndDate_", df["EffectiveEndDate"])
            return df
        else:
            df_overwrite_schema=df.filter("1=2")
            df_overwrite_schema=df_overwrite_schema.withColumn("EffectiveEndDate_", df["EffectiveEndDate"])
            df_overwrite_schema.write \
            .format("delta") \
            .mode("append") \
            .option("mergeSchema", "true") \
            .partitionBy('EffectiveEndDate') \
            .save(
                destination_transformed
            )
            merge_statement = f'''
            Merge INTO {table_name}_delta as tar using {delta_table_name} as src 
            on {Key_column_condition_string} WHEN Matched and 
            sha2(concat_ws({non_key_columns_rowhash_list_srcstring}),256) 
            != sha2(concat_ws({non_key_columns_rowhash_list_string}),256) 
            and tar.isActive=1 then update SET EffectiveEndDate=current_timestamp(),isActive=0 
            When Not Matched THEN INSERT ({column_list}) values ({src_column_list})'''
            
            self.spark.sql(merge_statement)
            
            select_statement = f'''
            Select {src_column_select_list} FROM {delta_table_name}
            as src LEFT JOIN {table_name}_delta as tar ON 
            {Key_column_condition_string} AND tar.isActive=1  
            Where tar.isActive is null
            '''
            df_append = self.spark.sql(select_statement)
            df_append=df_append.withColumn("EffectiveEndDate_", df["EffectiveEndDate"])
            df_append.write \
            .format('delta') \
            .mode("append") \
            .partitionBy('EffectiveEndDate') \
            .save(
                destination_transformed
            )
            latest_data = self.spark.sql(f'select * from {table_name}_delta')

            self.update_source_db(
                target_count, source_count, 
                duplicate_count ,pipeline_log_id, 
                source_file_process_log_id
            )
            return('data saved')

    def process_cdc_data(self,
            df,
            source_name,
            country_name,
            object_name,
            source_count,
            eod_marker_strategy,
            data_source,
            pipeline_log_id,
            source_file_process_log_id):   
        
        # Fetch EOD Marker Time from watermark table
        if eod_marker_strategy == 'global_eod':         
           query = f"""SELECT PreviousEOD, CurrentEOD
                FROM ETLlog.CDCWatermark
                WHERE SourceName = '{source_name}'
                AND CountryCode = '{country_name}'
                AND EODMarkerStrategy = '{eod_marker_strategy}'
                AND ObjectName = 'all'"""
        elif eod_marker_strategy == 'table_level_eod':
            query = f"""SELECT PreviousEOD, CurrentEOD
                FROM ETLlog.CDCWatermark
                WHERE SourceName = '{source_name}'
                AND CountryCode = '{country_name}'
                AND EODMarkerStrategy = '{eod_marker_strategy}'
                AND ObjectName = '{object_name}'"""
        
        results = self.db_obj.run_sql_query(query)

        previous_eod_timestamp = results [0][0][0]
        current_eod_timestamp = results [0][0][1]

        # Put default date if previous EOD marker time is not available
        if previous_eod_timestamp is None:
            previous_eod_timestamp = '1900-01-01 00:00:00.000000'      

        # Create temporary view from dataframe
        df.createOrReplaceTempView("tbl_temp_source")
        # Getting log counts for DB Logging
        target_count = df.count()
        updated_records_count = self.spark.sql(
            "SELECT * FROM tbl_temp_source WHERE OPERATIONTYPE = 'A' OR \
                OPERATIONTYPE = 'B'"
        ).count()
        deleted_records_count = self.spark.sql(
            "SELECT * FROM tbl_temp_source WHERE OPERATIONTYPE = 'D'").count()
        inserted_records_count = self.spark.sql(
            "SELECT * FROM tbl_temp_source WHERE OPERATIONTYPE = 'I'").count()
        # Defining target delta table name
        target_delta_table = source_name + '_' + country_name + '_' + object_name + '_delta'
        
        #Check if target tables exists
        table_exists = self.spark.catalog._jcatalog.tableExists(f"{target_delta_table}")
        
        # Create target table if it does not exists
        # Select schema from temporary view, add columns for CDC to create target delta table
        if not table_exists:
          LOGGER.info('Creating Delta table as it does not exists')
          source_table_df = self.spark.sql(f"""select * from tbl_temp_source where 1=2""")
          source_table_df = source_table_df.withColumn("EffectiveStartDate",
                                f.lit(None).cast(t.TimestampType()))
          source_table_df = source_table_df.withColumn("EffectiveEndDate",
                                f.lit(None).cast(t.TimestampType()))
          source_table_df = source_table_df.withColumn("isActive", 
                                f.lit(None).cast(t.StringType()))
          source_table_df.createOrReplaceTempView(f"tmp_{target_delta_table}")
          
          transformed_path = (
                    TRANSFORMED_ZONE_DATA_PATH.replace(
                        'account', self.adls_account_name
                    ).replace(
                        "source",
                        source_name
                    ).replace(
                        "country",
                        country_name
                    )
                ) 
                
          destination_transformed = f'{transformed_path}/{object_name}/'
          
          self.spark.sql(f"""
                  CREATE TABLE IF NOT EXISTS {target_delta_table}
                  USING delta 
                  PARTITIONED BY (EffectiveEndDate) 
                  LOCATION '{destination_transformed}' AS 
                  SELECT * FROM tmp_{target_delta_table} where 1=2
                  """)
        
        # Fetch all the columns from SQL metastore
        get_columns='''SELECT soc.ColumnName,soc.IsPrimaryKey
            FROM Metadata.SourceMaster sm with(nolock)
            JOIN Metadata.SourceObjectDetail sod with(nolock)
            ON sm.SourceID=sod.SourceID
            JOIN Metadata.SourceObjectSchema soc with(nolock)
            ON sod.SourceObjectID=soc.SourceObjectID 
            AND soc.columnname!='DUMMY'
            AND sm.SourceName=\''''+source_name+\
            '''\' AND sm.CountryCode=\''''+country_name+\
            '''\' AND sod.ObjectName=\''''+object_name+\
            '''\' AND soc.IsActive=1'''

        object_cols = self.db_obj.get_df_from_query(get_columns)
        object_cols_df = self.spark.createDataFrame(object_cols)  

        # Filter the df to get primary key columns
        key_columns = object_cols_df \
            .filter("IsPrimaryKey==1")\
            .select("ColumnName").toPandas()
        pk_columns = ' , \n'.join(key_columns["ColumnName"]) 
        
        # Preparing join statement based on primary keys
        merged_keys = []
        pk_keys = pk_columns.split(",")
        for keys in pk_keys:
            merged_keys.append(keys.strip())
        pk_cols_join_cond = ' and '.join(map(lambda x: f"next.{x} = base.{x}", merged_keys))

        # Preparing where condition to filter records based on EOD Marker time
        where_condition = f"where (journaldate > \
                                (cast('{previous_eod_timestamp}' as timestamp))\
                            and journaldate <= \
                                (cast('{current_eod_timestamp}' as timestamp)))"

        # Define operation sequence for CDC operations
        pushdown_query = f"""SELECT *,
        CASE 
            WHEN OPERATIONTYPE = 'I' 
                THEN 1
            WHEN OPERATIONTYPE = 'B'
                THEN 2
            WHEN OPERATIONTYPE = 'A'
                THEN 3
            WHEN OPERATIONTYPE = 'D'
                THEN 4
        END AS operation_seq
        FROM tbl_temp_source"""
        updated_data = self.spark.sql(pushdown_query)
        updated_data.createOrReplaceTempView("""tbl_updated_source""")

        # Prepare query to mark active Flag
        pushdown_query = f"""SELECT * FROM
        (
        SELECT 
        base.*,
        CASE 
            WHEN base.rnum=1 and base.operationtype <> 'D'  
                THEN '1'
            ELSE '0' 
        END as isActive,
        base.JOURNALDATE AS EffectiveStartDate,
        to_timestamp(nvl((next.next_journal_date-(interval 1 second)),
            from_unixtime(unix_timestamp("9999-12-31 23:59:59", "yyyy-MM-dd HH:mm:ss"),"yyyy-MM-dd HH:mm:ss"))) AS EffectiveEndDate
        FROM
        (
        SELECT  * ,
            row_number() over (partition by {pk_columns} 
                order by journaldate desc, operation_seq desc) AS rnum
        FROM tbl_updated_source
        {where_condition}
        ) base
        LEFT OUTER JOIN 
        (
        SELECT 
            {pk_columns},
            journaldate as next_journal_date,
            row_number() over (partition by {pk_columns} 
                order by journaldate desc,operation_seq desc ) AS rnum
        FROM tbl_updated_source    
        {where_condition}
        ) next
        ON (next.rnum = base.rnum - 1 and {pk_cols_join_cond})
        ORDER BY rnum desc) source
        """
        change_data = self.spark.sql(pushdown_query)
        
        # Check if there are any new rows to be added or updated
        if bool(change_data.head(1)):
            change_data = change_data.drop("rnum")
            change_data = change_data.drop("operation_seq")
            
            colums_select_stmt = change_data.columns
            
            # Preparing string for insert
            target_tab_col_str = ','.join(colums_select_stmt)
            target_tab_insert_val = ','.join(list(map(lambda x: f"{x}", colums_select_stmt)))
            
            # Preparing data for merge
            obsolete_df = change_data.filter(f.col("isActive") == '0')
            if bool(obsolete_df.head(1)):
                # Mark obsolete records
                obsolete_df.createOrReplaceTempView(f"temp_{target_delta_table}")
                to_be_deleted_df = obsolete_df.filter(f.col("OPERATIONTYPE") == "D")
                if bool(to_be_deleted_df.head(1)):
                    print("No of rows to be deleted(update with 'isActive = 0') : ", to_be_deleted_df.count())
                    execute_stmt = self.execute_cdc(target_delta_table, True, True,
                                                    source=to_be_deleted_df,
                                                    merge_keys=merged_keys)
                    self.spark.sql(execute_stmt)
                else:
                    self.spark.sql(f"""MERGE INTO  {target_delta_table} USING temp_{target_delta_table}
                                        ON 1=2 
                                        WHEN NOT MATCHED 
                                        THEN INSERT ({target_tab_col_str}) 
                                        VALUES ({target_tab_insert_val})""")
                
            merged_keys.append('isActive')
            to_be_updated_df = change_data.filter(f.col("isActive") == '1')
            if bool(to_be_updated_df.head(1)):
                # Insert active records
                print("No of rows to be updated : ", to_be_updated_df.count())
                execute_stmt = self.execute_cdc(target_delta_table, True, False,
                                                                source=to_be_updated_df,
                                                                merge_keys=merged_keys)
                self.spark.sql(execute_stmt)
        
        self.update_source_db(target_count, source_count, 0, pipeline_log_id, source_file_process_log_id)
        self.update_cdc_source_count_summary(
            pipeline_log_id, updated_records_count, 
            deleted_records_count, inserted_records_count
        )
        return('data saved')
    
    def update_cdc_source_count_summary(
        self, pipeline_log_id, update_count, 
        delete_count, insert_count
    ):
        '''
        This function is used to insert the source count summary for CDC Files into
        ETLlog.CdcSourceCountSummary Table.
        '''
        params = {
            'PipelineLogID': pipeline_log_id,
            'UpdateRecords': update_count,
            'DeleteRecords': delete_count,
            'InsertRecords': insert_count
        }
        self.db_obj.run_stored_proc(
            'ETLLog','uspUpdateCdcSourceCountSummary', params=params
        )
        
    def execute_cdc(self, parameter_table_name, supply_obsolete_val, to_be_deleted,
                                  source: DataFrame, merge_keys: list) -> str:
        
        
        source.createOrReplaceTempView(f"tmp_source_{parameter_table_name}")
        cols = source.columns
        scd_type2_cols = set(cols) - {'EffectiveStartDate', 'EffectiveEndDate'}
  
       # Preparing Select statement dynamically for merge query
        select_stmnt_list = list(
            map(lambda x: "src.{}".format(x + " AS " + x + "_Key, src." + x if x in merge_keys else x), scd_type2_cols))
        select_stmnt_str = ', \n'.join(
            select_stmnt_list) + ', from_unixtime(unix_timestamp("1900-01-01 00:00:00", "yyyy-MM-dd HH:mm:ss"))' \
                                 ' as EffectiveStartDate, src.EffectiveEndDate'
        
        # Preparing Union statement dynamically for merge query
        union_all_stmnt_list = list(
            map(lambda x: "{}".format("NULL AS " + x + "_Key, src." + x if x in merge_keys else "src." + x),
                scd_type2_cols))        
        union_all_stmnt_str = ', \n'.join(union_all_stmnt_list) + ', src.EffectiveStartDate, \
        from_unixtime(unix_timestamp("9999-12-31 23:59:59", "yyyy-MM-dd HH:mm:ss")) as EffectiveEndDate'

        
        # Preparing join condition dynamically
        joining_str_inner = ' AND '.join(list(map(lambda x: "src.{} = trg.{}".format(x, x), merge_keys)))


        joining_str_outer = ' AND '.join(list(map(lambda x: "target.{} = source.{}".format(x, x + "_Key"), merge_keys)))

        
        cols_without_ts = set(cols) - {'RowID','file','date'}

        # Preparing insert statement for merge query                                               
        insert_col_str = ' , \n'.join(cols_without_ts)
        insert_val_str = ' , \n'.join(
            list(map(lambda x: "{}".format("\'1\'" if 'isActive' in x else "source." + x), cols_without_ts)))
        
                                                       
        if supply_obsolete_val:                                           
            insert_col_str = ' , \n'.join(cols)
            insert_val_str = ' , \n'.join(
                list(map(lambda x: "{}".format("source." + x), cols))) 
            select_stmnt_str = ', \n'.join(
                select_stmnt_list) + ', src.EffectiveStartDate, src.EffectiveEndDate'
            union_all_stmnt_str = ', \n'.join(union_all_stmnt_list) + ', src.EffectiveStartDate, \
          src.EffectiveEndDate'
            
        if to_be_deleted:
            insert_col_str = ' , \n'.join(cols)
            insert_val_str = ' , \n'.join(
                list(map(lambda x: "{}".format("\'0\'" if 'isActive' in x else "source." + x), cols)))
            
        match_cols = set(filter(lambda x: 'record_' not in x, set(cols_without_ts) - set(merge_keys))) - {
            'EffectiveStartDate', 'EffectiveEndDate'}
        match_src_str = "||'-'||".join(list(map(lambda x: f"nvl(cast(src.{x} as string),'')", match_cols)))
        match_trg_str = "||'-'||".join(list(map(lambda x: f"nvl(cast(trg.{x} as string),'')", match_cols)))
        match_str_inner = f"md5({match_src_str}) <> md5({match_trg_str})"

        match_src_str = "||'-'||".join(list(map(lambda x: f"nvl(cast(source.{x} as string),'')", match_cols)))
        match_trg_str = "||'-'||".join(list(map(lambda x: f"nvl(cast(target.{x} as string),'')", match_cols)))
        match_str_outer = f"md5({match_src_str}) <> md5({match_trg_str})"

        merge_statement = f"""MERGE INTO {parameter_table_name} target USING 
            ( SELECT {select_stmnt_str} 
            FROM tmp_source_{parameter_table_name} as src
            UNION ALL 
            SELECT {union_all_stmnt_str} FROM tmp_source_{parameter_table_name} as src 
            JOIN {parameter_table_name} as trg ON {joining_str_inner} 
            WHERE trg.isActive = \'1\' 
            AND {match_str_inner} ) source ON {joining_str_outer} 
            WHEN MATCHED AND {match_str_outer} THEN 
            UPDATE
            SET target.isActive = \'0\', 
            target.EffectiveEndDate = source.EffectiveStartDate - interval 1 second
            WHEN NOT MATCHED THEN INSERT ({insert_col_str}) VALUES ({insert_val_str})
            """

        
        return merge_statement
        

    def run(self):
        '''
        This method is used to run the raw to standardize pipeline
        end-to-end.
        '''
        LOGGER.info("Starting Raw to Standardized pipeline")
        LOGGER.info("Started Initialisation")
        self.config, self.db_obj = initialise(
            self.spark, self.spn_credentials, self.kv_name,
            self.adls_account_name, self.config_path
        )
        LOGGER.info("Ended Initialisation")
        LOGGER.info("Starting Processing Data Files")
        self.raw_to_standardize_processor()
