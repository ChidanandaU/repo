from datetime import datetime

import pandas as pd
from pyspark.sql.functions import col
from pyspark.sql.types import StructType, StructField, StringType

from edm.utils.const import TRANSFORMED_ZONE_DATA_PATH
from edm.utils.general_helper import (
    initialise, connect_to_synapse, get_polybase_refresh_statement_batch
)
from edm.utils.logging_utility import get_logger

LOGGER = get_logger(__name__)
EXTERNAL_DATA_SOURCE = 'ExtenalDataSourceTransformed'
DATE = datetime.today()


class SchemaEvolution:
    '''
    This class is used to handle the schema
    evolution scenarios.
    '''
    def __init__(
            self, source, country, file_name, object_name,
            pipeline_log_Id, spark, dbutils, **kwargs):
        '''
        This instantiates a Param Config Parser Object
        '''
        self.source = source
        self.country = country
        self.file_name = file_name
        self.object_name = object_name
        self.pipeline_log_Id = pipeline_log_Id
        self.spark = spark
        self.dbutils = dbutils
        self.spn_credentials = kwargs.get("spn_credentials", None)
        self.kv_name = kwargs.get("kv_name", None)
        self.adls_account_name = kwargs.get("adls_account_name", None)
        self.config_path = kwargs.get("config_path", None)

    def schema_evolution_handling(self):
        '''
        This method is used to run the schema
        evolution scenerios.
        '''
        self.transformed_data_path = (
            TRANSFORMED_ZONE_DATA_PATH.replace(
                "container",
                self.config['adls_details'][0]['transformed_container_name']
                ).replace(
                    "account",
                    self.config['adls_details'][0]['name']
                ).replace(
                    "source",
                    self.source
                ).replace(
                    "country",
                    self.country
                )
        )

        self.trans_delta_location = self.transformed_data_path + '/' + \
            self.object_name + '/'

        self.trans_delta_backup_location = self.transformed_data_path + '/' + \
            self.object_name + \
            str(DATE.strftime('%Y')) + \
            str(DATE.strftime('%m')) + \
            str(DATE.strftime('%d'))

        #  Getting the columns which are active or are schema evolved
        self.delta_table_name = self.source + '_' \
            + self.country + '_' \
            + self.object_name + '_delta'

        LOGGER.info("Getting Schema Evolution Meta info")
        df = self.get_metainfo_sql()
        schema_evolved_cols = df.loc[df['IsSchemaEvolved'] == 1, :]

        LOGGER.info("Checking Schema Evolution Condition")
        if(len(schema_evolved_cols) > 0):
            LOGGER.info("Performing Schema Evolution")
            if self.check_for_dbtable_existance():
                self.schema_evolution(df)
            # Refresh the polybase tables
            LOGGER.info("Refreshing Polybase Tables")
            self.refresh_polybase_table('dbo', df)
            # SP call to turn down schema evolution flag
            LOGGER.info("Turning Down Schema Evolution Flag")
            self.turn_down_schema_evolution_flag()

    def refresh_polybase_table(self, schema, table_property_df):
        table_name = f'{self.source}_{self.country}_{self.object_name}'
        sql_query = (
                f"SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE \
                    TABLE_SCHEMA = '{schema}' AND TABLE_NAME = '{table_name}'"
            )
        results, _ = self.synapse_obj.run_sql_query(
            sql_query
        )
        if len(results) != 0:
            self.synapse_obj.run_sql_query(
                f"DROP EXTERNAL TABLE {schema}.{table_name}"
            )
        polybase_sql_query = get_polybase_refresh_statement_batch(
                'dbo', self.object_name, self.source, self.country,
                table_property_df, EXTERNAL_DATA_SOURCE)
        self.synapse_obj.run_sql_query(polybase_sql_query)

    def get_metainfo_sql(self):
        '''
        Method to get all columns for all tables
        which are active or schema has evolved

        '''
        query = f"select \
                        sod.ObjectName, \
                        sm.SourceName, \
                        sm.CountryCode, \
                        ColumnName, \
                        ColumnOrder, \
                        DataType, \
                        IsPrimaryKey,  \
                        sob.IsActive, \
                        sob.IsSchemaEvolved, \
                        sod.ObjectType, \
                        sob.Length \
                    FROM [Metadata].[sourceobjectschema] sob \
                    JOIN [Metadata].[SourceObjectDetail] sod  \
                    ON sob.SourceObjectID = sod.SourceObjectID \
                    JOIN [metadata].[SourceMaster] AS SM  \
                        ON sm.SourceID=sod.SourceID \
                    WHERE sod.ObjectName = '{self.object_name}' \
                    AND SM.SourceName = '{self.source}' \
                    AND SM.CountryCode = '{self.country}'"

        df = self.db_obj.get_df_from_query(query)
        pd_df = df.sort_values(by=['ColumnOrder'], ascending=True)
        return pd_df

    def check_for_dbtable_existance(self):
        delta_table_exists = self.spark.sql(
                "show tables '" +
                self.source + '_' +
                self.country + '_' +
                self.object_name + "_delta'")

        if delta_table_exists.count() > 0:
            return True
        else:
            return False

    def turn_down_schema_evolution_flag(self):
        # Turning down the schema evolution flag the object
        params = {
            'SourceName': self.source,
            'CountryCode': self.country,
            'ObjectName': self.object_name
            }
        schema = 'ETLlog'
        stored_proc = 'uspTurnDownSchemaEvolutionFlagForObject'
        self.db_obj.run_stored_proc(schema, stored_proc, params)

    def refresh_pointintime_backup_table(self):
        ''''
        Method to take point in time backup and recreate databricks delta table

        '''
        self.dbutils.fs.cp(
            self.trans_delta_location, self.trans_delta_backup_location, True)
        # Dropping the table with point in time back up
        query_drop_pointintime_delta_table = 'DROP TABLE IF EXISTS ' + \
            self.source + '_' + \
            self.country + '_' + self.object_name + '_' + \
            str(DATE.strftime('%Y')) + \
            '_'+str(DATE.strftime('%m'))+'_' + \
            str(DATE.strftime('%d'))
        # Dropping the databricks table with YYYY_mm_dd if exists
        self.spark.sql(query_drop_pointintime_delta_table)

        # Recreating databricks table on delta files in
        # point in time back up folder
        query_add_pointintime_delta_table = 'create  table ' + self.source + \
            '_' + self.country + '_' + self.object_name + '_' + \
            str(DATE.strftime('%Y')) + '_' + \
            str(DATE.strftime('%m')) + '_' + \
            str(DATE.strftime('%d')) + \
            ' using DELTA options (path \'' + self.trans_delta_backup_location + '\')'
        self.spark.sql(query_add_pointintime_delta_table)

    def overwrite_delta_files(self):
        self.TableData.write.format('delta').partitionBy(
            self.partitioncolumn).mode('overwrite').option(
                'overwriteschema', 'true').save(self.trans_delta_location)

    def delete_columns(self, df, sourcename, country):
        '''
        Method to perform schema evolution for deleted columns

        '''
        active_columns_df = df[(df.IsActive == 1)]
        source_table_cols_query = f"DESCRIBE TABLE {self.delta_table_name}"
        source_table_cols = (
            self.spark.sql(source_table_cols_query)).toPandas()
        active_columns_df = pd.merge(
            active_columns_df, source_table_cols, left_on=[
                'ColumnName'], right_on=['col_name'], how='inner')
        columnlist = ','.join(active_columns_df['ColumnName'].values)

        #  Adding additional columns based type of table -
        # transaction or delta - To be validated
        if(active_columns_df['ObjectType'].unique() == 'txn'):
            columnlist = 'RowID,' + columnlist + ',date,file,IsActive'
            self.partitioncolumn = 'date'
        else:
            columnlist = 'RowID,' + columnlist + \
                ',date,file,EffectiveStartDate,EffectiveEndDate,IsActive'
            self.partitioncolumn = 'EffectiveEndDate'

        # Query to get value from DB table on delta files for table
        selectstring = 'SELECT ' + columnlist + ' FROM ' + sourcename + \
            '_' + country + '_' + self.object_name + '_delta'  
       
        print(selectstring)

        # Getting the table data based on active column list
        # which will be written to transformed and standardized zones
        self.TableData = self.spark.sql(selectstring)
        self.TableData.cache()        

    def schema_evolution(self, df):
        '''
        Method to perform schema evolution steps
            1. Perform evolution for table with deleted columns
            2. Perform column reorder and datatype change

        '''
        # 1. Perform evolution for tables with deleted columns
        self.column_delete_flag = False
        self.column_update_flag = False
        # getting the columns that are deleted and
        # have isActive = 0 and IsSchemaEvolved = 1
        deletedf = df.loc[
            (df['IsActive'] == 0) & (df['IsSchemaEvolved'] == 1),
            ["ObjectName", "SourceName", "CountryCode"]].drop_duplicates()

        # Handle column deletion if there is any deleted column
        if(len(deletedf) > 0):
            self.delete_columns(
                df, deletedf["SourceName"].values[0],
                deletedf["CountryCode"].values[0]
                )
            self.column_delete_flag = True

        # 2. Perform column reorder and datatype change

        # getting the columns for which updation has happened
        # and have IsActive = 1 and IsSchemaEvolved = 1
        updatedf = df.loc[
            (df['IsActive'] == 1) & (df['IsSchemaEvolved'] == 1),
            ["ObjectName", "SourceName", "CountryCode"]].drop_duplicates()

        if(len(updatedf) > 0):
            self.ColumnReorderAndDataTypechange(
                df,
                self.source + '_' + self.country + '_' + self.object_name
                )
            self.column_update_flag = True

        if self.column_delete_flag or self.column_update_flag:
            #self.refresh_pointintime_backup_table()
            self.overwrite_delta_files()

    def ColumnReorderAndDataTypechange(self, df, table_name):
        source_table = 'SchemaEvolutionSource_' + table_name
        existing_table = 'SchemaEvolutionCurrent_' + table_name

        active_columns_df = df.loc[df['IsActive'] == 1]
        if self.column_delete_flag:
            col_type_list = self.TableData.dtypes
            source_table_cols = pd.DataFrame(data=col_type_list, columns=['col_name', 'data_type'])
            schema = StructType([
                 StructField("col_name", StringType(), True),
                 StructField("data_type", StringType(), True)])
            source_cols_df = spark.createDataFrame(data=col_type_list, schema=schema) 
        else:
            source_table_cols_query = f"DESCRIBE TABLE {self.delta_table_name}"
            source_cols_df = self.spark.sql(source_table_cols_query)
            source_table_cols = (source_cols_df).toPandas()
        active_columns_df = pd.merge(
            active_columns_df, source_table_cols, left_on=[
                'ColumnName'], right_on=['col_name'], how='inner')

        # Checking for the column datatype

        # Getting the columns from the databricks delta table
        col_desc_df_pd = source_table_cols

        # Creating temp view -'SchemaEvolutionSource_' + table_name
        # with columns from the databricks delta table
        source_cols_df.createOrReplaceTempView(source_table)

        # Creating temp view on all active and schema evolved columns
        spark_df = self.spark.createDataFrame(df)
        spark_df.createOrReplaceTempView(existing_table)

        # Getting the columns for which datatype has changed
        column_typechange_query = f"SELECT st.col_name, st.data_type AS \
            SourceDataType, et.DataType AS CurrentDataType \
            FROM  {existing_table} as  et \
            join {source_table}  as st \
            on st.col_name = et.ColumnName \
            and lower(et.DataType)!=lower(st.data_type)"
        column_typechange_result = self.spark.sql(column_typechange_query)

        # Creating the column list to be used in select statement
        selectcolumnlist = ','.join(active_columns_df['ColumnName'])

        # Creating a new column by composing column name and datatype
        active_columns_df['ColumnWithDataType'] = (
            active_columns_df['ColumnName'] + ' ' +
            active_columns_df['DataType']
        )

        # Creating the column definition for alter statement
        columnlist = ','.join(active_columns_df['ColumnWithDataType'].values)

        # Getting the list of active columns and composing a list

        if(active_columns_df['ObjectType'].values[0] == 'txn'):
            selectstring = 'SELECT RowID,' + selectcolumnlist + \
                ',date,file FROM ' + table_name + '_delta'
            cols_to_ignore = ['RowID', 'date', 'file', 'IsActive']
            columnlist = 'RowID String,' + \
                columnlist + \
                ',date string, file string, IsActive String'
            self.partitioncolumn = 'date'
        else:
            selectstring = 'SELECT RowID,' + selectcolumnlist + \
                ',date,file,EffectiveStartDate,EffectiveEndDate,IsActive FROM ' + \
                table_name + '_delta'
            cols_to_ignore = [
                'RowID', 'date', 'file', 'IsActive', 'EffectiveStartDate',
                'EffectiveEndDate']
            columnlist = 'RowID String,' + columnlist + \
                ',date string,' + \
                'file string,' + \
                'EffectiveStartDate timestamp,' + \
                'EffectiveEndDate timestamp,' + \
                'IsActive string'
            self.partitioncolumn = 'EffectiveEndDate'

        # Columns from the delta table
        existing_col_list = list(
                col_desc_df_pd.loc[
                    ((
                        col_desc_df_pd['data_type'].notnull()) & ~(
                            col_desc_df_pd['col_name'].isin(cols_to_ignore)
                            )), :]['col_name'].values)
        current_col_list = list(active_columns_df['ColumnName'].values)
        # Fetching table data using selectstring
        if self.column_delete_flag is False:
            self.TableData = self.spark.sql(selectstring)

        if column_typechange_result.count() > 0:
            # If there is datatype change
            datatype_mismatched_columns = column_typechange_result.toPandas()
            for _, row in datatype_mismatched_columns.iterrows():
                self.TableData = self.TableData.withColumn(
                    row['col_name'], col(row['col_name']).cast(
                        row['CurrentDataType']))

        if(existing_col_list != current_col_list):
            # If there is no datatype change
            print(columnlist)
            self.TableData.createOrReplaceTempView('FinalDeltaTable')
            select_query = selectstring.replace(
                self.delta_table_name, 'FinalDeltaTable')
            self.TableData = self.spark.sql(select_query)            

    def run(self):
        '''
        This method is used to run the schema evolution
        process end-to-end.
        '''
        LOGGER.info("Starting Schema evolution process")
        LOGGER.info("Started Initialisation")
        self.config, self.db_obj = initialise(
            self.spark, self.spn_credentials, self.kv_name,
            self.adls_account_name, self.config_path
        )
        self.synapse_obj = connect_to_synapse(
            self.spn_credentials, self.kv_name, self.config)
        LOGGER.info("Ended Initialisation")
        LOGGER.info("Starting Processing ")
        try:
            LOGGER.info("Starting Schema Evolution")
            self.schema_evolution_handling()
            LOGGER.info("Ending Schema Evolution")
        except Exception as err:            
            LOGGER.exception(
                    f"Exception occured while performing schema evolution for \
                        {self.source}/{self.country}/{self.file_name}"
                    )
            param = {
                    'SourceName': self.source,
                    'CountryName': self.country,
                    'FileName': self.file_name,
                    'PipelineLogId': self.pipeline_log_Id,
                    'OnSchemaEvolution': 1,
                    'ExceptionDetails': str(err)
                    }
            self.db_obj.run_stored_proc(
                'ETLlog', 'uspInsertParamConfigErrorLog', params=param
            )
            raise Exception(str(err))