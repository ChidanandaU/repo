import asyncio
from datetime import datetime
import json
import uuid

from dotted.utils import dot_json
import pandas as pd
from pyspark.sql import Row
from pyspark.sql.functions import (
    col, to_json, from_json, lit, lower)

from edm.utils.const import (
    REALTIME_STAGING_DELTA_PATH,
    REALTIME_LANDING_PATH, GET_STREAMING_SOURCE_SCHEMA_DETAILS,
    GET_STREAMING_TABLE_COLUMN_PROP, GET_STREAMING_TABLE_EXPLODE_PROP
)
from edm.utils.event_hub_utility import EventHubConnection
from edm.utils.general_helper import (
    initialise, reformat_data, is_valid, remove_null_values_from_dict,
    convert_xml_event_to_json, indentify_event_format, get_xml_event_root_key,
    read_json_path_value, get_tokenized_col_str
)
from edm.utils.keyvault_utility import KeyvaultSecretsUtility
from edm.utils.logging_utility import get_logger


SCHEMA = 'Metadata'
ETL_LOG_SCHEMA = 'ETLlog'
EVENT_LOG_SP_NAME = 'uspUpdateStreamingEventLog'
TOKENIZATION_SP_NAME = 'uspRealtimeGetTokenizedColumns'
LOGGER = get_logger(__name__)


def get_explode_col_seq(json_tag):
    json_tag_parts = json_tag.split(".")
    json_explode_parts = json_tag_parts[0].split("_")
    seq_no = json_explode_parts[2]
    return int(seq_no)


def create_merge_statetment(source_table, target_table, table_prop_df):
    primary_key_cols = table_prop_df.loc[
        ((table_prop_df['IsPrimaryKey'] == 1) &
            (table_prop_df['IsActive'] == 1)),
        ['ColumnName', 'PkSequenceNumber']
    ]
    primary_key_cols.sort_values(by=['PkSequenceNumber'], inplace=True)
    primary_key_cols['PrimaryKeyCondition'] = (
        "Tar." + primary_key_cols['ColumnName'] + " = " +
        "Src." + primary_key_cols['ColumnName']
    )
    primary_key_condition_str = " AND ".join(
        primary_key_cols['PrimaryKeyCondition'].values
    )
    non_primary_key_cols = table_prop_df.loc[
        ((table_prop_df['IsPrimaryKey'] == 0) &
            (table_prop_df['IsActive'] == 1)),
        ['ColumnName', 'ColumnOrder']
    ]
    non_primary_key_cols.sort_values(by=['ColumnOrder'], inplace=True)
    non_primary_key_cols['ColumnUpdateCheckCondition'] = (
        "((ISNULL(Tar." + non_primary_key_cols['ColumnName'] + ") != " + "ISNULL(Src." +
        non_primary_key_cols['ColumnName'] + ")) OR (Tar." +  non_primary_key_cols['ColumnName'] + "!=" + "Src." + non_primary_key_cols['ColumnName'] + "))"
    )
    non_primary_key_update_check_str = " OR ".join(
        non_primary_key_cols['ColumnUpdateCheckCondition'].values
    )
    non_primary_key_cols['ColumnUpdateCondition'] = (
        "Tar." + non_primary_key_cols['ColumnName'] + " = " + "Src." +
        non_primary_key_cols['ColumnName']
    )
    update_condition_str = ",".join(
        non_primary_key_cols['ColumnUpdateCondition'].values
    )
    update_condition_str += (
        ",Tar.EventGuid = Src.EventGuid, Tar.ModifiedOn= Src.ModifiedOn"
    )
    table_schema = table_prop_df.loc[
        table_prop_df['IsActive'] == 1, ['ColumnOrder', 'ColumnName']
    ]
    table_schema.sort_values(by=['ColumnOrder'], inplace=True)
    schema_str = ",".join(table_schema['ColumnName'])
    schema_str += ',EventGuid, CreatedOn'
    table_schema['ColumnName'] = table_schema['ColumnName'] + ','
    insert_values_str = 'Src.' + "Src.".join(table_schema['ColumnName']).strip(
        ',')
    insert_values_str += ",Src.EventGuid,Src.CreatedOn"
    sql = f"MERGE INTO {target_table} AS Tar USING {source_table} AS Src"
    sql = sql + f" ON {primary_key_condition_str} WHEN MATCHED AND \
        ({non_primary_key_update_check_str}) THEN"
    sql = sql + f" UPDATE SET {update_condition_str} WHEN NOT MATCHED THEN"
    sql = sql + f" INSERT ({schema_str}) VALUES ( {insert_values_str})"
    return sql


class RealtimeEventProcessing:
    def __init__(self, spark, dbutils, **kwargs):
        self.spark = spark
        self.dbutils = dbutils
        self.kv_name = kwargs.get('kv_name', None)
        self.spn_credentials = kwargs.get('spn_credentials', None)
        self.config_path = kwargs.get('config_path', None)
        self.schema_mapping_filename = kwargs.get(
            'schema_mapping_filename', None)
        self.consumer_group = kwargs.get('consumer_group', None)
        self.adls_account_name = kwargs.get('adls_account_name', None)
        self.kv_client = KeyvaultSecretsUtility(
            self.spn_credentials,
            self.kv_name)

    def get_event_schema_format(self, streaming_source):
        '''
        This method is uses to get the streming source to event schema format mappings
        ADLS
        '''
        base_path = REALTIME_LANDING_PATH.replace(
            'account', self.adls_account_name
        )
        adls_config_path = (
            base_path.rstrip('/') + '/schema/' + self.schema_mapping_filename.lstrip('/')
        )
        mapping_df = self.spark.read.csv(adls_config_path, header=True)
        schema_format = (
            mapping_df.filter(
                lower(col("StreamingSource")) == streaming_source.lower()
                ).select(col("SchemaFormat")).collect()[0][0]
        )
        return schema_format

    def get_event_schema(self, streaming_source, schema_format):
        # uspGetStreamingSourceSchemaDetails
        sql_query = GET_STREAMING_SOURCE_SCHEMA_DETAILS.format(
            streaming_source
        )
        result_df = self.spark.sql(sql_query).toPandas()
        schema_guid = result_df['SchemaGuid'].values[0]
        if schema_format == 'avro':
            event_schema = (
                self.eventhub_connection.get_struct_schema_from_avro(
                    schema_guid)
                )
        elif schema_format == 'json':
            event_schema = (
                self.eventhub_connection.get_struct_schema_from_json(
                    schema_guid)
                )
        return event_schema

    def get_deserialized_event(self, input_df, event_schema):
        input_df = input_df.withColumn(
            'DeserializedEvent', to_json(from_json(
                col('EventData'), event_schema))
        )
        return input_df

    def get_streaming_source(self, event_body):
        event_dict = json.loads(event_body)
        return event_dict.get("streamingSource", None)

    def get_deserialised_event_from_schema(self, event_body, event_schema):
        event_body = json.dumps(json.loads(event_body))
        spark_df = self.spark.createDataFrame([Row(EventData=event_body)])
        deserailsed_event_df = self.get_deserialized_event(
            spark_df, event_schema
        )
        deserailsed_event = deserailsed_event_df.select(
            col('DeserializedEvent')).collect()[0][0]
        return deserailsed_event

    def insert_into_event_log(
        self, enqueued_time, event_process_start_time,
        sequence_number, event_id, streaming_source,
        event_process_end_time=None, is_valid=0
    ):
        enqueued_time = enqueued_time.strftime('%Y-%m-%d %H:%M:%S')
        event_process_start_time = event_process_start_time.strftime(
            '%Y-%m-%d %H:%M:%S')
        params = {
            'StreamingSourceName': streaming_source,
            'EventGuid': event_id,
            'IsValidated': int(is_valid),
            'EnqueuedTime': enqueued_time,
            'SequenceNumber': sequence_number,
            'ProcessingStartTime': event_process_start_time,
            'ProcessingEndTime': event_process_end_time,
            'Mode': 'insert'
        }
        self.db_obj.run_stored_proc(
            schema=ETL_LOG_SCHEMA,
            stored_proc=EVENT_LOG_SP_NAME,
            params=params
        )

    def get_event_body_to_json(self, event_body, event_format):
        if event_format in ['json', 'avro']:
            return event_body
        if event_format == 'xml':
            return convert_xml_event_to_json(event_body)

    def get_table_prop_df(self, streaming_source):
        # uspGetStreamingTableColumnProperties
        sql_query = GET_STREAMING_TABLE_COLUMN_PROP.format(streaming_source)
        result_df = self.spark.sql(sql_query).toPandas()
        return result_df

    def process_non_explode_columns(
        self, non_explode_col_df, event_format,
        event_dotted, xml_root_key=None
    ):
        table_dict = dict()
        non_explode_col_df.sort_values(by=['ColumnOrder'], inplace=True)
        for _, prop_row in non_explode_col_df.iterrows():
            column_name = prop_row['ColumnName']
            json_tag = prop_row['JsonTag']
            if event_format == 'xml':
                json_tag = f'{xml_root_key}.{json_tag}'
            table_dict[column_name] = read_json_path_value(
                event_dotted, json_tag
            )
        return pd.DataFrame([table_dict])

    def get_table_explode_prop(self, streaming_source, target_table_name):
        # uspGetTableExplodeProperties
        sql_query = GET_STREAMING_TABLE_EXPLODE_PROP.format(
            streaming_source, target_table_name
        )
        result_df = self.spark.sql(sql_query).toPandas()
        return result_df

    def process_explode_columns(
        self, explode_col_df, non_explode_rows_df,
        event_format, event_dotted, xml_root_key,
        streaming_source, table_name
    ):
        # spark_df = None
        explode_col_df.sort_values(
            ['ColumnOrder'], ascending=True, inplace=True)
        explode_col_df['ExplodeSequence'] = explode_col_df['JsonTag'].apply(
            get_explode_col_seq
        )
        explode_properties = self.get_table_explode_prop(
            streaming_source,
            table_name
        )
        explode_properties.sort_values(
            ['ExplodeColumnSequence'], ascending=True, inplace=True
        )

        for _, explode_prop in explode_properties.iterrows():
            explode_path_list = list()
            explode_seq = explode_prop['ExplodeColumnSequence']
            explode_json_path = explode_prop['ExplodeColumnJsonPath']
            if "," in explode_json_path:
                explode_path_list = explode_json_path.split(',')
            else:
                explode_path_list.append(explode_json_path)

            # iterate over the explode path list to get the value for each of
            # the paths
            explode_seq_value_list = list()
            explode_seq_value = None
            for path in explode_path_list:
                if explode_seq == 1:
                    path_value = read_json_path_value(event_dotted, path)
                    #path_value = get_primitive_type(path_value)
                    if len(explode_path_list) == 1:
                        explode_seq_value = path_value
                    else:
                        explode_seq_value_list.append(path_value)
                else:
                    dot_index = path.index(".")
                    tag_name = path[dot_index+1:]
                    tag_name = tag_name.replace("[", ".").replace("]", "")
                    non_explode_rows_df[f'exp_col_{explode_seq}'] = (
                        non_explode_rows_df[f'exp_col_{explode_seq-1}'].apply(
                            lambda x: x.get(tag_name)
                        )
                    )
                    non_explode_rows_df[f'exp_col_{explode_seq}'] = (
                        non_explode_rows_df.explode(f'exp_col_{explode_seq}')
                    )
                    #spark_df = spark_df.withColumn(
                    #    f'exp_col_{explode_seq}',
                    #    path)
                    #spark_df = spark_df.withColumn(
                    #    f'exp_col_{explode_seq}',
                    #    explode(col(f'exp_col_{explode_seq}'))
                    #)

            if explode_seq == 1:
                if len(explode_path_list) > 1:
                    non_explode_rows_df[f'exp_col_{explode_seq}'] = [
                        explode_seq_value_list]
                if explode_seq_value is not None:
                    non_explode_rows_df[f'exp_col_{explode_seq}'] = [
                        explode_seq_value]
                non_explode_rows_df = non_explode_rows_df.explode(
                    f'exp_col_{explode_seq}')
                # spark_df = self.spark.createDataFrame(non_explode_rows_df)

            explode_seq_cols_df = explode_col_df.loc[
                explode_col_df['ExplodeSequence'] == explode_seq, :
            ]
            for _, cols in explode_seq_cols_df.iterrows():
                json_path = cols['JsonTag']
                dot_index = json_path.index(".")
                tag_name = json_path[dot_index+1:]
                tag_name = tag_name.replace("[", ".").replace("]", "")
                column_name = cols['ColumnName']
                non_explode_rows_df[column_name] = (
                    non_explode_rows_df[f'exp_col_{explode_seq}'].apply(
                        lambda x: x.get(tag_name)
                        )
                )
                #spark_df = spark_df.withColumn(
                #    column_name, col(json_path)
                #)
            #non_explode_rows_df = spark_df.toPandas()
        return non_explode_rows_df

    def save_df_as_delta(
        self, table_df, table_name,
        streaming_source, event_id, table_prop_df
    ):
        delta_table_path = REALTIME_STAGING_DELTA_PATH.replace(
            'account', self.adls_account_name
        )
        delta_table_path = (
            delta_table_path.rstrip('/') + '/' + streaming_source + '/' +
            table_name
        )
        delta_table_name = f'{table_name}_delta'
        column_list = table_df.columns
        table_df = table_df.withColumn('CreatedOn', lit(datetime.utcnow()))
        table_df = table_df.withColumn('ModifiedOn', lit(datetime.utcnow()))
        table_df = table_df.withColumn('EventGuid', lit(event_id))
        show_tables_sql = f"SHOW TABLES '{delta_table_name}'"
        delta_tables = self.spark.sql(show_tables_sql)
        if delta_tables.count() == 0:
            table_df.write.format('delta').mode('overwrite').save(
                delta_table_path
            )
            delta_table_creation_sql = (
                f"CREATE TABLE {delta_table_name} USING DELTA LOCATION \
                    '{delta_table_path}'"
            )
            self.spark.sql(delta_table_creation_sql)
        else:
            table_df.createOrReplaceTempView(f'{delta_table_name}Temp')
            merge_statement = create_merge_statetment(
                f'{delta_table_name}Temp', delta_table_name, table_prop_df)
            self.spark.sql(merge_statement)

    def tokenize_columns(self, data, table_name, table_prop_df):
        tokneization_func_base = "create or replace temporary function {} as'com.protegrity.hive.udf.{}'"
        spark_data = self.spark.createDataFrame(data)
        spark_data.createOrReplaceTempView(f'{table_name}Temp')
        tokenized_col_str, tokenization_func = get_tokenized_col_str(
            table_prop_df, recon=False
        )
        # TODO: register the functions dynamically
        for func in tokenization_func:
            sql_statement = tokneization_func_base.format(func, func)
            self.spark.sql(sql_statement)
        spark_sql_query = f"SELECT {tokenized_col_str} FROM {table_name}Temp"
        tokenized_col_df = self.spark.sql(spark_sql_query)
        return tokenized_col_df

    def process_explode_tables(
        self, explode_table_df, target_tables_prop_df,
        event_data_formatted, event_format, xml_root_key,
        streaming_source, event_id, sequence_number
    ):
        event_dotted = dot_json(event_data_formatted)
        for _, row in explode_table_df.iterrows():
            table_name = row['TargetTableName']
            table_prop_df = target_tables_prop_df.loc[
                target_tables_prop_df['TargetTableName'] == table_name, :
            ]
            explode_columns = table_prop_df.loc[
                ((table_prop_df['IsExploded'] == 1) &
                    (table_prop_df['IsActive'] == 1)), :]
            non_explode_columns = table_prop_df.loc[
                ((table_prop_df['IsExploded'] == 0) &
                    (table_prop_df['IsActive'] == 1)), :]
            if len(non_explode_columns) > 0:
                non_explode_rows_df = self.process_non_explode_columns(
                    non_explode_columns, event_format, event_dotted,
                    xml_root_key
                )
            if len(explode_columns) > 0:
                exploded_rows_df = self.process_explode_columns(
                    explode_columns, non_explode_rows_df, event_format,
                    event_dotted, xml_root_key, streaming_source, table_name)

            table_column_list = table_prop_df.loc[
                table_prop_df['IsActive'] == 1, ['ColumnName', 'ColumnOrder']]
            table_column_list.sort_values(by=['ColumnOrder'], inplace=True)
            table_column_list = table_column_list['ColumnName'].values
            exploded_rows_df = exploded_rows_df.loc[:, table_column_list]

            LOGGER.info(f'Tokenizing columns for table {table_name}')
            tokenized_df = self.tokenize_columns(
                exploded_rows_df, table_name, table_prop_df
            )
            # tokenized_df = self.spark.createDataFrame(exploded_rows_df)
            LOGGER.info(
                f'Saving Event for {event_id} and {sequence_number} \
                    for table {table_name}'
            )
            self.save_df_as_delta(
                tokenized_df, table_name, streaming_source,
                event_id, table_prop_df
            )

    def process_non_explode_tables(
        self, non_explode_table_df, target_tables_prop_df,
        event_data_formatted, event_format, xml_root_key,
        streaming_source, event_id, sequence_number
    ):
        event_dotted = dot_json(event_data_formatted)
        for _, row in non_explode_table_df.iterrows():
            table_name = row['TargetTableName']
            table_prop_df = target_tables_prop_df.loc[
                target_tables_prop_df['TargetTableName'] == table_name, :
            ]
            non_explode_columns = table_prop_df.loc[
                ((table_prop_df['IsExploded'] == 0) &
                    (table_prop_df['IsActive'] == 1)), :]
            if len(non_explode_columns) > 0:
                non_explode_rows_df = self.process_non_explode_columns(
                    non_explode_columns, event_format, event_dotted,
                    xml_root_key
                )
            table_column_list = table_prop_df.loc[
                table_prop_df['IsActive'] == 1, ['ColumnName', 'ColumnOrder']
            ]
            table_column_list.sort_values(by=['ColumnOrder'], inplace=True)
            table_column_list = table_column_list['ColumnName'].values
            non_explode_rows_df = non_explode_rows_df.loc[:, table_column_list]
            LOGGER.info(f'Tokenizing columns for table {table_name}')
            tokenized_df = self.tokenize_columns(
                non_explode_rows_df, table_name, table_prop_df
            )
            LOGGER.info(
                f'Saving Event for {event_id} and {sequence_number} for table\
                    {table_name}'
            )
            self.save_df_as_delta(
                tokenized_df, table_name, streaming_source,
                event_id, table_prop_df
            )

    def process_valid_event(
        self, event_data_formatted, event_format, streaming_source,
        event_id, sequence_number
    ):
        if event_format.lower() == 'xml':
            xml_root_key = get_xml_event_root_key(event_data_formatted)
        else:
            xml_root_key = None
        target_table_prop_df = self.get_table_prop_df(streaming_source)
        non_explode_table_df = target_table_prop_df.loc[target_table_prop_df[
            'HasExplode'] == 0, ['TargetTableName', 'HasExplode']
        ].drop_duplicates()
        explode_table_df = target_table_prop_df.loc[target_table_prop_df[
            'HasExplode'] == 1, ['TargetTableName', 'HasExplode']
        ].drop_duplicates()

        if len(non_explode_table_df) > 0:
            non_explode_table_df = self.process_non_explode_tables(
                non_explode_table_df, target_table_prop_df,
                event_data_formatted, event_format, xml_root_key,
                streaming_source, event_id,
                sequence_number
            )

        if len(explode_table_df) > 0:
            explode_table_df = self.process_explode_tables(
                explode_table_df, target_table_prop_df, event_data_formatted,
                event_format, xml_root_key, streaming_source, event_id,
                sequence_number
            )

    async def on_event(self, partition_context, event):
        try:
            event_process_start_time = datetime.utcnow()
            event_body = event.body_as_str(encoding='UTF-8')
            event_id = uuid.uuid4().hex
            event_format = indentify_event_format(event_body)
            event_body = self.get_event_body_to_json(event_body, event_format)
            streaming_source = self.get_streaming_source(event_body)
            schema_format = self.get_event_schema_format(streaming_source)
            enqueued_time = event.enqueued_time
            sequence_number = event.sequence_number
            LOGGER.info(f'Getting Schema for {event_id} and {sequence_number}')
            event_schema = self.get_event_schema(
                streaming_source, schema_format)
            deserailsed_event = self.get_deserialised_event_from_schema(
                event_body, event_schema
            )
            event_data_wo_null = remove_null_values_from_dict(
                json.loads(event_body))
            deserailsed_event_formatted = reformat_data(
                json.loads(deserailsed_event))
            event_data_formatted = reformat_data(event_data_wo_null)
            LOGGER.info(f'Validating event for {event_id} and {sequence_number}')
            is_event_valid = is_valid(
                event_data_formatted, deserailsed_event_formatted)
            if is_event_valid:
                LOGGER.info(
                    f'Processing Event for {event_id} and {sequence_number}'
                )
                self.process_valid_event(
                    event_data_formatted, event_format, streaming_source,
                    event_id, sequence_number)
                process_end_time = datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')
                LOGGER.info(f'Logging Event with {event_id} and {sequence_number}')
                self.insert_into_event_log(
                    enqueued_time, event_process_start_time,
                    sequence_number, event_id, streaming_source,
                    event_process_end_time=process_end_time,
                    is_valid=is_event_valid
                )
            else:
                process_end_time = datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')
                self.insert_into_event_log(
                    enqueued_time, event_process_start_time,
                    sequence_number, event_id, streaming_source,
                    event_process_end_time=process_end_time,
                    is_valid=is_event_valid
                )
                await self.eventhub_connection.write_event_to_event_hub(
                    event_data_formatted
                )
            LOGGER.info(
                f'Checkpointing Event for {event_id} and {sequence_number}')
            await partition_context.update_checkpoint(event)
        except Exception as err:
            LOGGER.exception("Exception: " + str(err))
            self.insert_into_event_log(
                    enqueued_time, event_process_start_time,
                    sequence_number, event_id, streaming_source
                )

    async def receive_process_events(self):
        await self.eventhub_connection.consumer_client.receive(
            on_event=self.on_event, starting_position=-1
        )

    def run(self):
        '''
        This function starts the Stream event processing.
        It first initialised the required Clients, reads the .avsc
        file from the ADLS, Registers the schema content on the
        Azure Even Hub Registry and then updates the DB metastore.
        '''
        self.config, self.db_obj = initialise(
            self.spark, self.spn_credentials, self.kv_name,
            self.adls_account_name, self.config_path
        )
        self.eventhub_connection = EventHubConnection(
            self.spn_credentials, self.config, self.spark,
            consumer_group=self.consumer_group
        )
        loop = asyncio.get_event_loop()
        loop.run_until_complete(self.receive_process_events())