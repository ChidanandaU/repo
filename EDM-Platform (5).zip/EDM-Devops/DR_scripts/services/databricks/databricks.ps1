#
#
# PowerShell Script for  testing Databricks  in DR Region
#
#

# Make Sure Databricks cli is correctly configured to the right Databricks Workspace.
if($args[0] -eq $True) {
        Write-Output "Begin Databricks FailOver Process"

		terraform init -reconfigure -upgrade -input=false -backend-config="backend.dr.tfvars"
        (terraform workspace select "dr") -OR (terraform workspace new "dr")

        terraform plan -out "dr.plan"  -var-file="config.dr.tfvars"

        terraform apply  "dr.plan"

#	terraform plan -destroy -var-file="./Config/config.dr.tfvars"
      
#	terraform destroy -auto-approve -var-file="./Config/config.dr.tfvars"
}

else {

    Write-output "Databricks FailOver Process Skipped"
}