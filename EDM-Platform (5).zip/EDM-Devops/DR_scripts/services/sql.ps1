#
#
# Powershell Script for FailOver of Azure SQL DB
#
#
# SQL variables

$PrimaryresourceGroupName=$args[2]
$PrimaryserverName=$args[3]

$SecondaryresourceGroupName=$args[4]
$SecondaryServerName=$args[5]

$failoverGroupName =$args[6]

if($args[0] -eq $True){
        # Failover to secondary server
        Write-host "Failing over failover group to the secondary..."
        Switch-AzSqlDatabaseFailoverGroup `  -ResourceGroupName $SecondaryresourceGroupName `  -ServerName $SecondaryServerName `  -FailoverGroupName $failoverGroupName
        Write-host "Failed failover group to successfully to" $SecondaryServerName

}
else{

       Write-output "SQL DB FailOver FailOver Skipped"

}
if($args[1] -eq $True){
        # Failback to Primary Server
        Write-host "Failing back failover group to the Primary..."
        Switch-AzSqlDatabaseFailoverGroup `  -ResourceGroupName $PrimaryresourceGroupName `  -ServerName $PrimaryserverName `  -FailoverGroupName $failoverGroupName
        Write-host "Failed failover group successfully to back to" $PrimaryserverName
}
else{

    Write-output "SQL DB  Failback Skipped"

}


