# PRE-REQUISITES
# 1) Make Sure SQL FailOver Groups are Created during server provisioning.
# 2) Primary Synapse SQL Pool is  up and Online.
# 3) Storage Account replication Type should not LRS but RA-GRS
# 4) Databricks CLI is configured
#  You can ru this comamnd to configure databricks cli
#   - databricks configure --token
#  When prompted, Provide the Databricks workspace URL  and PAT Token.
# 5) Make Sure az cli with latest version and az powershell for powershell version>5.0 is installed.
#
#
# To Execute this PowerShell Script Use following Commands
#Start-Transcript -Path .\deployment.log
# &.\deployment.ps1
# Stop-Transcript
#
# Synapse Variables

$Config = (Get-Content  "parameters.json" -Raw) | ConvertFrom-Json
$servicesArray = $Config.services;


$subscription_id=$servicesArray[0].subscription_id
$primaryResourceGroup=$servicesArray[0].primaryResourceGroup
$PrimarySynapseWorkspace=$servicesArray[0].PrimarySynapseWorkspace
$primaryPoolName=$servicesArray[0].primaryPoolName

$SecondaryResourceGroup=$servicesArray[0].SecondaryResourceGroup
$SecondarySynapseWorkspace=$servicesArray[0].SecondarySynapseWorkspace
$SecondaryPoolName=$servicesArray[0].SecondaryPoolName

$DWPerformanceValue=$servicesArray[0].DWPerformanceValue

$BeginSynapseFailOver=$servicesArray[0].BeginSynapseFailOver
$CreateRestorePoint=$servicesArray[0].CreateRestorePoint
$RemoveRestorePoint=$servicesArray[0].RemoveRestorePoint

Write-Output "Begin Synapse FailOver Script Execution"

$SynapseScriptToRun= $PSScriptRoot+"\services\synapse.ps1"

&$SynapseScriptToRun $BeginSynapseFailOver $subscription_id $primaryResourceGroup $PrimarySynapseWorkspace $primaryPoolName $SecondaryResourceGroup $SecondarySynapseWorkspace $SecondaryPoolName $DWPerformanceValue $CreateRestorePoint $RemoveRestorePoint

#####--------------------------------------------------------------------------------------------####


#Storage Account Variables
$primaryResourceGroup=$servicesArray[1].primaryResourceGroup
$primaryStorageAccount=$servicesArray[1].primaryStorageAccount

$SecondaryResourceGroup=$servicesArray[1].SecondaryResourceGroup
$SecondaryStorageAccount=$servicesArray[1].SecondaryStorageAccount
$sku=$servicesArray[1].sku

$BeginSAFailover=$servicesArray[1].BeginSAFailover

Write-Output "Begin Storage Account FailOver Script Execution"

$StorageAccountScriptToRun= $PSScriptRoot+"\services\storageaccount.ps1"

&$StorageAccountScriptToRun $BeginSAFailover $primaryResourceGroup $primaryStorageAccount $SecondaryResourceGroup $SecondaryStorageAccount $sku
####----------------------------------------------------------------------------------------------####
# SQL DB Variables
$PrimaryresourceGroupName=$servicesArray[2].PrimaryresourceGroupName
$PrimaryserverName=$servicesArray[2].PrimaryserverName

$SecondaryresourceGroupName=$servicesArray[2].SecondaryresourceGroupName
$SecondaryServerName=$servicesArray[2].SecondaryserverName

$failoverGroupName=$servicesArray[2].failoverGroupName

$BeginSQLFailOver=$servicesArray[2].BeginSQLFailOver
$BeginSQLFailback=$servicesArray[2].BeginSQLFailback

Write-Output "Begin SQL DB FailOver Script Execution"

$StorageAccountScriptToRun= $PSScriptRoot+"\services\sql.ps1"

&$StorageAccountScriptToRun $BeginSQLFailOver $BeginSQLFailback $PrimaryresourceGroupName $PrimaryserverName $SecondaryresourceGroupName $SecondaryServerName $failoverGroupName


####---------------------------------------------------------------------------------------------######
#Databricks Variables
# Execute the Provisioning of Interactive Cluster by following commands-
# cd services/databricks
# &s ../../deployment.ps1
$BeginDatabricksFailOver = $servicesArray[3].BeginDatabricksFailOver
$DatabricksScriptToRun = $PSScriptRoot+"\services\databricks\databricks.ps1"

Write-Output "Begin Databricks FailOver Execution"

&$DatabricksScriptToRun $BeginDatabricksFailOver