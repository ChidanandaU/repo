CREATE TABLE [ETLlog].[StreamingFileLog](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[PipelineLogID] [int] NOT NULL,
	[FileName] [varchar](100) NOT NULL,
	[FilePath] [varchar](255) NOT NULL,
	[FileType] [varchar](50) NOT NULL,
	[StartTime] [datetime] NOT NULL,
	[EndTime] [datetime] NULL,
	[IsSuccessful] [bit] NOT NULL,
	[CreatedBy] [nvarchar](100) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](100) NULL,
	[ModifiedOn] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [ETLlog].[StreamingFileLog] ADD  DEFAULT (suser_name()) FOR [CreatedBy]
GO

ALTER TABLE [ETLlog].[StreamingFileLog] ADD  DEFAULT (getutcdate()) FOR [CreatedOn]
GO

ALTER TABLE [ETLlog].[StreamingFileLog]  WITH CHECK ADD FOREIGN KEY([PipelineLogID])
REFERENCES [ETLlog].[PipelineLog] ([PipelineLogID])
GO