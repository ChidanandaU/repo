CREATE TABLE [ETLlog].[PoolConfigurationLog](
	[PoolConfigurationLogID] [int] IDENTITY(1,1) NOT NULL,
	[PoolConfigurationID] [int] NULL,
	[InstancePoolId] [nvarchar](1000) NULL,
	[StartDate] [datetime] NULL,
	[EndDate] [datetime] NULL,
	[IsActive] [bit] NULL,
	[CreatedBy] [nvarchar](100) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](100) NULL,
	[ModifiedOn] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[PoolConfigurationLogID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [ETLlog].[PoolConfigurationLog] ADD  DEFAULT (suser_name()) FOR [CreatedBy]
GO

ALTER TABLE [ETLlog].[PoolConfigurationLog] ADD  DEFAULT (getutcdate()) FOR [CreatedOn]
GO

ALTER TABLE [ETLlog].[PoolConfigurationLog] ADD  DEFAULT (suser_name()) FOR [ModifiedBy]
GO

ALTER TABLE [ETLlog].[PoolConfigurationLog] ADD  DEFAULT (getutcdate()) FOR [ModifiedOn]
GO

ALTER TABLE [ETLlog].[PoolConfigurationLog]  WITH CHECK ADD FOREIGN KEY([PoolConfigurationID])
REFERENCES [Metadata].[PoolConfig] ([PoolConfigurationID])
GO