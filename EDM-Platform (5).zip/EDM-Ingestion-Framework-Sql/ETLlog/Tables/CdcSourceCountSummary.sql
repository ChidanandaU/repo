CREATE TABLE [ETLlog].[CdcSourceCountSummary](
	[SourceCountSummaryID] [int] IDENTITY(1,1) NOT NULL,
	[SourceFileProcessLogID] [int] NULL,
	[UpdateRecords] [int] NULL,
	[DeleteRecords] [int] NULL,
	[InsertRecords] [int] NULL,
	[CreatedOn] [datetime] NULL,
	[CreatedBy] [nvarchar](100) NULL,
	[ModifiedOn] [datetime] NULL,
	[ModifiedBy] [nvarchar](100) NULL,
PRIMARY KEY CLUSTERED 
(
	[SourceCountSummaryID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [ETLlog].[CdcSourceCountSummary]  WITH CHECK ADD FOREIGN KEY([SourceFileProcessLogID])
REFERENCES [ETLlog].[SourceFileProcessLog] ([SourceFileProcessLogID])
GO