﻿CREATE PROCEDURE [ETLlog].[SourceFileHeaderTrailerLogProc] 
@SourceObjectID int,
@Metadata nvarchar(max),
@BusinessDate nvarchar(200),
@RowCount bigint

AS   
-----------------------------------------------------------------------------------------------------------------------
/****** StoredProcedure:		[metadata].[uspInsertObjectSchema]
		Script Date:			2021-06-15 
		Author:					Vikash Jangid
		Test Execute:			This SP is used to insert or update records into the SourceFileHeaderTrailerLog Table.
		CMD:					EXEC [ETLlog].[SourceFileHeaderTrailerLogProc] 
								@SourceObjectID, @Metadata
******/
-----------------------------------------------------------------------------------------------------------------------

BEGIN
	BEGIN TRY
		SET NOCOUNT ON

		UPDATE [ETLlog].[SourceFileHeaderTrailerLog]
		SET
		IsActive = 0
		WHERE SourceObjectID = @SourceObjectID and BusinessDate = @BusinessDate 

		INSERT INTO [ETLlog].[SourceFileHeaderTrailerLog] 
		(SourceObjectID,Metadata,IsActive,ProjectCode,CreatedBy,CreatedOn,ModifiedBy,ModifiedOn,BusinessDate,[RowCount])
		VALUES
		(@SourceObjectID ,@Metadata,1,'POCProject001',suser_name(), switchoffset(sysdatetimeoffset(),'+05:30'),
		suser_name(), switchoffset(sysdatetimeoffset(),'+05:30'),@BusinessDate,@RowCount)
	END TRY

	BEGIN CATCH
		DECLARE @Errmsg NVARCHAR(4000) = (
				SELECT ERROR_MESSAGE()
				)
			,@ErrorSeverity INT = ERROR_SEVERITY()
			,@ErrorState INT = ERROR_STATE()

		RAISERROR (
				@Errmsg
				,@ErrorSeverity
				,@ErrorState
			)
	END CATCH
END