CREATE PROCEDURE [ETLlog].[uspUpdatePipelineActivityLog]
( 
  @PipelineActivityLogID INT,
  @ActivityStatus NVARCHAR(50)
)
AS 
-----------------------------------------------------------------------------------------------------------------------
/****** StoredProcedure:		[ETLlog].[uspUpdatePipelineActivityLog]
		Script Date:			2021-06-07 
		Author:					Santhosh Boyapally
		Test Execute:			This SP is used to update pipeline activity log
		CMD:					EXEC [ETLlog].[uspUpdatePipelineActivityLog]
								  @PipelineActivityLogID=<Value>, 
								  @ActivityStatus=<Value>
******/
-----------------------------------------------------------------------------------------------------------------------

BEGIN
	
	SET NOCOUNT ON;

	IF @PipelineActivityLogID IS NOT NULL

		UPDATE [EtlLog].[PipelineEtlActivityLog]
		SET 
		[ActivityStatus] = @ActivityStatus,
		[EndTime] = SWITCHOFFSET(SYSDATETIMEOFFSET(), '+05:30'),
		[ModifiedOn] = SWITCHOFFSET(SYSDATETIMEOFFSET(), '+05:30'),
		[ModifiedBy] = SUSER_NAME()
		WHERE PipelineActivityLogID = @PipelineActivityLogID;
	
END
GO


