﻿CREATE PROCEDURE [ETLlog].[uspUpsertCDCWatermark]
(
	@CDCWatermark [ETLlog].[TableType_CDCWatermark] READONLY
)
AS
-----------------------------------------------------------------------------------------------------------------------
/****** StoredProcedure:		[ETLlog].[uspUpsertCDCWatermark]
		Script Date:			2021-08-26 
		Author:					Sonam Jain
		Test Execute:			This SP is used to insert/update watermark value from CDC EOD marker files
		CMD:					EXEC [metadata].[uspUpdateProtegrityDetail] 
								@ProtegritySchema = @TableTypeParameter
******/
-----------------------------------------------------------------------------------------------------------------------
BEGIN	
	BEGIN TRY
		DROP TABLE IF EXISTS #TempCDCWatermark
		SELECT tmp.SourceName,
			tmp.CountryCode,
			tmp.SourceId,
			tmp.ObjectName,
			tmp.EODMarkerStrategy,
			MAX(tmp.EODMarker) AS EODMarker
		INTO #TempCDCWatermark 
		FROM @CDCWatermark tmp
		GROUP BY tmp.SourceName,
			tmp.CountryCode, 
			tmp.SourceId,
			tmp.ObjectName,
			tmp.EODMarkerStrategy

		UPDATE cw 
		SET cw.SourceId = sm.SourceId
		FROM #TempCDCWatermark  cw 
		INNER JOIN metadata.SourceMaster sm
		ON cw.SourceName = sm.SourceName
		AND cw.CountryCode = sm.CountryCode
	
		MERGE INTO ETLlog.CDCWatermark AS tar
		USING #TempCDCWatermark AS src
			ON src.SourceId = tar.SourceId
			AND src.ObjectName = tar.ObjectName
			AND src.EODMarkerStrategy = tar.EODMarkerStrategy
		WHEN MATCHED 
		THEN UPDATE
			SET PreviousEOD = tar.CurrentEOD,
				CurrentEOD = src.EODMarker,
				ModifiedBy = suser_name(),
				ModifiedOn = GETUTCDATE()
		WHEN NOT MATCHED
		THEN INSERT
			(
				SourceId,
				ObjectName,
				EODMarkerStrategy,
				PreviousEOD,
				CurrentEOD,
				CreatedBy,
				CreatedOn,
				ModifiedBy,
				ModifiedOn
			)
			VALUES
			(
				src.SourceId,
				src.ObjectName,
				src.EODMarkerStrategy,
				NULL,
				src.EODMarker,
				suser_name() ,
				GETUTCDATE(),
				suser_name() ,
				GETUTCDATE()
			);
END TRY
	BEGIN CATCH
		DECLARE @Errmsg NVARCHAR(4000) = (
				SELECT ERROR_MESSAGE()
				)
			,@ErrorSeverity INT = ERROR_SEVERITY()
			,@ErrorState INT = ERROR_STATE()

		RAISERROR (
				@Errmsg
				,@ErrorSeverity
				,@ErrorState
				)
	END CATCH
END


GO


