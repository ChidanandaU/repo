CREATE PROCEDURE [ETLlog].[uspInsertPipelineActivityErrorLog]
( 
  @PipelineLogID INT,
  @PipelineActivityLogID INT,
  @ErrorMessage NVARCHAR(MAX),
  @SoucreFileProcessLogID INT,
  @IsLandingToRawProcessed BIT,
  @IsRawtoStandardisedProcessed BIT,
  @Details BIT = 1
)
AS 
-----------------------------------------------------------------------------------------------------------------------
/****** StoredProcedure:		[ETLlog].[uspInsertPipelineActivityErrorLog]
		Script Date:			2021-08-06 
		Author:					Vikash
		Test Execute:			This SP is used to insert records on failre into Activity Error Log Table
								and also update the PipelineLog with Unsuccessful status.
		CMD:					EXEC [ETLlog].[uspInsertPipelineActivityErrorLog]
								@PipelineLogID = '<value>', @PipelineActivityLogID = '<value>', @ErrorMessage = '<value>',
								@SoucreFileProcessLogID = '<value>', @@IsLandingToRawProcessed = '<value>', 
								@IsRawtoStandardisedProcessed = '<value>'
******/
-----------------------------------------------------------------------------------------------------------------------
BEGIN
	BEGIN TRY
		SET NOCOUNT ON;

		IF @Details = 1
		BEGIN
			INSERT INTO [EtlLog].[PipelineActivityErrorLog] 
			(PipelineActivityLogID, ErrorMessage)
			VALUES
			(@PipelineActivityLogID, @ErrorMessage);

			-- Update the activity status as failed.
			EXEC [EtlLog].[uspUpdatePipelineActivityLog]
				@PipelineActivityLogID = @PipelineActivityLogID,
				@ActivityStatus = 'Failed'

			-- Update the pipeline status as failed.
			EXEC [EtlLog].[uspUpdatePipelineLog]
			@PipelineLogID = @PipelineLogID,
			@SourceFileProcessLogID = @SoucreFileProcessLogID,
			@SourceCount = NULL, 
			@TargetCount = NULL, 
			@ErrorCount  = NULL, 
			@IsLandingToRawProcessed = 0,
			@IsRawtoStandardisedProcessed = 0,
			@SourceObjectId = NULL, 
			@SourceId= NULL,
			@PipelineStatus = 'Failed',
			@SourceFileStatus = 'Failed'
		END

		ELSE
		BEGIN
			INSERT INTO [EtlLog].[PipelineActivityErrorLog] 
			(PipelineActivityLogID, ErrorMessage)
			VALUES
			(@PipelineActivityLogID, @ErrorMessage);

			-- Update the activity status as failed.
			EXEC [EtlLog].[uspUpdatePipelineActivityLog]
				@PipelineActivityLogID = @PipelineActivityLogID,
				@ActivityStatus = 'Failed'
		END
	END TRY

	BEGIN CATCH
		DECLARE @Errmsg NVARCHAR(4000) = (
				SELECT ERROR_MESSAGE()
				)
			,@ErrorSeverity INT = ERROR_SEVERITY()
			,@ErrorState INT = ERROR_STATE()

		RAISERROR (
				@Errmsg
				,@ErrorSeverity
				,@ErrorState
			)
	END CATCH
END