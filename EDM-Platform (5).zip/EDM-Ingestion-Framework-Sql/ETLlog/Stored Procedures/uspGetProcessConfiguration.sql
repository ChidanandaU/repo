CREATE PROCEDURE [ETLlog].[uspGetProcessConfiguration]
( 
   @SourceObjectId INT, 
   @SourceID INT, 
   @Type NVARCHAR(1000),
   @FileName nvarchar(1000)
)
AS
-----------------------------------------------------------------------------------------------------------------------
/****** StoredProcedure:		[ETLlog].[uspGetProcessConfiguration]
		Script Date:			2021-06-07 
		Author:					Divye Rastogi
		Test Execute:			This SP is used to get the cluster and instance configuration information
		CMD:					EXEC [ETLlog].[uspGetProcessConfiguration]
								  @SourceObjectId=<Value>, 
								  @SourceID=<Value>, 
								  @Type=<Value>,
								  @FileName=<Value>
******/
-----------------------------------------------------------------------------------------------------------------------
BEGIN
	BEGIN TRY
	
	SET NOCOUNT ON;
	
	DECLARE @sourcename nvarchar(1000),
			@ProjectCode nvarchar(1000)

	IF @Type='LandingToRaw'
	BEGIN 

	 SELECT @sourcename=Substring(@FileName,0,CHARINDEX('_',@FileName))

	 SELECT @ProjectCode=ProjectCode
	  FROM Metadata.SourceMaster 
	  where SourceName=@sourcename
	  
	 SELECT InstancePoolId,
		       CL.ClusterType,
			   CL.ClusterDriverType,
			   CL.ClusterNodeType,
		       CL.ClusterVersion,
			   cast(ClusterMinNodes as nvarchar)+':'+cast(ClusterMaxNodes as varchar) AS WorkerNode,
			   @ProjectCode as ProjectCode
		 FROM ETLlog.PoolConfigurationLog PCL
		 JOIN Metadata.PoolConfig PC 
		   ON pc.PoolConfigurationID=pcl.PoolConfigurationID
		  --AND pc.IsLandingToRaw=1
		 JOIN [Metadata].[ClusterConfig] CL 
		   ON pcl.PoolConfigurationID=cl.PoolConfigurationID
		 WHERE PCL.IsActive=1
	END
	ELSE IF @Type = 'RawToStandardized'
	BEGIN
		SELECT @ProjectCode=ProjectCode
		FROM Metadata.SourceMaster 
		WHERE SourceID = @SourceID

		SELECT InstancePoolId,
		       CL.ClusterType,
			   CL.ClusterDriverType,
			   CL.ClusterNodeType,
		       CL.ClusterVersion,
			   cast(ClusterMinNodes as nvarchar)+':'+cast(ClusterMaxNodes as varchar) AS WorkerNode,
			   @ProjectCode as ProjectCode
		 FROM ETLlog.PoolConfigurationLog PCL
		 JOIN Metadata.PoolConfig PC 
		   ON pc.PoolConfigurationID=pcl.PoolConfigurationID
		 JOIN [Metadata].[ClusterConfig] CL 
		   ON pcl.PoolConfigurationID=cl.PoolConfigurationID
		 WHERE PCL.IsActive=1
	END
	ELSE 
	BEGIN 

		SELECT InstancePoolId,
		       CL.ClusterType,
			   CL.ClusterDriverType,
			   CL.ClusterNodeType,
		       CL.ClusterVersion,
			   cast(ClusterMinNodes as nvarchar)+':'+cast(ClusterMaxNodes as varchar) AS WorkerNode,
			   sm.ProjectCode as ProjectCode
		 FROM Metadata.SourceMaster SM
		 JOIN [Metadata].[ClusterConfig] CL 
		   ON SM.ClusterConfigurationID=cl.ClusterConfigurationID
		  AND SM.SourceId=@SourceID
    LEFT JOIN ETLlog.PoolConfigurationLog pcl
		   ON pcl.PoolConfigurationID=CL.PoolConfigurationID
		  AND pcl.IsActive=1
	END 
	

END TRY

	BEGIN CATCH
		DECLARE @Errmsg NVARCHAR(4000) = (
				SELECT ERROR_MESSAGE()
				)
			,@ErrorSeverity INT = ERROR_SEVERITY()
			,@ErrorState INT = ERROR_STATE()

		RAISERROR (
				@Errmsg
				,@ErrorSeverity
				,@ErrorState
				)
	END CATCH
END
