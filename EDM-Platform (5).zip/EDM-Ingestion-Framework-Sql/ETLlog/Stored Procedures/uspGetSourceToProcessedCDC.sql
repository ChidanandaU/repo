﻿CREATE PROCEDURE [ETLlog].[uspGetSourceToProcessedCDC] 
@FilePath NVARCHAR(MAX),
@FileName NVARCHAR(200) 
AS
-----------------------------------------------------------------------------------------------------------------------
/****** StoredProcedure:		[ETLLOG].[uspGetSourceToProcessedCDC]
		Script Date:			2021-08-17
		Author:					Ankita Kumari	
		Test Execute:			This SP is used to get the source id & source object id for EOD Marker files
		CMD:					EXEC [ETLLOG].[uspGetSourceToProcessedCDC] 
								@FilePath='<value>',
								@FileName = '<value>'
******/
-----------------------------------------------------------------------------------------------------------------------
BEGIN
	BEGIN TRY
	
	SELECT SourceId, SourceObjectId
	  FROM Etllog.SourceFileProcessLog SPL WITH(NOLOCK) 
	  WHERE RawPath=@FilePath
	  AND FileName = @FileName

	END TRY

	BEGIN CATCH
	DECLARE @Errmsg NVARCHAR(4000) = (
				SELECT ERROR_MESSAGE()
				)
			,@ErrorSeverity INT = ERROR_SEVERITY()
			,@ErrorState INT = ERROR_STATE()

		RAISERROR (
				@Errmsg
				,@ErrorSeverity
				,@ErrorState
				)
	END CATCH
END
GO


