CREATE PROCEDURE [ETLlog].[uspArchiveETLLogs]
( @RetentionPeriod INT
)
AS 
-----------------------------------------------------------------------------------------------------------------------    
/****** StoredProcedure:	[ETLlog].[uspArchiveETLLogs]
  Script Date:				2021-08-23    
  Author:					Purushotham Chanda
  Test Execute:				This SP is used to archiving the ETL log tables by deleting the records for no of previous daa
  CMD:						EXEC [ETLlog].[uspArchiveETLLogs]
							@RetentionPeriod = '<value>'
******/    
-----------------------------------------------------------------------------------------------------------------------    

BEGIN
	
	SET NOCOUNT ON;	

	BEGIN TRY
	
	DELETE fpel FROM ETLlog.FileProcessErrorLog fpel JOIN ETLlog.SourceFileProcessLog sfpl ON fpel.SourceFileProcessLogId=sfpl.SourceFileProcessLogId
													 JOIN ETLlog.PipelineLog pll ON sfpl.PipelineLogID=pll.PipelineLogID 
														  WHERE pll.ModifiedOn<=GETUTCDATE()-@RetentionPeriod 
	DELETE pcel FROM ETLlog.ParamConfigErrorLog pcel JOIN ETLlog.SourceFileProcessLog sfpl ON pcel.SourceFileProcessLogId=sfpl.SourceFileProcessLogId
													 JOIN ETLlog.PipelineLog pll ON sfpl.PipelineLogID=pll.PipelineLogID 
														  WHERE pll.ModifiedOn<=GETUTCDATE()-@RetentionPeriod 
	DELETE pael FROM ETLlog.PipelineActivityErrorLog pael JOIN ETLlog.PipelineEtlActivityLog peal ON pael.PipelineActivityLogID=peal.PipelineActivityLogID
														  JOIN ETLlog.PipelineLog pll ON peal.PipelineLogID=pll.PipelineLogID 
														  WHERE pll.ModifiedOn<=GETUTCDATE()-@RetentionPeriod
	DELETE sfpl FROM ETLlog.SourceFileProcessLog sfpl JOIN ETLlog.PipelineLog pll ON sfpl.PipelineLogID=pll.PipelineLogID 
														  WHERE pll.ModifiedOn<=GETUTCDATE()-@RetentionPeriod 
	DELETE peal FROM ETLlog.PipelineEtlActivityLog peal JOIN ETLlog.PipelineLog pll ON peal.PipelineLogID=pll.PipelineLogID 
														  WHERE pll.ModifiedOn<=GETUTCDATE()-@RetentionPeriod 
	DELETE ETLlog.PipelineLog  WHERE ModifiedOn<=GETUTCDATE()-@RetentionPeriod AND PipeLineName IN ('PL_EDM_BatchIngestion_DeleteJobPool', 
																									'PL_EDM_BatchIngestion_NewJobPoolCreation',
																									'PL_EDM_BatchIngestion_LandingtoRaw',
																									'PL_EDM_BatchIngestion_ProcessLandingFiles',
																									'PL_EDM_BatchIngestion_RawToStandardized')
								          
	--DELETE  FROM ETLlog.StreamingEventLog WHERE ModifiedOn<=GETUTCDATE()-@RetentionPeriod
	--DELETE sfl FROM ETLlog.StreamingFileLog sfl JOIN ETLlog.PipelineLog pll ON sfl.PipelineLogID=pll.PipelineLogID 
	--													  WHERE pll.ModifiedOn<=GETUTCDATE()-@RetentionPeriod 
	DELETE FROM ETLlog.CDCWatermark WHERE ModifiedOn<=GETUTCDATE()-@RetentionPeriod
   
	END TRY
		BEGIN CATCH
			DECLARE @Errmsg NVARCHAR(4000) = (
				SELECT ERROR_MESSAGE()
				)
			,@ErrorSeverity INT = ERROR_SEVERITY()
			,@ErrorState INT = ERROR_STATE()

		RAISERROR (
				@Errmsg
				,@ErrorSeverity
				,@ErrorState
				)
		END CATCH
END
GO


