﻿CREATE PROCEDURE [ETLlog].[uspGetSourceToProcessed] 
@FrequencyDurationUnit nvarchar(100)
AS
-----------------------------------------------------------------------------------------------------------------------
/****** StoredProcedure:		[ETLLOG].[uspGetSourceToProcessed]
		Script Date:			2021-06-01
		Author:					Santhosh Boyapally	
		Test Execute:			This SP is used to get the sources to processed
		CMD:					EXEC [ETLLOG].[uspGetSourceToProcessed] 
								@Frequency='Day'
******/
-----------------------------------------------------------------------------------------------------------------------
BEGIN
	BEGIN TRY
	
	SELECT Distinct SOD.SourceID,SOD.SourceName,SOD.SourceType
	  FROM Etllog.SourceFileProcessLog SPL WITH(NOLOCK) 
	  JOIN Metadata.SourceMaster SOD WITH(NOLOCK)
	    ON SPL.SourceID=SOD.SourceID 
	   AND SPL.IsLandingToRawProcessed=1 
	   AND SPL.IsRawtoStandardisedProcessed=0
	   AND SPL.RawFileStatus = 'Not Processed'
	   AND IsCDCFile = 0
	   AND SOD.FrequencyDurationUnit=@FrequencyDurationUnit
	  
	END TRY

	BEGIN CATCH
	DECLARE @Errmsg NVARCHAR(4000) = (
				SELECT ERROR_MESSAGE()
				)
			,@ErrorSeverity INT = ERROR_SEVERITY()
			,@ErrorState INT = ERROR_STATE()

		RAISERROR (
				@Errmsg
				,@ErrorSeverity
				,@ErrorState
				)
	END CATCH
END
GO


