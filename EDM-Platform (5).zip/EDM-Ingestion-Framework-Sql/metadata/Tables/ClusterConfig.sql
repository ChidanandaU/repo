CREATE TABLE [Metadata].[ClusterConfig](
	[ClusterConfigurationID] [int] IDENTITY(1,1) NOT NULL,
	[PoolConfigurationID] [int] NULL,
	[ClusterConfigurationName] [nvarchar](200) NOT NULL,
	[ClusterType] [nvarchar](1000) NOT NULL,
	[ClusterDriverType] [nvarchar](1000) NULL,
	[ClusterVersion] [nvarchar](1000) NULL,
	[ClusterNodeType] [nvarchar](1000) NULL,
	[ClusterMinNodes] [int] NULL,
	[ClusterMaxNodes] [int] NULL,
	[AutoTerminationMinutes] [int] NULL,
	[SparkEnvVars] [nvarchar](1000) NULL,
	[Libraries] [nvarchar](max) NULL,
	[CreatedBy] [nvarchar](100) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](100) NULL,
	[ModifiedOn] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[ClusterConfigurationID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [Metadata].[ClusterConfig] ADD  DEFAULT (suser_name()) FOR [CreatedBy]
GO

ALTER TABLE [Metadata].[ClusterConfig] ADD  DEFAULT (getutcdate()) FOR [CreatedOn]
GO

ALTER TABLE [Metadata].[ClusterConfig] ADD  DEFAULT (suser_name()) FOR [ModifiedBy]
GO

ALTER TABLE [Metadata].[ClusterConfig] ADD  DEFAULT (getutcdate()) FOR [ModifiedOn]
GO

ALTER TABLE [Metadata].[ClusterConfig]  WITH CHECK ADD FOREIGN KEY([PoolConfigurationID])
REFERENCES [Metadata].[PoolConfig] ([PoolConfigurationID])
GO

ALTER TABLE [Metadata].[ClusterConfig]  WITH CHECK ADD FOREIGN KEY([PoolConfigurationID])
REFERENCES [Metadata].[PoolConfig] ([PoolConfigurationID])
GO