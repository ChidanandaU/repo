CREATE TABLE [Metadata].[EventHubsMaster](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[EventHubName] [nvarchar](100) NOT NULL,
	[EventHubsNamespace] [nvarchar](100) NOT NULL,
	[PartitionName] [nvarchar](100) NOT NULL,
	[EventHubConnectionSecret] [nvarchar](max) NOT NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedBy] [nvarchar](100) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](100) NULL,
	[ModifiedOn] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [Metadata].[EventHubsMaster] ADD  DEFAULT (suser_name()) FOR [CreatedBy]
GO

ALTER TABLE [Metadata].[EventHubsMaster] ADD  DEFAULT (getutcdate()) FOR [CreatedOn]
GO