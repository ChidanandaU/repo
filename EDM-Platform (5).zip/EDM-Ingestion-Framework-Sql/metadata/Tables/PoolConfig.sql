CREATE TABLE [Metadata].[PoolConfig](
	[PoolConfigurationID] [int] IDENTITY(1,1) NOT NULL,
	[PoolName] [nvarchar](1000) NULL,
	[InstanceType] [nvarchar](1000) NULL,
	[PoolDatabricksRuntimeVersion] [nvarchar](1000) NULL,
	[PoolMinIdle] [int] NULL,
	[PoolMaxCapacity] [int] NULL,
	[CreatedBy] [nvarchar](100) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](100) NULL,
	[ModifiedOn] [datetime] NULL,
	[IsLandingToRaw] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[PoolConfigurationID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [Metadata].[PoolConfig] ADD  DEFAULT (suser_name()) FOR [CreatedBy]
GO

ALTER TABLE [Metadata].[PoolConfig] ADD  DEFAULT (getutcdate()) FOR [CreatedOn]
GO

ALTER TABLE [Metadata].[PoolConfig] ADD  DEFAULT (suser_name()) FOR [ModifiedBy]
GO

ALTER TABLE [Metadata].[PoolConfig] ADD  DEFAULT (getutcdate()) FOR [ModifiedOn]
GO