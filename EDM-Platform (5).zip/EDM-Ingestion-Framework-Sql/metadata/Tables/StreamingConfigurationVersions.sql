CREATE TABLE [Metadata].[StreamingConfigurationVersions](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[Version] [nvarchar](10) NOT NULL,
	[ConfigurationID] [bigint] NOT NULL,
	[IsActive] [bit] NOT NULL,
	[VersionStartDate] [date] NOT NULL,
	[VersionExpiryDate] [date] NULL,
	[CreatedBy] [nvarchar](100) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](100) NULL,
	[ModifiedOn] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [Metadata].[StreamingConfigurationVersions] ADD  DEFAULT ((1)) FOR [IsActive]
GO

ALTER TABLE [Metadata].[StreamingConfigurationVersions] ADD  DEFAULT (suser_name()) FOR [CreatedBy]
GO

ALTER TABLE [Metadata].[StreamingConfigurationVersions] ADD  DEFAULT (getutcdate()) FOR [CreatedOn]
GO

ALTER TABLE [Metadata].[StreamingConfigurationVersions]  WITH CHECK ADD FOREIGN KEY([ConfigurationID])
REFERENCES [Metadata].[StreamingConfigurations] ([ID])
GO