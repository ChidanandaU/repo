CREATE TYPE [Metadata].[TableType_ProtegritySchema] AS TABLE(
	[SourceobjectName] [nvarchar](200) NULL,
	[SourceColumnName] [nvarchar](200) NULL,
	[IsTokenizable] [nvarchar](1) NULL,
	[TokenizationAlgorithm] [nvarchar](1000) NULL,
	[TokenizationFunction] [nvarchar](200) NULL,
	[Source] [nvarchar](200) NULL,
	[Country] [nvarchar](200) NULL,
	[ObjectName] [nvarchar](200) NULL
)
GO