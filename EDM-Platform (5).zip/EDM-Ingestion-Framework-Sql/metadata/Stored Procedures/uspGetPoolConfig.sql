CREATE PROCEDURE [Metadata].[uspGetPoolConfig] 
AS
-----------------------------------------------------------------------------------------------------------------------
/****** StoredProcedure:		[Metadata].[uspGetSourceBatchToProcessed]
		Script Date:			2021-06-01
		Author:					Santhosh Boyapally	
		Test Execute:			This SP is used to get the sources to processed
		CMD:					EXEC [Metadata].[uspGetSourceBatchToProcessed]
******/
-----------------------------------------------------------------------------------------------------------------------
BEGIN
	BEGIN TRY
	
	SELECT PoolConfigurationID,
		  '{"instance_pool_name":"'+PoolName+'",
         "node_type_id":"'+cast(InstanceType as nvarchar)+'","min_idle_instances":'+cast(PoolMinIdle as varchar)+
		 ',"max_capacity":'+cast(PoolMaxCapacity as varchar)+',"custom_tags":[{"key":"my-key","value":"my-value"}]}' As ConfigurationBody
   FROM [Metadata].[PoolConfig] 

	END TRY

	BEGIN CATCH
	DECLARE @Errmsg NVARCHAR(4000) = (
				SELECT ERROR_MESSAGE()
				)
			,@ErrorSeverity INT = ERROR_SEVERITY()
			,@ErrorState INT = ERROR_STATE()

		RAISERROR (
				@Errmsg
				,@ErrorSeverity
				,@ErrorState
				)
	END CATCH
END