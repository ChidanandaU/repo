CREATE PROCEDURE [Metadata].[uspInsertObjectSchema]
@SourceObjectSchema [metadata].TableType_SourceObjectSchema READONLY
AS
-----------------------------------------------------------------------------------------------------------------------
/****** StoredProcedure:		[metadata].[uspInsertObjectSchema]
		Script Date:			2021-05-24 
		Author:					Divye Rastogi
		Test Execute:			This SP is used to insert or update records into the SourceObjectDetail Table.
		CMD:					EXEC [metadata].[uspInsertObjectSchema] 
								@SourceObjectSchema = @TableTypeParameter
******/
-----------------------------------------------------------------------------------------------------------------------
BEGIN
	BEGIN TRY
		DECLARE @Source NVARCHAR(50)
		DECLARE @Country NVARCHAR(50)
		DECLARE @ObjectName NVARCHAR(100)

		SELECT @Source = [Source] FROM @SourceObjectSchema
		SELECT @Country = Country FROM @SourceObjectSchema
		SELECT @ObjectName = ObjectName FROM @SourceObjectSchema

		DECLARE @SourceObjectID INT
		SELECT @SourceObjectID = sod.SourceObjectID 
		FROM Metadata.SourceMaster sm
		INNER JOIN Metadata.SourceObjectDetail sod ON sm.SourceID = sod.SourceID
		WHERE sm.SourceName = @Source 
		AND sm.CountryCode = @Country 
		AND sod.ObjectName = @ObjectName

		-- if column deleted from source.
		UPDATE Metadata.SourceObjectSchema
		SET
		IsActive = 0,
		ColumnOrder = -1,
		IsSchemaEvolved = 1
		WHERE SourceObjectID = @SourceObjectID
		AND ColumnName NOT IN (SELECT ColumnName FROM @SourceObjectSchema)
	

		MERGE INTO metadata.SourceObjectSchema As Tar
		USING
		(
			SELECT 
			ColumnName,
			ColumnOrder,
			DataType,
			IsPrimaryKey,
			[Length],
			Width,
			Rules as [Rule],
			SourceDataType,
			IsNullable,
			IsActive
			FROM @SourceObjectSchema
		)As Src
		ON Tar.SourceObjectID = @SourceObjectID
		AND Tar.ColumnName = Src.ColumnName

		WHEN MATCHED AND (
		Tar.ColumnOrder		!= Src.ColumnOrder OR
		Tar.DataType		!= Src.DataType OR
		Tar.IsPrimaryKey	!= Src.IsPrimaryKey OR
		Tar.IsActive		!= Src.IsActive OR
		Tar.Width			!= Src.Width OR
		Tar.[Rule]			!= Src.[Rule] OR
		Tar.SourceDataType	!= Src.SourceDataType OR
		Tar.IsNullable		!= Src.IsNullable OR
		Tar.[Length]		!= Src.[Length]
	)
		THEN UPDATE
		SET
		Tar.ColumnOrder		= Src.ColumnOrder,
		Tar.DataType		= Src.DataType,
		Tar.IsPrimaryKey	= Src.IsPrimaryKey,
		Tar.IsActive		= Src.IsActive,
		Tar.Width			= Src.Width,
		Tar.[Length]		= Src.[Length],
		Tar.[Rule]			= Src.[Rule],
		Tar.SourceDataType	= Src.SourceDataType,
		Tar.IsNullable		= Src.IsNullable,
		Tar.IsSchemaEvolved = CASE WHEN Tar.DataType!= Src.DataType OR Tar.ColumnOrder!= Src.ColumnOrder
		                           THEN 1 
								   ELSE Tar.IsSchemaEvolved
								   END,
		Tar.ModifiedBy		= suser_name(),
		Tar.ModifiedOn		= GETUTCDATE()


		WHEN NOT MATCHED THEN INSERT
		(
			 [SourceObjectID]
			,[ColumnName]
			,[ColumnOrder]
			,[SourceDataType]
			,[DataType]
			,[IsPrimaryKey]
			,[ColumnFormat]
			,[IsNullable]
			,[IsActive]
			,[IsSchemaEvolved]
			,[Width]
			,[Length]
			,[Rule]
			,[CreatedBy]
			,[CreatedOn]
		)
		VALUES
		(
			@SourceObjectID,
			Src.ColumnName,
			Src.ColumnOrder,
			Src.SourceDataType,
			Src.DataType,
			Src.IsPrimaryKey,
			NULL,
			Src.IsNullable,
			Src.IsActive,
			0,
			Src.Width,
			Src.[Length],
			Src.[Rule],
			suser_name(),
			GETUTCDATE()
		);
	END TRY

	BEGIN CATCH
		DECLARE @Errmsg NVARCHAR(4000) = (
				SELECT ERROR_MESSAGE()
				)
			,@ErrorSeverity INT = ERROR_SEVERITY()
			,@ErrorState INT = ERROR_STATE()

		RAISERROR (
				@Errmsg
				,@ErrorSeverity
				,@ErrorState
				)
	END CATCH
END
