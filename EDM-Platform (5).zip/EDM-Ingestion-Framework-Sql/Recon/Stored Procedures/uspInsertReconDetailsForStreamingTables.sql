CREATE PROCEDURE [Recon].[uspInsertReconDetailsForStreamingTables]
(
	@ControlFileName NVARCHAR(200),
	@TargetTableName NVARCHAR(100),
	@ReconDate DATETIME2,
	@ControlFileRecordCount INT,
	@FailedEDMPTableRowCount INT,
	@IsReconSkipped BIT=0,
    @IsReconSuccessful BIT,
	@ExceptionDetails NVARCHAR(MAX)=NUll

)
AS    
-----------------------------------------------------------------------------------------------------------------------    
/****** StoredProcedure:  [Recon].[uspInsertReconDetailsForStreamingTables]
  Script Date:   2021-07-08    
  Author:     Saurav Misra    
  Test Execute:   This SP is used to insert recon details for a table
******/    
-----------------------------------------------------------------------------------------------------------------------    
BEGIN    
	DECLARE @TargetTableId BIGINT;
	SELECT @TargetTableId = ID FROM Metadata.StreamingEDMPTableDetails WHERE TargetTableName = @TargetTableName;
	INSERT INTO [Recon].[StreamingTableReconciliation]
           ([ControlFileName]
           ,[TargetTableID]
           ,[ReconDate]
           ,[ControlFileRecordCount]
           ,[FailedEDMPTableRowCount]
           ,[IsReconSkipped]
           ,[IsReconSuccessful]
		   ,[ExceptionDetails]
           ,[CreatedBy]
           ,[CreatedOn])
     VALUES
           (
			@ControlFileName,
			@TargetTableId,
			@ReconDate,
			@ControlFileRecordCount,
			@FailedEDMPTableRowCount,
			@IsReconSkipped,
			@IsReconSuccessful,
			NULLIF(@ExceptionDetails, 'None'),
			SUSER_NAME(),
			GETUTCDATE()
			)  
END